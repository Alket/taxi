--
-- PostgreSQL database dump
--

\restrict Zl3DyT0hNttUWbNQOMwi1IHOsaCXWHVPamZfcuMPrTofsya9j5ZtkMNdYs3bHhh

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AdminRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AdminRole" AS ENUM (
    'admin',
    'operator'
);


--
-- Name: BookerRelation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BookerRelation" AS ENUM (
    'family_friend',
    'travel_agent',
    'colleague',
    'prefer_not_to_say'
);


--
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'pending',
    'confirmed',
    'driver_assigned',
    'en_route',
    'arrived',
    'in_progress',
    'completed',
    'cancelled',
    'driver_accepted'
);


--
-- Name: CancellationOutcome; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CancellationOutcome" AS ENUM (
    'free_cancellation',
    'deposit_forfeited'
);


--
-- Name: ConnectionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ConnectionStatus" AS ENUM (
    'connected',
    'disconnected'
);


--
-- Name: Direction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Direction" AS ENUM (
    'airport_to_dest',
    'dest_to_airport'
);


--
-- Name: FlightStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FlightStatus" AS ENUM (
    'scheduled',
    'on_time',
    'delayed',
    'landed',
    'cancelled'
);


--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'email',
    'sms',
    'whatsapp'
);


--
-- Name: NotificationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationStatus" AS ENUM (
    'pending',
    'sent',
    'failed'
);


--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationType" AS ENUM (
    'confirmation',
    'driver_assigned',
    'flight_delay',
    'reminder',
    'cancellation',
    'date_change',
    'completed_receipt',
    'review_request',
    'review_submitted'
);


--
-- Name: PaymentMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMode" AS ENUM (
    'test',
    'live'
);


--
-- Name: PaymentProvider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentProvider" AS ENUM (
    'stripe',
    'paypal',
    'manual'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'unpaid',
    'deposit_paid',
    'paid',
    'refunded',
    'failed',
    'fully_paid'
);


--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentType" AS ENUM (
    'deposit',
    'balance'
);


--
-- Name: ReviewStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReviewStatus" AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: VehicleType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VehicleType" AS ENUM (
    'sedan',
    'minivan'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminUser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AdminUser" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    role public."AdminRole" DEFAULT 'admin'::public."AdminRole" NOT NULL,
    suspended boolean DEFAULT false NOT NULL,
    "requiresPasswordReset" boolean DEFAULT false NOT NULL
);


--
-- Name: Booking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Booking" (
    id text NOT NULL,
    "referenceCode" text NOT NULL,
    direction public."Direction" NOT NULL,
    "pickupAddress" text NOT NULL,
    "dropoffAddress" text NOT NULL,
    "pickupDateTime" timestamp(3) without time zone NOT NULL,
    "flightNumber" text NOT NULL,
    "flightStatus" public."FlightStatus" DEFAULT 'scheduled'::public."FlightStatus" NOT NULL,
    "passengerCount" integer NOT NULL,
    "luggageCount" integer NOT NULL,
    "vehicleType" public."VehicleType" NOT NULL,
    "totalPrice" numeric(10,2) NOT NULL,
    "depositPaid" numeric(10,2) DEFAULT 0 NOT NULL,
    "balanceDue" numeric(10,2) DEFAULT 0 NOT NULL,
    "isBalanceCharged" boolean DEFAULT false NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'unpaid'::public."PaymentStatus" NOT NULL,
    status public."BookingStatus" DEFAULT 'pending'::public."BookingStatus" NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    "freeCancellationUntil" timestamp(3) without time zone NOT NULL,
    notes text,
    "customerId" text NOT NULL,
    "driverId" text,
    "zoneId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "pickupPin" text NOT NULL,
    "depositAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "balanceChargedAt" timestamp(3) without time zone,
    "balanceChargedBy" text,
    "cancelledAt" timestamp(3) without time zone,
    "cancellationOutcome" public."CancellationOutcome",
    "meetAndGreet" boolean DEFAULT false NOT NULL,
    "isRoundTrip" boolean DEFAULT false NOT NULL,
    "roundTripId" text,
    "bookedForOther" boolean DEFAULT false NOT NULL,
    "passengerName" text,
    "passengerEmail" text,
    "passengerPhone" text,
    "passengerNoEmail" boolean DEFAULT false NOT NULL,
    "bookerRelation" public."BookerRelation"
);


--
-- Name: BookingStatusEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BookingStatusEvent" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    status public."BookingStatus" NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "stripeCustomerId" text
);


--
-- Name: Driver; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Driver" (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    "whatsappNumber" text NOT NULL,
    "vehicleMake" text NOT NULL,
    "vehicleModel" text NOT NULL,
    "plateNumber" text NOT NULL,
    "vehicleType" public."VehicleType" NOT NULL,
    languages text[],
    vetted boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "avgRating" double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "pinHash" text
);


--
-- Name: FlightStatusEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FlightStatusEvent" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "flightNumber" text NOT NULL,
    status public."FlightStatus" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "observedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "delayMinutes" integer,
    source text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: MediaAsset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MediaAsset" (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    "mimeType" text DEFAULT ''::text NOT NULL,
    "sizeBytes" integer DEFAULT 0 NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    alt text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: NotificationLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificationLog" (
    id text NOT NULL,
    "bookingId" text,
    "customerId" text,
    channel public."NotificationChannel" NOT NULL,
    type public."NotificationType" NOT NULL,
    status public."NotificationStatus" DEFAULT 'pending'::public."NotificationStatus" NOT NULL,
    recipient text NOT NULL,
    subject text,
    body text,
    "sentAt" timestamp(3) without time zone,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PageContent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PageContent" (
    id text NOT NULL,
    slug text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "ogImage" text DEFAULT ''::text NOT NULL,
    sections jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    locale text DEFAULT 'en'::text NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    status public."PaymentStatus" NOT NULL,
    provider public."PaymentProvider" NOT NULL,
    "externalId" text,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    type public."PaymentType" DEFAULT 'deposit'::public."PaymentType" NOT NULL
);


--
-- Name: PaypalOrderIntent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PaypalOrderIntent" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "bookingId" text NOT NULL,
    "paymentOption" text NOT NULL,
    "expectedAmount" numeric(10,2) NOT NULL,
    currency text NOT NULL,
    status text DEFAULT 'created'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PricingRule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PricingRule" (
    id text NOT NULL,
    "zoneId" text NOT NULL,
    "vehicleType" public."VehicleType" NOT NULL,
    "baseFare" numeric(10,2) NOT NULL,
    "perKmRate" numeric(10,2) NOT NULL,
    "minFare" numeric(10,2) NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PushSubscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PushSubscription" (
    id text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    audience text NOT NULL,
    "ownerId" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Review" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "driverId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "driverRating" integer NOT NULL,
    "driverComment" text,
    "platformRating" integer NOT NULL,
    "platformComment" text,
    status public."ReviewStatus" DEFAULT 'pending'::public."ReviewStatus" NOT NULL,
    "moderatedAt" timestamp(3) without time zone
);


--
-- Name: Settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Settings" (
    id text DEFAULT 'default'::text NOT NULL,
    "companyName" text NOT NULL,
    "supportPhone" text NOT NULL,
    "supportEmail" text NOT NULL,
    "supportWhatsApp" text NOT NULL,
    "displayCurrencies" text[],
    "freeCancellationHours" integer DEFAULT 24 NOT NULL,
    "depositPercentage" integer DEFAULT 30 NOT NULL,
    airports jsonb NOT NULL,
    "notificationChannelsEnabled" jsonb NOT NULL,
    "flightDelayThresholdMinutes" integer DEFAULT 45 NOT NULL,
    "whatsappConnectionStatus" public."ConnectionStatus" DEFAULT 'disconnected'::public."ConnectionStatus" NOT NULL,
    "stripeMode" text DEFAULT 'test'::text NOT NULL,
    "paypalMode" text DEFAULT 'test'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "roundTripDiscountPercent" integer DEFAULT 0 NOT NULL,
    "stripeEnabled" boolean DEFAULT true NOT NULL,
    "paypalEnabled" boolean DEFAULT true NOT NULL,
    "cashOnArrivalEnabled" boolean DEFAULT false NOT NULL,
    "infantCarrierPrice" numeric(10,2) DEFAULT 0 NOT NULL,
    "childSeatPrice" numeric(10,2) DEFAULT 0 NOT NULL,
    "boosterSeatPrice" numeric(10,2) DEFAULT 0 NOT NULL,
    "paypalSandboxClientId" text DEFAULT ''::text NOT NULL,
    "paypalSandboxSecret" text DEFAULT ''::text NOT NULL,
    "paypalLiveClientId" text DEFAULT ''::text NOT NULL,
    "paypalLiveSecret" text DEFAULT ''::text NOT NULL,
    "depositPaymentEnabled" boolean DEFAULT true NOT NULL,
    "fullPaymentEnabled" boolean DEFAULT true NOT NULL,
    "stripeTestPublishableKey" text DEFAULT ''::text NOT NULL,
    "stripeTestSecretKey" text DEFAULT ''::text NOT NULL,
    "stripeTestWebhookSecret" text DEFAULT ''::text NOT NULL,
    "stripeLivePublishableKey" text DEFAULT ''::text NOT NULL,
    "stripeLiveSecretKey" text DEFAULT ''::text NOT NULL,
    "stripeLiveWebhookSecret" text DEFAULT ''::text NOT NULL,
    "adminNotificationEmail" text DEFAULT ''::text NOT NULL,
    "faviconUrl" text DEFAULT ''::text NOT NULL,
    "searchIndexingEnabled" boolean DEFAULT false NOT NULL,
    "smtpHost" text DEFAULT ''::text NOT NULL,
    "smtpPort" integer DEFAULT 465 NOT NULL,
    "smtpSecure" boolean DEFAULT true NOT NULL,
    "smtpUser" text DEFAULT ''::text NOT NULL,
    "smtpPass" text DEFAULT ''::text NOT NULL,
    "smtpFrom" text DEFAULT ''::text NOT NULL,
    "smtpTlsRejectUnauthorized" boolean DEFAULT true NOT NULL,
    "sedanSeats" integer DEFAULT 3 NOT NULL,
    "sedanLuggage" integer DEFAULT 2 NOT NULL,
    "minivanSeats" integer DEFAULT 6 NOT NULL,
    "minivanLuggage" integer DEFAULT 6 NOT NULL
);


--
-- Name: StaffNotification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StaffNotification" (
    id text NOT NULL,
    audience text NOT NULL,
    "ownerId" text,
    type text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    url text NOT NULL,
    "bookingId" text,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Zone" (
    id text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AdminUser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AdminUser" (id, name, email, "passwordHash", "lastLoginAt", "createdAt", role, suspended, "requiresPasswordReset") FROM stdin;
cmsfs050m0007ob8s47y0x82i	Shytialket	shytialket@gmail.com	$2b$12$/WC20RrM9yAD3wRxKDYUHeqGvVokkrWcg1X3DjlCEqFK6QApypRCK	2026-08-05 07:39:54.877	2026-08-05 07:39:03.91	operator	f	f
cmry2z98u0000lkbn86mkqlac	Ops Team	ops@transfers.co	$2b$12$1O1dR.QFTIgT33NozJVegOpNmrCWoaFqI/xil.HZrZH.qIWPnr8G2	2026-08-06 09:06:54.797	2026-07-23 22:26:27.342	admin	f	f
\.


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Booking" (id, "referenceCode", direction, "pickupAddress", "dropoffAddress", "pickupDateTime", "flightNumber", "flightStatus", "passengerCount", "luggageCount", "vehicleType", "totalPrice", "depositPaid", "balanceDue", "isBalanceCharged", "paymentStatus", status, currency, "freeCancellationUntil", notes, "customerId", "driverId", "zoneId", "createdAt", "updatedAt", "pickupPin", "depositAmount", "balanceChargedAt", "balanceChargedBy", "cancelledAt", "cancellationOutcome", "meetAndGreet", "isRoundTrip", "roundTripId", "bookedForOther", "passengerName", "passengerEmail", "passengerPhone", "passengerNoEmail", "bookerRelation") FROM stdin;
cmry2z9fv0048lkbn7uoyzc0r	TRF-1AB6YT	dest_to_airport	Liro Hotel, Rruga e Butrintit, Ksamil	Tirana International Airport (TIA), Departures	2026-07-29 08:00:00	IB3251	scheduled	2	2	sedan	118.00	35.40	82.60	f	deposit_paid	pending	EUR	2026-07-28 08:00:00	\N	cmry2z9fs0046lkbnvd992sjw	\N	cmry2z99i0002lkbnwyhnms54	2026-07-23 22:26:27.595	2026-07-23 22:26:27.595	448277	35.40	\N	\N	\N	\N	f	f	\N	f	\N	\N	\N	f	\N
cmry2z9gy0052lkbna03aqxa2	TRF-3ZX5PL	airport_to_dest	Tirana International Airport (TIA), Arrivals Hall	Hotel Vlora International, Rruga Justin Godard, Vlorë	2026-07-26 13:20:00	QR0127	on_time	2	3	sedan	74.00	0.00	51.80	f	failed	pending	EUR	2026-07-25 13:20:00	Card payment failed — customer asked to retry.	cmry2z9gw0050lkbnoemyii3q	\N	cmry2z99p0004lkbnfdf0qbpy	2026-07-23 22:26:27.635	2026-07-23 22:26:27.635	693769	22.20	\N	\N	\N	\N	f	f	\N	f	\N	\N	\N	f	\N
cmryq5lhv0002lk9ks26z915e	TRF-8F4E7E	airport_to_dest	Tirana International (TIA)	Berat	2026-07-24 11:10:00	AB1235	scheduled	1	0	sedan	65.00	65.00	0.00	t	fully_paid	completed	EUR	2026-07-23 11:10:00	Meet & greet requested. Child seats: Infant carrier ×1 (EUR 10.00 each). Driver notes: This is a test note Source: public booking · deposit paid.	cmryq5lgp0000lk9kee4bgiho	cmry2z9co0023lkbnuo6p7xma	cmry2z99u0007lkbn2bv1pcr0	2026-07-24 09:15:14.324	2026-07-24 09:18:05.852	766134	19.50	2026-07-24 09:18:04.533	Ana Krasniqi	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cms94b99b0007lkbcdgjrwg1c	TRF-F971AE	airport_to_dest	Tirana International (TIA)	Berat	2026-07-31 17:45:00		scheduled	1	0	sedan	55.00	0.00	38.50	f	unpaid	pending	EUR	2026-07-30 17:45:00	Source: public booking · awaiting deposit (unpaid pending checkout).	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-07-31 15:49:14.783	2026-07-31 15:49:14.783	746446	16.50	\N	\N	\N	\N	f	f	\N	f	\N	\N	\N	f	\N
cmsbxadu80002lk9mimqt3zhu	TRF-64F5CC	airport_to_dest	Tirana International (TIA)	Durrës	2026-08-25 15:55:00	AB1235	scheduled	1	0	sedan	48.00	48.00	0.00	t	fully_paid	confirmed	EUR	2026-08-24 15:55:00	Meet & greet requested. Child seats: Infant carrier ×1 (EUR 10.00 each). Driver notes: test Source: public booking · paid in full.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99k0003lkbnxehr7hvb	2026-08-02 14:55:55.281	2026-08-02 14:56:26.254	850717	14.40	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmseg1f6o0002lk9ycdorsq5t	TRF-B3EA2F	airport_to_dest	Tirana International (TIA)	Berat	2026-08-19 10:15:00	AB1235	scheduled	1	0	sedan	55.00	55.00	0.00	t	fully_paid	confirmed	EUR	2026-08-18 10:15:00	Meet & greet requested. Source: public booking · paid in full.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-04 09:16:22.176	2026-08-04 09:16:44.446	908669	16.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsegazvq000flk9y9izogwfm	TRF-AC13AA	airport_to_dest	Tirana International (TIA)	Berat	2026-08-12 10:20:00	AB1235	scheduled	1	0	sedan	65.00	65.00	0.00	t	fully_paid	confirmed	EUR	2026-08-11 10:20:00	Meet & greet requested. Child seats: Infant carrier ×1 (EUR 10.00 each). Driver notes: test Source: public booking · paid in full.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-04 09:23:48.902	2026-08-04 09:24:09.485	188308	19.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsghk9jx0002ob9nnqy7ctx2	TRF-2A1926	airport_to_dest	Tirana International (TIA)	Berat	2026-08-06 20:30:00	AB1235	scheduled	1	0	sedan	55.00	55.00	0.00	t	fully_paid	completed	EUR	2026-08-05 20:30:00	Meet & greet requested. Source: public booking · cash on arrival.	cmryq5lgp0000lk9kee4bgiho	cmry2z9co0023lkbnuo6p7xma	cmry2z99u0007lkbn2bv1pcr0	2026-08-05 19:34:33.309	2026-08-05 19:43:20.612	082564	16.50	2026-08-05 19:43:04.516	Ana Krasniqi	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsgi62jh001cob9n63fk9rwv	TRF-524530	airport_to_dest	Tirana International (TIA)	Berat	2026-08-13 20:50:00	AB1235	scheduled	1	0	sedan	55.00	0.00	55.00	f	unpaid	confirmed	EUR	2026-08-12 20:50:00	Meet & greet requested. Source: public booking · cash on arrival.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-05 19:51:30.653	2026-08-05 19:51:33.415	691184	16.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsgi8q20001oob9ndikhokb0	TRF-8CAEC0	airport_to_dest	Tirana International (TIA)	Berat	2026-08-06 20:50:00	AB1235	scheduled	2	2	sedan	55.00	0.00	55.00	f	unpaid	confirmed	EUR	2026-08-05 20:50:00	Meet & greet requested. Source: public booking · cash on arrival.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-05 19:53:34.44	2026-08-05 19:53:38.299	878233	16.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmry2z9ev003clkbnqx8ps17f	TRF-5KD0ZE	airport_to_dest	Tirana International Airport (TIA), Arrivals Hall	Rogner Hotel Tirana, Bulevardi Deshmoret e Kombit	2026-07-28 11:00:00	BA2592	scheduled	1	2	sedan	78.00	23.40	54.60	f	deposit_paid	confirmed	EUR	2026-07-27 11:00:00	\N	cmry2z9es003alkbnmjeixgp1	\N	cmry2z9920001lkbnp5z0niw5	2026-07-23 22:26:27.559	2026-07-23 22:26:27.559	416599	23.40	\N	\N	\N	\N	f	f	\N	f	\N	\N	\N	f	\N
cmry2z9f8003mlkbn40w729kf	TRF-9WP3LQ	airport_to_dest	Tirana International Airport (TIA), Arrivals Hall	Hotel Butrinti, Rruga Teodor Keko, Sarandë	2026-07-27 16:45:00	KL1611	on_time	2	2	sedan	145.00	43.50	101.50	t	fully_paid	completed	EUR	2026-07-26 16:45:00	\N	cmry2z9f6003klkbnk0gb66b7	cmry2z9co0025lkbn0ry329so	cmry2z99p0005lkbnv0tuzomm	2026-07-23 22:26:27.573	2026-07-23 22:26:27.573	646251	43.50	2026-07-22 18:00:00	admin	\N	\N	f	f	\N	f	\N	\N	\N	f	\N
cmsgma8770002ob9spaefubp8	TRF-DF20A6	airport_to_dest	Tirana International (TIA)	Berat	2026-08-09 07:00:00	AB1235	scheduled	1	1	sedan	65.00	0.00	65.00	f	unpaid	cancelled	EUR	2026-08-08 07:00:00	Meet & greet requested. Child seats: Infant carrier ×1 (EUR 10.00 each). Driver notes: tst Source: public booking · cash on arrival.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-05 21:46:43.075	2026-08-05 21:59:27.825	233264	19.50	\N	\N	2026-08-05 21:59:27.821	deposit_forfeited	t	f	\N	f	\N	\N	\N	f	\N
cmsglwoak002hob9napjtx8b9	TRF-EAE09B	airport_to_dest	Tirana International Airport (TIA), Arrivals	Hotel Plaza Tirana, Rruga 28 Nentori	2026-08-07 10:00:00	OS847	scheduled	2	2	sedan	40.00	0.00	40.00	f	unpaid	cancelled	EUR	2026-08-06 10:00:00	Meet & greet requested. Child seats: Child seat ×1 (EUR 12.00 each). Driver notes: Tester notes — not hardcoded Source: public booking · cash on arrival.	cmsglwo9k002fob9nle2dkrd4	\N	cmry2z9920001lkbnp5z0niw5	2026-08-05 21:36:10.748	2026-08-05 22:03:38.273	513596	12.00	\N	\N	2026-08-05 22:03:38.269	deposit_forfeited	t	f	\N	f	\N	\N	\N	f	\N
cmsemsjqr0002ob8sq2rsiygn	TRF-BE34B3	airport_to_dest	Tirana International (TIA)	Berat	2026-09-08 12:00:00	AB1235	scheduled	2	0	sedan	55.00	0.00	38.50	f	unpaid	pending	EUR	2026-09-07 12:00:00	Meet & greet requested. Source: public booking · awaiting deposit (unpaid pending checkout).	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-04 12:25:25.49	2026-08-05 22:11:44.929	799062	16.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsgia4y60020ob9n7ue5ub66	TRF-233B8F	airport_to_dest	Tirana International (TIA)	Berat	2026-08-13 20:50:00		scheduled	1	0	sedan	55.00	0.00	55.00	f	unpaid	cancelled	EUR	2026-08-12 20:50:00	Meet & greet requested. Source: public booking · cash on arrival.	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-05 19:54:40.398	2026-08-05 22:11:56.71	267139	16.50	\N	\N	2026-08-05 22:11:56.706	deposit_forfeited	t	f	\N	f	\N	\N	\N	f	\N
cmshkc5bv00f5ob9npx1h0y06	TRF-696659	airport_to_dest	Tirana International (TIA)	Berat	2026-08-07 14:35:00	AB1235	scheduled	1	0	sedan	55.00	0.00	38.50	f	unpaid	pending	EUR	2026-08-06 14:35:00	Meet & greet requested. Source: public booking · awaiting deposit (unpaid pending checkout).	cmryq5lgp0000lk9kee4bgiho	\N	cmry2z99u0007lkbn2bv1pcr0	2026-08-06 13:39:59.611	2026-08-06 13:39:59.611	049595	16.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsh7n8wc001nob9s4bi0oyce	TRF-337692	airport_to_dest	Tirana International (TIA)	Durrës	2026-08-06 12:44:00		scheduled	2	2	sedan	38.00	0.00	26.60	f	unpaid	driver_accepted	EUR	2026-08-05 12:44:00	Meet & greet requested.	cmsh7n8ua001lob9ss90o7895	cmry2z9co0023lkbnuo6p7xma	cmry2z99k0003lkbnxehr7hvb	2026-08-06 07:44:42.443	2026-08-06 08:50:34.065	941651	11.40	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsh9xxzp0002ob9nrmdfq0sx	TRF-DF371C	airport_to_dest	Tirana International (TIA)	Berat	2026-08-13 09:45:00	AB1235	scheduled	1	0	sedan	65.00	65.00	0.00	t	fully_paid	completed	EUR	2026-08-12 09:45:00	Meet & greet requested for Elisjon Shyti. Passenger: Elisjon Shyti. Child seats: Infant carrier ×1 (EUR 10.00 each). Driver notes: this is a test Source: public booking · cash on arrival.	cmsh7n8ua001lob9ss90o7895	cmry2z9co0023lkbnuo6p7xma	cmry2z99u0007lkbn2bv1pcr0	2026-08-06 08:49:00.757	2026-08-06 08:51:39.18	025433	19.50	2026-08-06 08:51:37.88	Ana Krasniqi	\N	\N	t	f	\N	t	Elisjon Shyti	shytialket@gmail.com	+355692356010	f	family_friend
cmshako2o0014ob9n60b6qapc	TRF-EF6E40	airport_to_dest	Tirana International Airport	Tirana City QA destination	2026-08-08 12:00:00	QA123	scheduled	2	2	sedan	28.00	0.00	19.60	f	unpaid	pending	EUR	2026-08-07 12:00:00	Meet & greet requested for QA Passenger Seven. Passenger: QA Passenger Seven. Source: public booking · awaiting deposit (unpaid pending checkout). Customer opted out of WhatsApp updates.	cmshako1w0012ob9n0r6x68m7	\N	cmry2z9920001lkbnp5z0niw5	2026-08-06 09:06:40.992	2026-08-06 09:06:40.992	839556	8.40	\N	\N	\N	\N	t	f	\N	t	QA Passenger Seven	\N	+355681111117	t	family_friend
cmshako3p0018ob9nf6v8z4vg	TRF-B28CAA	airport_to_dest	Tirana International Airport	Tirana City QA destination	2026-08-08 12:00:00	QA123	scheduled	2	2	sedan	28.00	0.00	19.60	f	unpaid	pending	EUR	2026-08-07 12:00:00	Meet & greet requested for QA Passenger Eight. Passenger: QA Passenger Eight. Source: public booking · awaiting deposit (unpaid pending checkout). Customer opted out of WhatsApp updates.	cmshako3d0016ob9nw4ojvpw6	\N	cmry2z9920001lkbnp5z0niw5	2026-08-06 09:06:41.029	2026-08-06 09:06:41.029	662224	8.40	\N	\N	\N	\N	t	f	\N	t	QA Passenger Eight	qa-pax-1786007200@example.com	+355681111118	f	colleague
cmshako4r001cob9nmxua3ks0	TRF-64240C	airport_to_dest	Tirana International Airport	Tirana City QA destination	2026-08-08 12:00:00	QA123	scheduled	2	2	sedan	28.00	0.00	19.60	f	unpaid	pending	EUR	2026-08-07 12:00:00	Meet & greet requested. Source: public booking · awaiting deposit (unpaid pending checkout). Customer opted out of WhatsApp updates.	cmshako4f001aob9nk9fo4k6c	\N	cmry2z9920001lkbnp5z0niw5	2026-08-06 09:06:41.068	2026-08-06 09:06:41.068	938704	8.40	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmshakq4a001gob9n52b00yjo	TRF-C798EC	airport_to_dest	Tirana International Airport	Tirana City QA destination	2026-08-08 12:00:00	QA123	scheduled	2	2	sedan	28.00	0.00	19.60	f	unpaid	pending	EUR	2026-08-07 12:00:00	Meet & greet requested. Source: public booking · awaiting deposit (unpaid pending checkout). Customer opted out of WhatsApp updates.	cmshakq2d001eob9nz78wsaec	\N	cmry2z9920001lkbnp5z0niw5	2026-08-06 09:06:43.642	2026-08-06 09:06:43.642	281055	8.40	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
cmsghzq5d0010ob9n1qn6qmls	TRF-3B6A17	airport_to_dest	Tirana International (TIA)	Berat	2026-08-06 20:45:00	AB1235	scheduled	1	0	sedan	55.00	0.00	55.00	f	unpaid	driver_accepted	EUR	2026-08-05 20:45:00	Meet & greet requested. Source: public booking · cash on arrival.	cmryq5lgp0000lk9kee4bgiho	cmry2z9co0023lkbnuo6p7xma	cmry2z99u0007lkbn2bv1pcr0	2026-08-05 19:46:34.657	2026-08-06 10:06:29.717	173348	16.50	\N	\N	\N	\N	t	f	\N	f	\N	\N	\N	f	\N
\.


--
-- Data for Name: BookingStatusEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BookingStatusEvent" (id, "bookingId", status, "timestamp") FROM stdin;
cmry2z9ev003dlkbncakv7dnh	cmry2z9ev003clkbnqx8ps17f	pending	2026-07-28 09:30:00
cmry2z9ev003elkbneu1a59ql	cmry2z9ev003clkbnqx8ps17f	confirmed	2026-07-28 10:15:00
cmry2z9f8003nlkbnowzscegn	cmry2z9f8003mlkbn40w729kf	pending	2026-07-27 10:45:00
cmry2z9f8003olkbnx0lmus2p	cmry2z9f8003mlkbn40w729kf	confirmed	2026-07-27 11:30:00
cmry2z9f8003plkbnab7xvt30	cmry2z9f8003mlkbn40w729kf	driver_assigned	2026-07-27 12:15:00
cmry2z9f8003qlkbntthma6iq	cmry2z9f8003mlkbn40w729kf	driver_accepted	2026-07-27 13:00:00
cmry2z9f8003rlkbnrvk29g5v	cmry2z9f8003mlkbn40w729kf	en_route	2026-07-27 13:45:00
cmry2z9f8003slkbn3emrji3o	cmry2z9f8003mlkbn40w729kf	arrived	2026-07-27 14:30:00
cmry2z9f8003tlkbnamy0hh76	cmry2z9f8003mlkbn40w729kf	in_progress	2026-07-27 15:15:00
cmry2z9f8003ulkbno6aiw1u9	cmry2z9f8003mlkbn40w729kf	completed	2026-07-27 16:00:00
cmry2z9fv0049lkbn1evgppzt	cmry2z9fv0048lkbn7uoyzc0r	pending	2026-07-29 07:15:00
cmshkc5bv00f6ob9n6fqtare3	cmshkc5bv00f5ob9npx1h0y06	pending	2026-08-06 13:39:59.604
cmry2z9gy0053lkbnnhv51vsx	cmry2z9gy0052lkbna03aqxa2	pending	2026-07-26 12:35:00
cmryq5lhw0003lk9klamzljb2	cmryq5lhv0002lk9ks26z915e	pending	2026-07-24 09:15:14.322
cmryq62k70007lk9kipk5fen0	cmryq5lhv0002lk9ks26z915e	confirmed	2026-07-24 09:15:36.411
cmryq7wrc000elk9kji0cp4z4	cmryq5lhv0002lk9ks26z915e	driver_assigned	2026-07-24 09:17:02.232
cmryq8z4k000hlk9kbsvtwgbu	cmryq5lhv0002lk9ks26z915e	driver_accepted	2026-07-24 09:17:51.956
cmryq972a000mlk9k40oref3v	cmryq5lhv0002lk9ks26z915e	arrived	2026-07-24 09:18:02.242
cmryq99uq000slk9kzvwstk1a	cmryq5lhv0002lk9ks26z915e	completed	2026-07-24 09:18:05.859
cms94b99c0008lkbcv1b1p49m	cms94b99b0007lkbcdgjrwg1c	pending	2026-07-31 15:49:14.781
cmsbxadu90003lk9maanjr4lc	cmsbxadu80002lk9mimqt3zhu	pending	2026-08-02 14:55:55.275
cmsbxb1rj0007lk9mb6zw05u8	cmsbxadu80002lk9mimqt3zhu	confirmed	2026-08-02 14:56:26.212
cmseg1f6p0003lk9y1g9f038c	cmseg1f6o0002lk9ycdorsq5t	pending	2026-08-04 09:16:22.172
cmseg1wdy0007lk9ycvzg8fqo	cmseg1f6o0002lk9ycdorsq5t	confirmed	2026-08-04 09:16:44.415
cmsegazvq000glk9ytbt2kfu2	cmsegazvq000flk9y9izogwfm	pending	2026-08-04 09:23:48.898
cmsegbfrr000klk9ydst167ga	cmsegazvq000flk9y9izogwfm	confirmed	2026-08-04 09:24:09.468
cmsemsjqr0003ob8s162o72rw	cmsemsjqr0002ob8sq2rsiygn	pending	2026-08-04 12:25:25.487
cmsghk9jx0003ob9nply1x6a0	cmsghk9jx0002ob9nnqy7ctx2	pending	2026-08-05 19:34:33.304
cmsghkqhs0004ob9nj2h6pt8x	cmsghk9jx0002ob9nnqy7ctx2	confirmed	2026-08-05 19:34:55.26
cmsghmml7000dob9nrp2adsfm	cmsghk9jx0002ob9nnqy7ctx2	driver_assigned	2026-08-05 19:36:23.515
cmsghn3wu000gob9nyg4u4g5z	cmsghk9jx0002ob9nnqy7ctx2	driver_accepted	2026-08-05 19:36:45.967
cmsghuzpx000lob9n3dupdcig	cmsghk9jx0002ob9nnqy7ctx2	arrived	2026-08-05 19:42:53.781
cmsghvkfb000rob9n15getp8p	cmsghk9jx0002ob9nnqy7ctx2	completed	2026-08-05 19:43:20.615
cmsghzq5d0011ob9nko8fjalo	cmsghzq5d0010ob9n1qn6qmls	pending	2026-08-05 19:46:34.652
cmsgi0nox0012ob9nzqd3l9gk	cmsghzq5d0010ob9n1qn6qmls	confirmed	2026-08-05 19:47:18.125
cmsgi62jh001dob9ny6dyjr69	cmsgi62jh001cob9n63fk9rwv	pending	2026-08-05 19:51:30.65
cmsgi64o7001eob9nrnrllp8f	cmsgi62jh001cob9n63fk9rwv	confirmed	2026-08-05 19:51:33.412
cmsgi8q20001pob9nzimo3dfi	cmsgi8q20001oob9ndikhokb0	pending	2026-08-05 19:53:34.438
cmsgi8t17001qob9nvlcvc9r6	cmsgi8q20001oob9ndikhokb0	confirmed	2026-08-05 19:53:38.297
cmsgia4y60021ob9n2whhm70t	cmsgia4y60020ob9n7ue5ub66	pending	2026-08-05 19:54:40.395
cmsgia6y10022ob9nmyfna0bo	cmsgia4y60020ob9n7ue5ub66	confirmed	2026-08-05 19:54:42.982
cmsglwoak002iob9n7pexjvz9	cmsglwoak002hob9napjtx8b9	pending	2026-08-05 21:36:10.746
cmsglx9pn002job9nizhtxw8w	cmsglwoak002hob9napjtx8b9	confirmed	2026-08-05 21:36:38.503
cmsgma8770003ob9syn2u6vxe	cmsgma8770002ob9spaefubp8	pending	2026-08-05 21:46:43.069
cmsgmc3fm0004ob9sfamtw4d0	cmsgma8770002ob9spaefubp8	confirmed	2026-08-05 21:48:10.207
cmsgmqmad000iob9so520bx4z	cmsgma8770002ob9spaefubp8	cancelled	2026-08-05 21:59:27.821
cmsgmvzja000pob9stz7mw2zt	cmsglwoak002hob9napjtx8b9	cancelled	2026-08-05 22:03:38.269
cmsgn6o4s001fob9s8014j33h	cmsgia4y60020ob9n7ue5ub66	cancelled	2026-08-05 22:11:56.706
cmsh7n8wd001oob9s41dj3w7i	cmsh7n8wc001nob9s4bi0oyce	pending	2026-08-06 07:44:42.438
cmsh7nhjf001vob9s8p6irfrx	cmsh7n8wc001nob9s4bi0oyce	driver_assigned	2026-08-06 07:44:53.644
cmsh9xxzp0003ob9n9nrf124a	cmsh9xxzp0002ob9nrmdfq0sx	pending	2026-08-06 08:49:00.753
cmsh9y3860004ob9n0b39ccal	cmsh9xxzp0002ob9nrmdfq0sx	confirmed	2026-08-06 08:49:07.539
cmsh9zgna000dob9n5eb9cmmi	cmsh9xxzp0002ob9nrmdfq0sx	driver_assigned	2026-08-06 08:50:11.59
cmsh9zxzu000gob9nhpzo2oja	cmsh7n8wc001nob9s4bi0oyce	driver_accepted	2026-08-06 08:50:34.075
cmsha0y6e000lob9ndnihjelv	cmsh9xxzp0002ob9nrmdfq0sx	driver_accepted	2026-08-06 08:51:20.966
cmsha19nv000qob9neaitcta2	cmsh9xxzp0002ob9nrmdfq0sx	arrived	2026-08-06 08:51:35.852
cmsha1c8d000wob9nrvhx2095	cmsh9xxzp0002ob9nrmdfq0sx	completed	2026-08-06 08:51:39.182
cmshako2o0015ob9neowwk52c	cmshako2o0014ob9n60b6qapc	pending	2026-08-06 09:06:40.989
cmshako3p0019ob9n90nso0wy	cmshako3p0018ob9nf6v8z4vg	pending	2026-08-06 09:06:41.028
cmshako4r001dob9n7x4mccbf	cmshako4r001cob9nmxua3ks0	pending	2026-08-06 09:06:41.066
cmshakq4a001hob9n0jiphbdq	cmshakq4a001gob9n52b00yjo	pending	2026-08-06 09:06:43.641
cmshcon1u001job9n41py65qe	cmsghzq5d0010ob9n1qn6qmls	driver_assigned	2026-08-06 10:05:45.522
cmshcpl5k001mob9n0770pmxs	cmsghzq5d0010ob9n1qn6qmls	driver_accepted	2026-08-06 10:06:29.72
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, name, email, phone, "createdAt", "updatedAt", "stripeCustomerId") FROM stdin;
cmry2z9cz0026lkbnkjx83r9a	James Whitfield	j.whitfield@example.com	+44 7700 900123	2026-07-23 22:26:27.491	2026-07-23 22:26:27.491	\N
cmry2z9dl002dlkbnqwpt96p3	Anna Kowalski	anna.k@example.com	+48 512 345 678	2026-07-23 22:26:27.513	2026-07-23 22:26:27.513	\N
cmry2z9e6002qlkbn5g6cibd6	Diego Fernández	d.fernandez@example.com	+34 600 112 233	2026-07-23 22:26:27.534	2026-07-23 22:26:27.534	\N
cmry2z9es003alkbnmjeixgp1	Priya Nair	priya.nair@example.com	+91 98200 45678	2026-07-23 22:26:27.556	2026-07-23 22:26:27.556	\N
cmry2z9f6003klkbnk0gb66b7	Robert Chen	r.chen@example.com	+1 415 555 0198	2026-07-23 22:26:27.57	2026-07-23 22:26:27.57	\N
cmry2z9fs0046lkbnvd992sjw	Marie Dubois	m.dubois@example.com	+33 6 12 34 56 78	2026-07-23 22:26:27.593	2026-07-23 22:26:27.593	\N
cmry2z9g6004flkbn3xc5issy	Tomasz Nowak	t.nowak@example.com	+48 601 234 567	2026-07-23 22:26:27.606	2026-07-23 22:26:27.606	\N
cmry2z9gj004plkbnxaqmhcoy	Olivia Brown	o.brown@example.com	+61 400 123 456	2026-07-23 22:26:27.619	2026-07-23 22:26:27.619	\N
cmry2z9gw0050lkbnoemyii3q	Hiroshi Tanaka	h.tanaka@example.com	+81 90 1234 5678	2026-07-23 22:26:27.632	2026-07-23 22:26:27.632	\N
cmry2z9h70057lkbnckag99kg	Elena Marku	elena.marku@example.com	+355 69 812 3344	2026-07-23 22:26:27.643	2026-07-23 22:26:27.643	\N
cmsglwo9k002fob9nle2dkrd4	Flow Tester	test.flow.booking@example.com	+355691111113	2026-08-05 21:36:10.692	2026-08-05 21:36:10.692	\N
cmsh7n8ua001lob9ss90o7895	Alket Shyti	alket.shyti@gmail.com	+355683256010	2026-08-06 07:44:42.365	2026-08-06 08:49:00.686	\N
cmshako1w0012ob9n0r6x68m7	QA Booker	qa-booker-1786007200-b7_no_passenger_email@example.com	+355681234567	2026-08-06 09:06:40.964	2026-08-06 09:06:40.964	\N
cmshako3d0016ob9nw4ojvpw6	QA Booker	qa-booker-1786007200-b8_with_passenger_email@example.com	+355681234567	2026-08-06 09:06:41.017	2026-08-06 09:06:41.017	\N
cmshako4f001aob9nk9fo4k6c	QA Booker	qa-booker-1786007200-b9_strip_passenger@example.com	+355681234567	2026-08-06 09:06:41.056	2026-08-06 09:06:41.056	\N
cmshakq2d001eob9nz78wsaec	QA Booker	qa-booker-1786007200-e13_normal@example.com	+355681234567	2026-08-06 09:06:43.572	2026-08-06 09:06:43.572	\N
cmryq5lgp0000lk9kee4bgiho	Alket Shyti	shytialket@gmail.com	+3550683256010	2026-07-24 09:15:14.28	2026-08-06 13:39:59.512	cus_UwYIZTY3RCGTCH
\.


--
-- Data for Name: Driver; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Driver" (id, name, phone, "whatsappNumber", "vehicleMake", "vehicleModel", "plateNumber", "vehicleType", languages, vetted, active, "avgRating", "createdAt", "updatedAt", "pinHash") FROM stdin;
cmry2z9co0021lkbnff8hob7u	Ergys Hoxha	+355 69 201 3344	+355 69 201 3344	Toyota	Corolla	TR 452 AB	sedan	{Albanian,English,Italian}	t	t	4.9	2026-07-23 22:26:27.481	2026-07-23 22:26:27.481	\N
cmry2z9co0022lkbnmiy73yto	Besnik Dervishi	+355 67 440 2211	+355 67 440 2211	Volkswagen	Caravelle	DR 903 LM	minivan	{Albanian,English,Greek}	t	t	4.7	2026-07-23 22:26:27.481	2026-07-23 22:26:27.481	\N
cmry2z9co0024lkbnu8ikchbu	Elira Gjoka	+355 69 550 7788	+355 69 550 7788	Mercedes-Benz	V-Class	VL 224 XY	minivan	{Albanian,English,Italian}	t	t	4.8	2026-07-23 22:26:27.481	2026-07-23 22:26:27.481	\N
cmry2z9co0025lkbn0ry329so	Gentian Muça	+355 68 990 1144	+355 68 990 1144	Mercedes-Benz	S-Class	TR 701 PM	sedan	{Albanian,English,French}	t	t	5	2026-07-23 22:26:27.481	2026-07-24 08:31:01.76	\N
cmry2z9co0023lkbnuo6p7xma	Ana Krasniqi	+355 68 778 9901	+355 68 778 9901	Skoda	Superb	TR 118 CK	sedan	{Albanian,English,German}	t	t	0	2026-07-23 22:26:27.481	2026-08-05 19:16:12.12	$2b$12$YlX8rtCASaEILmv95PXZfOHP.146xtQTTvrQECanSk/RPR9bQGsAi
\.


--
-- Data for Name: FlightStatusEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FlightStatusEvent" (id, "bookingId", "flightNumber", status, "scheduledAt", "observedAt", "delayMinutes", source, "createdAt") FROM stdin;
cmry2z9ev003flkbnohxzx4fm	cmry2z9ev003clkbnqx8ps17f	BA2592	scheduled	2026-07-28 11:00:00	2026-07-23 22:26:27.558	0	flightapi	2026-07-23 22:26:27.559
cmry2z9f8003vlkbn9nsd5mk3	cmry2z9f8003mlkbn40w729kf	KL1611	on_time	2026-07-27 16:45:00	2026-07-23 22:26:27.572	0	flightapi	2026-07-23 22:26:27.573
cmry2z9fv004alkbnpz8c3r46	cmry2z9fv0048lkbn7uoyzc0r	IB3251	scheduled	2026-07-29 08:00:00	2026-07-23 22:26:27.595	0	flightapi	2026-07-23 22:26:27.595
cmry2z9gz0054lkbnmh4t0isb	cmry2z9gy0052lkbna03aqxa2	QR0127	on_time	2026-07-26 13:20:00	2026-07-23 22:26:27.634	0	flightapi	2026-07-23 22:26:27.635
\.


--
-- Data for Name: MediaAsset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MediaAsset" (id, url, filename, "mimeType", "sizeBytes", title, description, alt, "createdAt", "updatedAt") FROM stdin;
cms8qboya0000lk9kho2iv4sa	/uploads/pages/r-5.webp	R (5).webp	image/webp	506012	R (5)			2026-07-31 09:17:40.493	2026-07-31 09:17:40.493
cmset2pp80004ob8sur92svrg	/uploads/pages/drivers-avaible.jpg	drivers-avaible.jpg	image/jpeg	291381	drivers avaible			2026-08-04 15:21:17.467	2026-08-04 15:21:17.467
\.


--
-- Data for Name: NotificationLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NotificationLog" (id, "bookingId", "customerId", channel, type, status, recipient, subject, body, "sentAt", "errorMessage", "createdAt") FROM stdin;
cmry2z9f3003jlkbnpzvx1oyo	cmry2z9ev003clkbnqx8ps17f	cmry2z9es003alkbnmjeixgp1	email	confirmation	sent	priya.nair@example.com	Booking confirmed — TRF-5KD0ZE	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.567
cmry2z9fn0043lkbn42gf3qas	cmry2z9f8003mlkbn40w729kf	cmry2z9f6003klkbnk0gb66b7	email	confirmation	sent	r.chen@example.com	Booking confirmed — TRF-9WP3LQ	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.587
cmry2z9fq0045lkbn0vfiayja	cmry2z9f8003mlkbn40w729kf	cmry2z9f6003klkbnk0gb66b7	whatsapp	driver_assigned	sent	+1 415 555 0198	\N	Your driver Gentian Muça has been assigned.	2026-07-22 11:00:00	\N	2026-07-23 22:26:27.59
cmry2z9g3004elkbnpt93cyhy	cmry2z9fv0048lkbn7uoyzc0r	cmry2z9fs0046lkbnvd992sjw	email	confirmation	sent	m.dubois@example.com	Booking confirmed — TRF-1AB6YT	Your transfer from Liro Hotel, Rruga e Butrintit, Ksamil is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.604
cmry2z9h40056lkbnme9wvmzf	cmry2z9gy0052lkbna03aqxa2	cmry2z9gw0050lkbnoemyii3q	email	confirmation	sent	h.tanaka@example.com	Booking confirmed — TRF-3ZX5PL	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.64
cmry2z9dg002clkbnv8pcup0g	\N	cmry2z9cz0026lkbnkjx83r9a	email	confirmation	sent	j.whitfield@example.com	Booking confirmed — TRF-8F3K2A	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.508
cmryq62wq000clk9kdd0yj1nt	cmryq5lhv0002lk9ks26z915e	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	alket.shyti@gmail.com	New booking — TRF-8F4E7E	New booking TRF-8F4E7E\n\nCustomer: Alket Shyti (shytialket@gmail.com, +355683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Fri 24 Jul, 11:10\nTotal: €65.00\n\nOpen: https://yin-dealt-citadel.ngrok-free.dev/admin/bookings?bookingId=cmryq5lhv0002lk9ks26z915e	2026-07-24 09:15:37.632	\N	2026-07-24 09:15:36.89
cmryq62wq000blk9kf3zz68y1	cmryq5lhv0002lk9ks26z915e	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-8F4E7E	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-8F4E7E\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Fri 24 Jul, 11:10\nTotal: €65.00\nPaid: €19.50\nBalance due: €45.50\n\nCancellation: Cancelling forfeits the deposit paid — it is not refunded. The remaining balance is never charged. If a driver fails to show or the service is not delivered, contact support for a full refund.\n\nManage: https://yin-dealt-citadel.ngrok-free.dev/my-booking\n+355 68 325 6010 · alket.shyti@gmail.com	2026-07-24 09:15:37.63	\N	2026-07-24 09:15:36.89
cmryq8z53000klk9k3uaccc67	cmryq5lhv0002lk9ks26z915e	cmryq5lgp0000lk9kee4bgiho	email	driver_assigned	sent	shytialket@gmail.com	Driver assigned — TRF-8F4E7E	Hi Alket Shyti,\nYour driver for TRF-8F4E7E is Ana Krasniqi.\nPhone: +355 68 778 9901\nWhatsApp: +355 68 778 9901\nVehicle: Skoda Superb\nPlate: TR 118 CK\nPickup: Fri 24 Jul, 11:10\nTirana International (TIA) → Berat\nMeet pin: 766134\nManage: https://yin-dealt-citadel.ngrok-free.dev/my-booking\n+355 68 325 6010 · alket.shyti@gmail.com	2026-07-24 09:17:52.495	\N	2026-07-24 09:17:51.975
cmryq99v7000vlk9k01h6ugxx	cmryq5lhv0002lk9ks26z915e	cmryq5lgp0000lk9kee4bgiho	email	completed_receipt	sent	shytialket@gmail.com	Trip completed — TRF-8F4E7E	Hi Alket Shyti,\n\nThanks for riding with Landed in Albania.\nTrip TRF-8F4E7E is complete.\n\nRoute: Tirana International (TIA) → Berat\nWhen: Fri 24 Jul, 11:10\nTotal: €65.00\nPaid: €65.00\nBalance due: €0.00\nPayment status: Paid in Full\n\n+355 68 325 6010 · alket.shyti@gmail.com	2026-07-24 09:18:06.386	\N	2026-07-24 09:18:05.875
cmryqtxhe0001lkvd3slqqhxd	cmryq5lhv0002lk9ks26z915e	cmryq5lgp0000lk9kee4bgiho	email	review_request	sent	shytialket@gmail.com	How was your trip? — TRF-8F4E7E	Hi Alket Shyti,\n\nThanks for riding with Landed in Albania.\nWe'd love your feedback on trip TRF-8F4E7E.\n\nRate your driver and overall experience (about 1 minute):\nhttps://yin-dealt-citadel.ngrok-free.dev/review?reference=TRF-8F4E7E&email=shytialket%40gmail.com\n\nReference: TRF-8F4E7E\nEmail: shytialket@gmail.com\n\n+355 68 325 6010 · alket.shyti@gmail.com	2026-07-24 09:34:10.139	\N	2026-07-24 09:34:09.603
cmry2z9gg004olkbnnw55zl2t	\N	cmry2z9g6004flkbn3xc5issy	email	confirmation	sent	t.nowak@example.com	Booking confirmed — TRF-4RT8NM	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.616
cmry2z9gt004zlkbnpycgiqec	\N	cmry2z9gj004plkbnxaqmhcoy	email	confirmation	sent	o.brown@example.com	Booking confirmed — TRF-6QC2WD	Your transfer from Guesthouse Theth, Theth Village, Shkodër County is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.63
cmry2z9em0037lkbnd034xkpa	\N	cmry2z9e6002qlkbn5g6cibd6	email	confirmation	sent	d.fernandez@example.com	Booking confirmed — TRF-7HH4RC	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.551
cmry2z9ep0039lkbnh0bpdiam	\N	cmry2z9e6002qlkbn5g6cibd6	whatsapp	driver_assigned	sent	+34 600 112 233	\N	Your driver Ana Krasniqi has been assigned.	2026-07-22 11:00:00	\N	2026-07-23 22:26:27.554
cmry2z9hi005hlkbn0pe6xb42	\N	cmry2z9h70057lkbnckag99kg	email	confirmation	sent	elena.marku@example.com	Booking confirmed — TRF-0PL8VN	Your transfer from Tirana International Airport (TIA), Arrivals Hall is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.654
cmry2z9hl005jlkbnznl58j1s	\N	cmry2z9h70057lkbnckag99kg	whatsapp	driver_assigned	sent	+355 69 812 3344	\N	Your driver Ergys Hoxha has been assigned.	2026-07-22 11:00:00	\N	2026-07-23 22:26:27.657
cmry2z9dz002nlkbn8y9y1xtt	\N	cmry2z9dl002dlkbnqwpt96p3	email	confirmation	sent	anna.k@example.com	Booking confirmed — TRF-2M9QP1	Your transfer from Hotel Adriatik, Rruga Pavaresia, Durrës is confirmed.	2026-07-22 10:00:00	\N	2026-07-23 22:26:27.528
cmry2z9e2002plkbnk6d30jk2	\N	cmry2z9dl002dlkbnqwpt96p3	whatsapp	driver_assigned	sent	+48 512 345 678	\N	Your driver Besnik Dervishi has been assigned.	2026-07-22 11:00:00	\N	2026-07-23 22:26:27.531
cmryr4gvk0001lk9vv9g45r8a	cmryq5lhv0002lk9ks26z915e	cmryq5lgp0000lk9kee4bgiho	email	review_submitted	sent	alket.shyti@gmail.com	New review — TRF-8F4E7E	New review for TRF-8F4E7E\nCustomer: Alket Shyti (shytialket@gmail.com)\nDriver: Ana Krasniqi\nDriver rating: 5/5\nPlatform rating: 5/5\nDriver comment: Driver was very helpful. We had an amaizing time\nPlatform comment: Very Good\nStatus: approved (awaiting moderation)\nModerate: https://yin-dealt-citadel.ngrok-free.dev/admin/reviews?status=pending\nBooking: https://yin-dealt-citadel.ngrok-free.dev/admin/bookings?bookingId=cmryq5lhv0002lk9ks26z915e	2026-07-24 09:42:21.906	\N	2026-07-24 09:42:21.297
cmsbxb227000clk9moaf5xib7	cmsbxadu80002lk9mimqt3zhu	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	alket.shyti@gmail.com	New booking — TRF-64F5CC	New booking TRF-64F5CC\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nPickup: Tirana International (TIA)\nDrop-off: Durrës\nWhen: Tue 25 Aug, 17:55\nTotal: €48.00\n\nOpen: https://yin-dealt-citadel.ngrok-free.dev/admin/bookings?bookingId=cmsbxadu80002lk9mimqt3zhu	2026-08-02 14:56:27.438	\N	2026-08-02 14:56:26.671
cmsbxb227000blk9m8maesum9	cmsbxadu80002lk9mimqt3zhu	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-64F5CC	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-64F5CC\nPickup: Tirana International (TIA)\nDrop-off: Durrës\nWhen: Tue 25 Aug, 17:55\nTotal: €48.00\nPaid: €48.00\nBalance due: €0.00\n\nCancellation: Cancelling forfeits the deposit paid — it is not refunded. The remaining balance is never charged. If a driver fails to show or the service is not delivered, contact support for a full refund.\n\nManage: https://yin-dealt-citadel.ngrok-free.dev/my-booking\n+355 68 325 6010 · alket.shyti@gmail.com	2026-08-02 14:56:27.447	\N	2026-08-02 14:56:26.671
cmseg1wp8000clk9yzey4wshv	cmseg1f6o0002lk9ycdorsq5t	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	alket.shyti@gmail.com	New booking — TRF-B3EA2F	New booking TRF-B3EA2F\n\nCustomer: Alket Shyti (shytialket@gmail.com, +355683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Wed 19 Aug, 12:15\nTotal: €55.00\n\nOpen: https://yin-dealt-citadel.ngrok-free.dev/admin/bookings?bookingId=cmseg1f6o0002lk9ycdorsq5t	2026-08-04 09:16:45.622	\N	2026-08-04 09:16:44.877
cmseg1wp8000alk9yjvvx8p0o	cmseg1f6o0002lk9ycdorsq5t	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-B3EA2F	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-B3EA2F\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Wed 19 Aug, 12:15\nTotal: €55.00\nPaid: €55.00\nBalance due: €0.00\n\nCancellation: Cancelling forfeits the deposit paid — it is not refunded. The remaining balance is never charged. If a driver fails to show or the service is not delivered, contact support for a full refund.\n\nManage: https://yin-dealt-citadel.ngrok-free.dev/my-booking\n+355 68 325 6010 · alket.shyti@gmail.com	2026-08-04 09:16:45.658	\N	2026-08-04 09:16:44.876
cmshdqh0m006aob9nvx97uums	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR7FE9	Booking TRF-QR7FE9 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-66baae2d@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b26534eda53a6175590d8acbc	2026-08-06 10:35:10.892	id=<7ad1e7e1-4e46-a67f-ca35-9084d991a3ff@landedalbania.com> · smtp=250 OK id=1wrvRP-00000006sb9-3FNL	2026-08-06 10:35:10.63
cmsegbg0i000nlk9y99ctfup6	cmsegazvq000flk9y9izogwfm	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-AC13AA	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-AC13AA\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Wed 12 Aug, 12:20\nTotal: €65.00\nPaid: €65.00\nBalance due: €0.00\n\nCancellation: Cancelling forfeits the deposit paid — it is not refunded. The remaining balance is never charged. If a driver fails to show or the service is not delivered, contact support for a full refund.\n\nManage: https://yin-dealt-citadel.ngrok-free.dev/my-booking\n+355 68 325 6010 · alket.shyti@gmail.com	2026-08-04 09:24:10.59	\N	2026-08-04 09:24:09.81
cmsegbgmx000plk9yux4zyf2l	cmsegazvq000flk9y9izogwfm	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	alket.shyti@gmail.com	New booking — TRF-AC13AA	New booking TRF-AC13AA\n\nCustomer: Alket Shyti (shytialket@gmail.com, +35568325010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Wed 12 Aug, 12:20\nTotal: €65.00\n\nOpen: https://yin-dealt-citadel.ngrok-free.dev/admin/bookings?bookingId=cmsegazvq000flk9y9izogwfm	2026-08-04 09:24:10.975	\N	2026-08-04 09:24:10.617
cmsghkqmh0009ob9nlat2tyob	cmsghk9jx0002ob9nnqy7ctx2	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-2A1926	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-2A1926\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 06 Aug, 22:30\nTotal: €55.00\nPaid: €0.00\nBalance due: €55.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:34:56.122	id=<8fd0055d-5631-8b7a-c5b7-256ed0f19949@landedalbania.com> · smtp=250 OK id=1wrhOC-00000008Egp-1jss	2026-08-05 19:34:55.434
cmsghkr6v000bob9ne9921tic	cmsghk9jx0002ob9nnqy7ctx2	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	support@landedalbania.com	New booking — TRF-2A1926	New booking TRF-2A1926\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 06 Aug, 22:30\nTotal: €55.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsghk9jx0002ob9nnqy7ctx2	2026-08-05 19:34:56.539	id=<e9b7771b-f420-76bf-fc54-5a084dda1506@landedalbania.com> · smtp=250 OK id=1wrhOC-00000008Egp-38SE	2026-08-05 19:34:56.168
cmsghn3y4000job9nudrakrda	cmsghk9jx0002ob9nnqy7ctx2	cmryq5lgp0000lk9kee4bgiho	email	driver_assigned	sent	shytialket@gmail.com	Driver assigned — TRF-2A1926	Hi Alket Shyti,\nYour driver for TRF-2A1926 is Ana Krasniqi.\nPhone: +355 68 778 9901\nWhatsApp: +355 68 778 9901\nVehicle: Skoda Superb\nPlate: TR 118 CK\nPickup: Thu 06 Aug, 22:30\nTirana International (TIA) → Berat\nMeet pin: 082564\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:36:46.588	id=<a4c518a9-7c3e-d86a-c058-33eb7dac5cb4@landedalbania.com> · smtp=250 OK id=1wrhPz-00000008H0y-0aM1	2026-08-05 19:36:46.012
cmsghvkhd000uob9nvvv8ezla	cmsghk9jx0002ob9nnqy7ctx2	cmryq5lgp0000lk9kee4bgiho	email	completed_receipt	sent	shytialket@gmail.com	Trip completed — TRF-2A1926	Hi Alket Shyti,\n\nThanks for riding with Landed in Albania.\nTrip TRF-2A1926 is complete.\n\nRoute: Tirana International (TIA) → Berat\nWhen: Thu 06 Aug, 22:30\nTotal: €55.00\nPaid: €55.00\nBalance due: €0.00\nPayment status: Paid in Full\n\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:43:21.3	id=<9269ff65-8a06-3333-3434-66ab544085a6@landedalbania.com> · smtp=250 OK id=1wrhWL-00000008Mqr-2Kfc	2026-08-05 19:43:20.689
cmsghvkz3000wob9n7q7xb1i7	cmsghk9jx0002ob9nnqy7ctx2	cmryq5lgp0000lk9kee4bgiho	email	review_request	sent	shytialket@gmail.com	How was your trip? — TRF-2A1926	Hi Alket Shyti,\n\nThanks for riding with Landed in Albania.\nWe'd love your feedback on trip TRF-2A1926.\n\nRate your driver and overall experience (about 1 minute):\nhttps://landedalbania.com/review?reference=TRF-2A1926&email=shytialket%40gmail.com\n\nReference: TRF-2A1926\nEmail: shytialket@gmail.com\n\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:43:21.6	id=<901d42cf-a4dc-dfc2-eabe-361271068ee8@landedalbania.com> · smtp=250 OK id=1wrhWL-00000008Mqr-3fKa	2026-08-05 19:43:21.327
cmsgi0nq30017ob9n2uyk1mpp	cmsghzq5d0010ob9n1qn6qmls	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-3B6A17	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-3B6A17\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 06 Aug, 22:45\nTotal: €55.00\nPaid: €0.00\nBalance due: €55.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:47:18.718	id=<319a9a8d-8788-692e-ee6a-8e0c6848dc86@landedalbania.com> · smtp=250 OK id=1wrhaB-00000008Rln-1BQ7	2026-08-05 19:47:18.172
cmsh7n94j001rob9sqxn9i9d1	cmsh7n8wc001nob9s4bi0oyce	cmsh7n8ua001lob9ss90o7895	email	confirmation	sent	alket.shyti@gmail.com	Booking confirmed — TRF-337692	Hi Alket,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-337692\nPickup PIN: 941651\nPickup: Tirana International (TIA)\nDrop-off: Durrës\nWhen: Thu 06 Aug, 14:44\nVehicle: Sedan\nPassengers: 2\nLuggage: 2\nTotal: €38.00\nPaid: €0.00\nBalance due: €26.60\n\nCancellation: Cancelling forfeits the deposit paid — it is not refunded. The remaining balance is never charged. If a driver fails to show or the service is not delivered, contact support for a full refund.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 07:44:43.423	id=<37059ed0-8823-c8be-91f6-0c97dc9950d4@landedalbania.com> · smtp=250 OK id=1wrsmR-00000003ZIW-3qM2	2026-08-06 07:44:42.74
cmsgi0o5w0019ob9nthfo2qz0	cmsghzq5d0010ob9n1qn6qmls	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	support@landedalbania.com	New booking — TRF-3B6A17	New booking TRF-3B6A17\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 06 Aug, 22:45\nTotal: €55.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsghzq5d0010ob9n1qn6qmls	2026-08-05 19:47:18.998	id=<0de2a217-9088-ab78-775e-5bc1d1e662e2@landedalbania.com> · smtp=250 OK id=1wrhaB-00000008Rln-2RpV	2026-08-05 19:47:18.741
cmsgi64p5001job9nnmfpshsg	cmsgi62jh001cob9n63fk9rwv	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-524530	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-524530\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 13 Aug, 22:50\nTotal: €55.00\nPaid: €0.00\nBalance due: €55.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:51:34.022	id=<d6b55060-2f11-d79b-2949-47d8dca58e58@landedalbania.com> · smtp=250 OK id=1wrheI-00000008VkV-0awH	2026-08-05 19:51:33.449
cmsh7n9o5001tob9sboyx4go0	cmsh7n8wc001nob9s4bi0oyce	cmsh7n8ua001lob9ss90o7895	email	confirmation	sent	support@landedalbania.com	New booking — TRF-337692	New booking TRF-337692\n\nCustomer: Alket (alket.shyti@gmail.com, +355683256010)\nReference: TRF-337692\nPickup PIN: 941651\nPickup: Tirana International (TIA)\nDrop-off: Durrës\nWhen: Thu 06 Aug, 14:44\nVehicle: Sedan\nPassengers: 2\nLuggage: 2\nTotal: €38.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsh7n8wc001nob9s4bi0oyce	2026-08-06 07:44:43.707	id=<aa5987cf-7ddd-f72e-8269-208e4254cab6@landedalbania.com> · smtp=250 OK id=1wrsmS-00000003ZIW-0sPu	2026-08-06 07:44:43.445
cmsgi655q001lob9nd8xd2r7m	cmsgi62jh001cob9n63fk9rwv	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	support@landedalbania.com	New booking — TRF-524530	New booking TRF-524530\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 13 Aug, 22:50\nTotal: €55.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgi62jh001cob9n63fk9rwv	2026-08-05 19:51:34.313	id=<3b56b8f6-1dbd-af62-bffe-49deebfb59a7@landedalbania.com> · smtp=250 OK id=1wrheI-00000008VkV-1umO	2026-08-05 19:51:34.046
cmsh9y3w2000bob9ncwprxlhr	cmsh9xxzp0002ob9nrmdfq0sx	cmsh7n8ua001lob9ss90o7895	email	confirmation	sent	support@landedalbania.com	New booking — TRF-DF371C	New booking TRF-DF371C\n\nCustomer: Alket Shyti (alket.shyti@gmail.com, +355683256010)\nReference: TRF-DF371C\nPickup PIN: 025433\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 13 Aug, 11:45\nFlight: AB1235\nVehicle: Sedan\nPassengers: 1\nLuggage: 0\nPassenger: Elisjon Shyti\nPassenger email: shytialket@gmail.com\nPassenger phone: +355692356010\nBooker relation: Family or friend\nTotal: €65.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	2026-08-06 08:49:08.674	id=<f4f3e02f-9918-c473-3d1f-a720dd78ee4b@landedalbania.com> · smtp=250 OK id=1wrtmn-00000004nVx-1kDP	2026-08-06 08:49:08.403
cmsgi8t2a001vob9n85di3ibe	cmsgi8q20001oob9ndikhokb0	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-8CAEC0	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-8CAEC0\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 06 Aug, 22:50\nTotal: €55.00\nPaid: €0.00\nBalance due: €55.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:53:38.912	id=<d9ea8ed8-7f6b-ce02-f561-ecbbea156b69@landedalbania.com> · smtp=250 OK id=1wrhgJ-00000008XWN-3h64	2026-08-05 19:53:38.339
cmsha0y7k000oob9nr5z988g5	cmsh9xxzp0002ob9nrmdfq0sx	cmsh7n8ua001lob9ss90o7895	email	driver_assigned	sent	alket.shyti@gmail.com	Driver assigned — TRF-DF371C	Hi Alket Shyti,\nYour driver for TRF-DF371C is Ana Krasniqi.\nPhone: +355 68 778 9901\nWhatsApp: +355 68 778 9901\nVehicle: Skoda Superb\nPlate: TR 118 CK\nPickup: Thu 13 Aug, 11:45\nTirana International (TIA) → Berat\nPickup PIN: 025433\nPassengers: 1\nLuggage: 0\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 08:51:21.559	id=<089bb026-f1dd-f798-9bb3-5e6c6dd8b0b9@landedalbania.com> · smtp=250 OK id=1wrtow-00000004q2V-1iqM	2026-08-06 08:51:21.009
cmsgi8tis001xob9nqonww144	cmsgi8q20001oob9ndikhokb0	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	support@landedalbania.com	New booking — TRF-8CAEC0	New booking TRF-8CAEC0\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 06 Aug, 22:50\nTotal: €55.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgi8q20001oob9ndikhokb0	2026-08-05 19:53:39.199	id=<fae26908-63d6-99ee-7575-61f585d89cde@landedalbania.com> · smtp=250 OK id=1wrhgK-00000008XWN-0jWP	2026-08-05 19:53:38.932
cmsha1c97000zob9ngqmjcaw2	cmsh9xxzp0002ob9nrmdfq0sx	cmsh7n8ua001lob9ss90o7895	email	completed_receipt	sent	alket.shyti@gmail.com	Trip completed — TRF-DF371C	Hi Alket Shyti,\n\nThanks for riding with Landed in Albania.\nTrip TRF-DF371C is complete.\n\nRoute: Tirana International (TIA) → Berat\nWhen: Thu 13 Aug, 11:45\nTotal: €65.00\nPaid: €65.00\nBalance due: €0.00\nPayment status: Paid in Full\n\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 08:51:39.477	id=<aa1f58c9-9b44-b349-3481-a57566df8946@landedalbania.com> · smtp=250 OK id=1wrtpD-00000004q2V-37Aj	2026-08-06 08:51:39.211
cmsgia6z20027ob9njsfmybhx	cmsgia4y60020ob9n7ue5ub66	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-233B8F	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-233B8F\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 13 Aug, 22:50\nTotal: €55.00\nPaid: €0.00\nBalance due: €55.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 19:54:43.541	id=<bd0d5495-4c89-d518-860e-d606a0b55fe0@landedalbania.com> · smtp=250 OK id=1wrhhM-00000008YHW-1qg2	2026-08-05 19:54:43.022
cmsgia7e20029ob9nd4gxyper	cmsgia4y60020ob9n7ue5ub66	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	support@landedalbania.com	New booking — TRF-233B8F	New booking TRF-233B8F\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 13 Aug, 22:50\nTotal: €55.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgia4y60020ob9n7ue5ub66	2026-08-05 19:54:43.813	id=<728f6a3e-363f-3fff-1527-074a4abe0681@landedalbania.com> · smtp=250 OK id=1wrhhM-00000008YHW-31p4	2026-08-05 19:54:43.562
cmsglx9vo002oob9nmslxx2oo	cmsglwoak002hob9napjtx8b9	cmsglwo9k002fob9nle2dkrd4	email	confirmation	failed	test.flow.booking@example.com	Booking confirmed — TRF-EAE09B	Hi Flow Tester,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-EAE09B\nPickup: Tirana International Airport (TIA), Arrivals\nDrop-off: Hotel Plaza Tirana, Rruga 28 Nentori\nWhen: Fri 07 Aug, 12:00\nTotal: €40.00\nPaid: €0.00\nBalance due: €40.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to test.flow.booking@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-05 21:36:38.725
cmsh9y3ew0009ob9n6vkpqnop	cmsh9xxzp0002ob9nrmdfq0sx	cmsh7n8ua001lob9ss90o7895	email	confirmation	sent	alket.shyti@gmail.com	Booking confirmed — TRF-DF371C	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-DF371C\nPickup PIN: 025433\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Thu 13 Aug, 11:45\nFlight: AB1235\nVehicle: Sedan\nPassengers: 1\nLuggage: 0\nPassenger: Elisjon Shyti\nPassenger email: shytialket@gmail.com\nPassenger phone: +355692356010\nBooker relation: Family or friend\nTotal: €65.00\nPaid: €0.00\nBalance due: €65.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 08:49:08.38	id=<7feebed7-e858-b622-d89b-7745ec4483cd@landedalbania.com> · smtp=250 OK id=1wrtmn-00000004nVx-0T59	2026-08-06 08:49:07.785
cmsglxahb002qob9n3tnkq6zf	cmsglwoak002hob9napjtx8b9	cmsglwo9k002fob9nle2dkrd4	email	confirmation	failed	test.flow.booking@example.com	Booking confirmed — TRF-EAE09B	Hi Flow Tester,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-EAE09B\nPickup: Tirana International Airport (TIA), Arrivals\nDrop-off: Hotel Plaza Tirana, Rruga 28 Nentori\nWhen: Fri 07 Aug, 12:00\nTotal: €40.00\nPaid: €0.00\nBalance due: €40.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to test.flow.booking@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-05 21:36:39.504
cmsglxat8002sob9ngdllhhoq	cmsglwoak002hob9napjtx8b9	cmsglwo9k002fob9nle2dkrd4	email	confirmation	sent	support@landedalbania.com	New booking — TRF-EAE09B	New booking TRF-EAE09B\n\nCustomer: Flow Tester (test.flow.booking@example.com, +355691111113)\nPickup: Tirana International Airport (TIA), Arrivals\nDrop-off: Hotel Plaza Tirana, Rruga 28 Nentori\nWhen: Fri 07 Aug, 12:00\nTotal: €40.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsglwoak002hob9napjtx8b9	2026-08-05 21:36:40.503	id=<f23c6abd-63a5-83f1-a6ae-503256fe34bf@landedalbania.com> · smtp=250 OK id=1wrjI0-0000000ALl5-2v9u	2026-08-05 21:36:39.932
cmsh9zy1b000job9nacluyaof	cmsh7n8wc001nob9s4bi0oyce	cmsh7n8ua001lob9ss90o7895	email	driver_assigned	sent	alket.shyti@gmail.com	Driver assigned — TRF-337692	Hi Alket Shyti,\nYour driver for TRF-337692 is Ana Krasniqi.\nPhone: +355 68 778 9901\nWhatsApp: +355 68 778 9901\nVehicle: Skoda Superb\nPlate: TR 118 CK\nPickup: Thu 06 Aug, 14:44\nTirana International (TIA) → Durrës\nPickup PIN: 941651\nPassengers: 2\nLuggage: 2\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 08:50:34.715	id=<271bd16a-a477-b306-2a7a-2bc3e203b36a@landedalbania.com> · smtp=250 OK id=1wrtoB-00000004pHn-0BXH	2026-08-06 08:50:34.127
cmsgmc3jp0009ob9sxgugzx82	cmsgma8770002ob9spaefubp8	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	shytialket@gmail.com	Booking confirmed — TRF-DF20A6	Hi Alket Shyti,\n\nYour transfer with Landed in Albania is confirmed.\n\nReference: TRF-DF20A6\nPickup PIN: 233264\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Fri 07 Aug, 00:45\nFlight: AB1235\nVehicle: Sedan\nPassengers: 1\nLuggage: 1\nTotal: €65.00\nPaid: €0.00\nBalance due: €65.00\n\nPayment: Pay the full amount in cash to your driver at pickup.\n\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 21:48:11.004	id=<7017bfb2-0536-9f7f-0197-db978b0043e7@landedalbania.com> · smtp=250 OK id=1wrjT8-0000000AXSd-3zVa	2026-08-05 21:48:10.357
cmsgmc42g000bob9s6pq6dx9w	cmsgma8770002ob9spaefubp8	cmryq5lgp0000lk9kee4bgiho	email	confirmation	sent	support@landedalbania.com	New booking — TRF-DF20A6	New booking TRF-DF20A6\n\nCustomer: Alket Shyti (shytialket@gmail.com, +3550683256010)\nReference: TRF-DF20A6\nPickup PIN: 233264\nPickup: Tirana International (TIA)\nDrop-off: Berat\nWhen: Fri 07 Aug, 00:45\nFlight: AB1235\nVehicle: Sedan\nPassengers: 1\nLuggage: 1\nTotal: €65.00\n\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgma8770002ob9spaefubp8	2026-08-05 21:48:11.344	id=<46d56068-0b3b-5bbd-cc77-026ab987719c@landedalbania.com> · smtp=250 OK id=1wrjT9-0000000AXSd-1Ird	2026-08-05 21:48:11.032
cmsgml0gv000eob9sb0zl4hgv	cmsgma8770002ob9spaefubp8	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-DF20A6	Hi Alket Shyti,\n\nYour pickup time for TRF-DF20A6 was changed.\nPrevious: Sat 08 Aug, 04:00\nNew: Sun 09 Aug, 09:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 21:55:06.922	id=<34f34489-f670-9916-14b9-033e89c1c5ec@landedalbania.com> · smtp=250 OK id=1wrjZr-0000000Ae1t-21ZQ	2026-08-05 21:55:06.272
cmsgml0gw000fob9sbe4lvy28	cmsgma8770002ob9spaefubp8	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	support@landedalbania.com	Date changed — TRF-DF20A6	Pickup time changed for TRF-DF20A6\nPrevious: Sat 08 Aug, 04:00\nNew: Sun 09 Aug, 09:00\nCustomer: Alket Shyti\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgma8770002ob9spaefubp8	2026-08-05 21:55:07.165	id=<9d6da5bb-540f-158c-da11-0ba3d0ed6a40@landedalbania.com> · smtp=250 OK id=1wrjZr-0000000Ae1t-37wx	2026-08-05 21:55:06.272
cmsgmqmb7000kob9syik1gqy9	cmsgma8770002ob9spaefubp8	cmryq5lgp0000lk9kee4bgiho	email	cancellation	sent	shytialket@gmail.com	Booking cancelled — TRF-DF20A6	Hi Alket Shyti,\n\nYour booking TRF-DF20A6 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: Tirana International (TIA) → Berat\nWhen: Sun 09 Aug, 09:00\n\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 21:59:28.397	id=<170900f1-056b-aeb3-d4ac-7674cd4dff2d@landedalbania.com> · smtp=250 OK id=1wrje4-0000000AhZv-3XaB	2026-08-05 21:59:27.86
cmsgmqmb8000mob9so4xuiynt	cmsgma8770002ob9spaefubp8	cmryq5lgp0000lk9kee4bgiho	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-DF20A6	Booking TRF-DF20A6 was cancelled (Deposit forfeited (no refund)).\nCustomer: Alket Shyti · shytialket@gmail.com\nWhen: Sun 09 Aug, 09:00\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgma8770002ob9spaefubp8	2026-08-05 21:59:28.641	id=<e4dd7d5d-e905-8cc0-7d8d-1203dcce4a95@landedalbania.com> · smtp=250 OK id=1wrje5-0000000AhZv-0Olk	2026-08-05 21:59:27.86
cmsgmvzlp000rob9sj89y9pvv	cmsglwoak002hob9napjtx8b9	cmsglwo9k002fob9nle2dkrd4	email	cancellation	failed	test.flow.booking@example.com	Booking cancelled — TRF-EAE09B	Hi Flow Tester,\n\nYour booking TRF-EAE09B has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: Tirana International Airport (TIA), Arrivals → Hotel Plaza Tirana, Rruga 28 Nentori\nWhen: Fri 07 Aug, 12:00\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to test.flow.booking@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-05 22:03:38.366
cmsgmvzlq000tob9s66mj3t87	cmsglwoak002hob9napjtx8b9	cmsglwo9k002fob9nle2dkrd4	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-EAE09B	Booking TRF-EAE09B was cancelled (Deposit forfeited (no refund)).\nCustomer: Flow Tester · test.flow.booking@example.com\nWhen: Fri 07 Aug, 12:00\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsglwoak002hob9napjtx8b9	2026-08-05 22:03:39.694	id=<bca4e9d6-1af1-4519-37bb-52d432a439a2@landedalbania.com> · smtp=250 OK id=1wrji7-0000000ApDt-2vuA	2026-08-05 22:03:38.366
cmsgn6eer000xob9sd0262lu9	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Wed 12 Aug, 15:25\nNew: Tue 01 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:45.686	id=<1f8a41ea-5c0f-bc62-ef0f-c2a8ca499e06@landedalbania.com> · smtp=250 OK id=1wrjpy-0000000AxCu-1qYA	2026-08-05 22:11:44.115
cmsgn6eer000yob9s23v3nsa4	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	support@landedalbania.com	Date changed — TRF-BE34B3	Pickup time changed for TRF-BE34B3\nPrevious: Wed 12 Aug, 15:25\nNew: Tue 01 Sept, 14:00\nCustomer: Alket Shyti\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsemsjqr0002ob8sq2rsiygn	2026-08-05 22:11:45.95	id=<f15642f3-5f52-4fcd-4040-7b2a362b28b7@landedalbania.com> · smtp=250 OK id=1wrjpy-0000000AxCu-2zMw	2026-08-05 22:11:44.115
cmsgn6eho0010ob9s46dqcqgq	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Tue 01 Sept, 14:00\nNew: Wed 02 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:46.201	id=<8ffe37ba-2137-30a4-bdc8-2e11800e4c39@landedalbania.com> · smtp=250 OK id=1wrjpy-0000000AxCu-47vj	2026-08-05 22:11:44.22
cmsgn6ek70012ob9ssqs76ugi	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Wed 02 Sept, 14:00\nNew: Thu 03 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:46.464	id=<e9c35b34-3e09-1f50-9600-0a92426cbaa6@landedalbania.com> · smtp=250 OK id=1wrjpz-0000000AxCu-10qD	2026-08-05 22:11:44.312
cmsgn6ena0014ob9s9muopg6t	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Thu 03 Sept, 14:00\nNew: Fri 04 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:46.733	id=<76fd0168-2955-60d0-8de7-cc3d2b61d1d1@landedalbania.com> · smtp=250 OK id=1wrjpz-0000000AxCu-2BrG	2026-08-05 22:11:44.422
cmsgn6eqd0016ob9sa09hdgs3	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Fri 04 Sept, 14:00\nNew: Sat 05 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:46.985	id=<8c06a002-5a55-d141-f503-a27256fbcd4d@landedalbania.com> · smtp=250 OK id=1wrjpz-0000000AxCu-3JtR	2026-08-05 22:11:44.533
cmsgn6et10018ob9smo3ke547	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Sat 05 Sept, 14:00\nNew: Sun 06 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:47.248	id=<4d83d1a5-8773-3ece-ce4b-b38630ec4717@landedalbania.com> · smtp=250 OK id=1wrjq0-0000000AxCu-0Cm0	2026-08-05 22:11:44.629
cmsgn6ew3001aob9sk5j7ixpb	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Sun 06 Sept, 14:00\nNew: Mon 07 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:47.511	id=<c4674d58-3152-7545-332b-74110286b7d0@landedalbania.com> · smtp=250 OK id=1wrjq0-0000000AxCu-1MKH	2026-08-05 22:11:44.739
cmsgn6f24001cob9smgbc87dp	cmsemsjqr0002ob8sq2rsiygn	cmryq5lgp0000lk9kee4bgiho	email	date_change	sent	shytialket@gmail.com	Pickup time updated — TRF-BE34B3	Hi Alket Shyti,\n\nYour pickup time for TRF-BE34B3 was changed.\nPrevious: Mon 07 Sept, 14:00\nNew: Tue 08 Sept, 14:00\n\nRoute: Tirana International (TIA) → Berat\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:47.764	id=<c57ce05c-a05f-ef3e-35ff-73627956f8c7@landedalbania.com> · smtp=250 OK id=1wrjq0-0000000AxCu-2Tyf	2026-08-05 22:11:44.956
cmsgn6o63001job9sl2xhjlfe	cmsgia4y60020ob9n7ue5ub66	cmryq5lgp0000lk9kee4bgiho	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-233B8F	Booking TRF-233B8F was cancelled (Deposit forfeited (no refund)).\nCustomer: Alket Shyti · shytialket@gmail.com\nWhen: Thu 13 Aug, 22:50\nOpen: https://landedalbania.com/admin/bookings?bookingId=cmsgia4y60020ob9n7ue5ub66	2026-08-05 22:11:57.044	id=<a8a643da-7863-e992-c546-087d7a9494c3@landedalbania.com> · smtp=250 OK id=1wrjq8-0000000AxCu-3jGw	2026-08-05 22:11:56.764
cmsgn6o63001hob9slm4qw09c	cmsgia4y60020ob9n7ue5ub66	cmryq5lgp0000lk9kee4bgiho	email	cancellation	sent	shytialket@gmail.com	Booking cancelled — TRF-233B8F	Hi Alket Shyti,\n\nYour booking TRF-233B8F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: Tirana International (TIA) → Berat\nWhen: Thu 13 Aug, 22:50\n\n+355 68 325 6010 · support@landedalbania.com	2026-08-05 22:11:57.33	id=<df6867bd-0954-33e0-5cc4-f9d1fee66e29@landedalbania.com> · smtp=250 OK id=1wrjq9-0000000AxCu-0csW	2026-08-05 22:11:56.763
cmsha1chg0011ob9ncmbs99in	cmsh9xxzp0002ob9nrmdfq0sx	cmsh7n8ua001lob9ss90o7895	email	review_request	sent	alket.shyti@gmail.com	How was your trip? — TRF-DF371C	Hi Alket Shyti,\n\nThanks for riding with Landed in Albania.\nWe'd love your feedback on trip TRF-DF371C.\n\nRate your driver and overall experience (about 1 minute):\nhttps://landedalbania.com/review?reference=TRF-DF371C&email=alket.shyti%40gmail.com\n\nReference: TRF-DF371C\nEmail: alket.shyti@gmail.com\n\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 08:51:39.918	id=<05f5e669-feaf-00ce-8749-8035fbbf6514@landedalbania.com> · smtp=250 OK id=1wrtpE-00000004q2V-0B6t	2026-08-06 08:51:39.508
cmshdqfs50061ob9nswpdsj7q	\N	\N	email	cancellation	failed	qa-race-4e9808e5@example.com	Booking cancelled — TRF-QR7897	Hi QA Race,\n\nYour booking TRF-QR7897 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-4e9808e5@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:09.029
cmshcpl7w001pob9nk7p4q9l7	cmsghzq5d0010ob9n1qn6qmls	cmryq5lgp0000lk9kee4bgiho	email	driver_assigned	sent	shytialket@gmail.com	Driver assigned — TRF-3B6A17	Hi Alket Shyti,\nYour driver for TRF-3B6A17 is Ana Krasniqi.\nPhone: +355 68 778 9901\nWhatsApp: +355 68 778 9901\nVehicle: Skoda Superb\nPlate: TR 118 CK\nPickup: Thu 06 Aug, 22:45\nTirana International (TIA) → Berat\nPickup PIN: 173348\nPassengers: 1\nLuggage: 0\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	2026-08-06 10:06:30.496	id=<4c45df85-7e65-e376-b078-68456cb5b8bb@landedalbania.com> · smtp=250 OK id=1wruze-00000006Gz0-3Oio	2026-08-06 10:06:29.803
cmshdohin001vob9nxzzh4ump	\N	\N	email	cancellation	failed	qa-selfsvc-opencancel@example.com	Booking cancelled — TRF-QA5649	Hi QA SelfService opencancel,\n\nYour booking TRF-QA5649 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA Airport → Durrës Center\nWhen: Sun 09 Aug, 12:33\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to\n550-qa-selfsvc-opencancel@example.com.  The account or domain may not exist,\n550 they may be blacklisted, or missing the proper dns entries.	2026-08-06 10:33:37.951
cmshdoikx001zob9nfgh3hdgz	\N	\N	email	date_change	failed	qa-selfsvc-openedit@example.com	Pickup time updated — TRF-QA2A66	Hi QA SelfService openedit,\n\nYour pickup time for TRF-QA2A66 was changed.\nPrevious: Sun 09 Aug, 12:33\nNew: Tue 11 Aug, 12:33\n\nRoute: TIA Airport → Durrës Center\nManage: https://landedalbania.com/my-booking\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-selfsvc-openedit@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:33:39.345
cmshdoikx0020ob9nh77gknzf	\N	\N	email	date_change	sent	support@landedalbania.com	Date changed — TRF-QA2A66	Pickup time changed for TRF-QA2A66\nPrevious: Sun 09 Aug, 12:33\nNew: Tue 11 Aug, 12:33\nCustomer: QA SelfService openedit\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd00ad857df472fd8e22fc06f	2026-08-06 10:33:40.461	id=<57ff34dd-c197-5a98-27b8-f1ffeea0c6c0@landedalbania.com> · smtp=250 OK id=1wrvPx-00000006r2X-2Jph	2026-08-06 10:33:39.345
cmshdoj6b0024ob9nq0cxe328	\N	\N	email	cancellation	failed	qa-selfsvc-race@example.com	Booking cancelled — TRF-QAD85B	Hi QA SelfService race,\n\nYour booking TRF-QAD85B has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA Airport → Durrës Center\nWhen: Sun 09 Aug, 12:33\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-selfsvc-race@example.com.  The\n550-account or domain may not exist, they may be blacklisted, or missing the\n550 proper dns entries.	2026-08-06 10:33:40.115
cmshdppse002cob9n1tjtro93	\N	\N	email	cancellation	failed	qa-race-70f85eee@example.com	Booking cancelled — TRF-QRA0FA	Hi QA Race,\n\nYour booking TRF-QRA0FA has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-70f85eee@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:35.342
cmshdpriq002job9nbm03gnd9	\N	\N	email	cancellation	failed	qa-race-f7218c3e@example.com	Booking cancelled — TRF-QRDB4F	Hi QA Race,\n\nYour booking TRF-QRDB4F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-f7218c3e@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:37.587
cmshdpsw4002sob9nora49y5a	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR7E00	Booking TRF-QR7E00 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-d76aa23f@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=bdb23c1f28687d41a3b746d1c	2026-08-06 10:34:39.622	id=<35063eb4-4089-9fbc-1a77-fb13a35b870c@landedalbania.com> · smtp=250 OK id=1wrvQu-00000006rpm-2D1K	2026-08-06 10:34:39.365
cmshdptya002zob9n2ukjrhit	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR891F	Booking TRF-QR891F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-469cc950@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b373cf8b240ff01bb8faff4af	2026-08-06 10:34:41.771	id=<efb417fa-19bd-f403-6b93-2b66a0b61aa5@landedalbania.com> · smtp=250 OK id=1wrvQw-00000006rtt-33Mg	2026-08-06 10:34:40.738
cmshdpwr4003dob9n3csqn19k	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR3AD7	Booking TRF-QR3AD7 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-e0541fe9@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b4668166c58af7b5bdf3feea2	2026-08-06 10:34:45.111	id=<f5288f21-3728-1cbc-6cb5-9cb9d99a7439@landedalbania.com> · smtp=250 OK id=1wrvR0-00000006rv6-0ns4	2026-08-06 10:34:44.368
cmshdqfs50063ob9npij9mvvy	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR7897	Booking TRF-QR7897 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-4e9808e5@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b0edb477009662d31aacdd384	2026-08-06 10:35:09.754	id=<e5e1625c-dd68-fda5-9252-9bb7f03786de@landedalbania.com> · smtp=250 OK id=1wrvRO-00000006sb9-2WAz	2026-08-06 10:35:09.029
cmshdv3lk00a6ob9njcpximre	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXB00C	Booking TRF-FXB00C was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix open · qa-fix-open-68d919@example.com\nWhen: Mon 10 Aug, 12:38\nOpen: https://landedalbania.com/admin/bookings?bookingId=b7c9e9074f1e85e39342d5968	2026-08-06 10:38:47.089	id=<8b50ead1-1b05-d485-a38f-cd51fdce901d@landedalbania.com> · smtp=250 OK id=1wrvUu-00000006wEV-2LgV	2026-08-06 10:38:46.52
cmshdohi7001tob9n4bsirtpa	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QA5649	Booking TRF-QA5649 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA SelfService opencancel · qa-selfsvc-opencancel@example.com\nWhen: Sun 09 Aug, 12:33\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd4d73b7180594cf59e6a55a5	2026-08-06 10:33:38.671	id=<8dd09f80-6b0e-2139-2519-a7cdc9c49e54@landedalbania.com> · smtp=250 OK id=1wrvPv-00000006r1l-2xLh	2026-08-06 10:33:37.951
cmshdoj6b0026ob9n3azoe6a0	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QAD85B	Booking TRF-QAD85B was cancelled (Deposit forfeited (no refund)).\nCustomer: QA SelfService race · qa-selfsvc-race@example.com\nWhen: Sun 09 Aug, 12:33\nOpen: https://landedalbania.com/admin/bookings?bookingId=bed52d567ba9210edf14d911d	2026-08-06 10:33:41.154	id=<cabc087d-a2d9-f08d-3057-1ee8f8d87ad9@landedalbania.com> · smtp=250 OK id=1wrvPy-00000006r38-17Kr	2026-08-06 10:33:40.116
cmshdppse002eob9nzz2ytn5g	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRA0FA	Booking TRF-QRA0FA was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-70f85eee@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b081578db9dcb503a49211d72	2026-08-06 10:34:36.344	id=<8b4d3bf2-91b7-594a-ed88-e86aa7ac8858@landedalbania.com> · smtp=250 OK id=1wrvQr-00000006ron-0bV8	2026-08-06 10:34:35.342
cmshdprir002lob9nq82f5oiu	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRDB4F	Booking TRF-QRDB4F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-f7218c3e@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=bf674ea471dbfc08d03c58c8c	2026-08-06 10:34:38.362	id=<fb07b521-7391-0bac-fd92-0786d1b9261d@landedalbania.com> · smtp=250 OK id=1wrvQt-00000006rpm-0weV	2026-08-06 10:34:37.587
cmshdpsw4002qob9n9vxbw084	\N	\N	email	cancellation	failed	qa-race-d76aa23f@example.com	Booking cancelled — TRF-QR7E00	Hi QA Race,\n\nYour booking TRF-QR7E00 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-d76aa23f@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:39.364
cmshdptya002xob9nmn1nh7zq	\N	\N	email	cancellation	failed	qa-race-469cc950@example.com	Booking cancelled — TRF-QR891F	Hi QA Race,\n\nYour booking TRF-QR891F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-469cc950@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:40.738
cmshdpvhq0034ob9ny45vb4oc	\N	\N	email	cancellation	failed	qa-race-a0501fc4@example.com	Booking cancelled — TRF-QR04A2	Hi QA Race,\n\nYour booking TRF-QR04A2 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-a0501fc4@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:42.734
cmshdpvhq0036ob9nhdy3tpdf	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR04A2	Booking TRF-QR04A2 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-a0501fc4@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b75fc11e4fa415b398705e12f	2026-08-06 10:34:43.458	id=<a9e6b303-790a-234b-cd6c-e68bf7086bd7@landedalbania.com> · smtp=250 OK id=1wrvQy-00000006ruG-22no	2026-08-06 10:34:42.734
cmshdpwr3003bob9nxzhws7kd	\N	\N	email	cancellation	failed	qa-race-e0541fe9@example.com	Booking cancelled — TRF-QR3AD7	Hi QA Race,\n\nYour booking TRF-QR3AD7 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-e0541fe9@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:44.368
cmshdpy5p003iob9nza9le7hx	\N	\N	email	cancellation	failed	qa-race-cda29c03@example.com	Booking cancelled — TRF-QR213D	Hi QA Race,\n\nYour booking TRF-QR213D has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-cda29c03@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:46.189
cmshdpy5p003kob9nqli3i4eq	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR213D	Booking TRF-QR213D was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-cda29c03@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=bb7db77e5131852cb6af44ee4	2026-08-06 10:34:46.455	id=<b87253e9-647c-ccec-6086-fcb75bd1bbae@landedalbania.com> · smtp=250 OK id=1wrvR1-00000006rv6-2Qok	2026-08-06 10:34:46.189
cmshdpz6g003rob9nx3u8hi3h	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR4104	Booking TRF-QR4104 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-f8bb891d@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b9d4e07e8325745386fe0a8f7	2026-08-06 10:34:48.068	id=<9884b649-4737-3f00-7363-89b0f866fe34@landedalbania.com> · smtp=250 OK id=1wrvR3-00000006ryH-128Z	2026-08-06 10:34:47.512
cmshdv3lk00a4ob9nbgf2m5ow	\N	\N	email	cancellation	failed	qa-fix-open-68d919@example.com	Booking cancelled — TRF-FXB00C	Hi QA Fix open,\n\nYour booking TRF-FXB00C has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:38\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-open-68d919@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:38:46.52
cmshdpz6g003pob9nq29ssrdj	\N	\N	email	cancellation	failed	qa-race-f8bb891d@example.com	Booking cancelled — TRF-QR4104	Hi QA Race,\n\nYour booking TRF-QR4104 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-f8bb891d@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:47.512
cmshdq0e5003wob9n0faxdav0	\N	\N	email	cancellation	failed	qa-race-e2b1208c@example.com	Booking cancelled — TRF-QR96E8	Hi QA Race,\n\nYour booking TRF-QR96E8 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-e2b1208c@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:49.086
cmshdq1zd0043ob9nwa14om1o	\N	\N	email	cancellation	failed	qa-race-cf5f1817@example.com	Booking cancelled — TRF-QR3188	Hi QA Race,\n\nYour booking TRF-QR3188 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-cf5f1817@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:51.145
cmshdq3eu004cob9n3yjyhx9d	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRFFAC	Booking TRF-QRFFAC was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-be72f16d@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b37f0cda463bfb7c72c57ed5b	2026-08-06 10:34:53.742	id=<9248e4b7-8b63-3371-9fd3-75d6c4ff2d5a@landedalbania.com> · smtp=250 OK id=1wrvR9-00000006s4d-0PTG	2026-08-06 10:34:52.998
cmshdq4p4004hob9np70snob4	\N	\N	email	cancellation	failed	qa-race-7df41c5c@example.com	Booking cancelled — TRF-QRA089	Hi QA Race,\n\nYour booking TRF-QRA089 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-7df41c5c@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:54.664
cmshdq5yc004oob9n4q8xk2wd	\N	\N	email	cancellation	failed	qa-race-cc9d4803@example.com	Booking cancelled — TRF-QRC04B	Hi QA Race,\n\nYour booking TRF-QRC04B has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-cc9d4803@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:56.292
cmshdq79n004xob9ncw1uqb59	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRA5AE	Booking TRF-QRA5AE was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-ba186ada@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b13111911dd1adba625f88820	2026-08-06 10:34:58.731	id=<64e47483-8b9a-b64c-cf46-fdf48decafd7@landedalbania.com> · smtp=250 OK id=1wrvRE-00000006s8J-11gi	2026-08-06 10:34:57.996
cmshdq8hg0052ob9nhg1ltsrw	\N	\N	email	cancellation	failed	qa-race-fa70fbee@example.com	Booking cancelled — TRF-QRAC84	Hi QA Race,\n\nYour booking TRF-QRAC84 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-fa70fbee@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:59.572
cmshdq9pk0059ob9nrhp746ni	\N	\N	email	cancellation	failed	qa-race-b4c9a932@example.com	Booking cancelled — TRF-QRD825	Hi QA Race,\n\nYour booking TRF-QRD825 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-b4c9a932@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:01.161
cmshdqans005gob9n1xthails	\N	\N	email	cancellation	failed	qa-race-7db6de9f@example.com	Booking cancelled — TRF-QRA248	Hi QA Race,\n\nYour booking TRF-QRA248 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-7db6de9f@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:02.393
cmshdqd2p005pob9nwdh69bmy	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR5757	Booking TRF-QR5757 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-c0009b6b@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bff616afad03ede0f01678bd4	2026-08-06 10:35:06.383	id=<3d51ffd0-e356-fa25-f9a3-77d83699bfcd@landedalbania.com> · smtp=250 OK id=1wrvRL-00000006sW8-0JVs	2026-08-06 10:35:05.521
cmshdqefz005uob9n3ji05yp2	\N	\N	email	cancellation	failed	qa-race-304b6084@example.com	Booking cancelled — TRF-QRCE28	Hi QA Race,\n\nYour booking TRF-QRCE28 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-304b6084@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:07.295
cmshdq0e6003yob9nsqfv4i39	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR96E8	Booking TRF-QR96E8 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-e2b1208c@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b00aa0f0c336401d37b2222ad	2026-08-06 10:34:50.059	id=<9832f63c-0258-43ce-cb7b-b3941092fb31@landedalbania.com> · smtp=250 OK id=1wrvR5-00000006s1Z-1GKf	2026-08-06 10:34:49.086
cmshdqjgf006oob9nm0yfleoi	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR2C61	Booking TRF-QR2C61 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-3ee844e0@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b1cd4e4de6cc981a6c3839c6a	2026-08-06 10:35:14.051	id=<c8b23e9b-1583-eb0f-8f3e-883b0a97e4ef@landedalbania.com> · smtp=250 OK id=1wrvRT-00000006sfK-07jy	2026-08-06 10:35:13.791
cmshdv7pf00acob9nb1plgoi3	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX6092	Booking TRF-FX6092 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r0 · qa-fix-r0-91fdbf@example.com\nWhen: Mon 10 Aug, 12:38\nOpen: https://landedalbania.com/admin/bookings?bookingId=b936fa93028af7ee58bfa421b	2026-08-06 10:38:52.433	id=<14e2d896-0948-4ddf-0513-095acc2cbeeb@landedalbania.com> · smtp=250 OK id=1wrvV0-00000006wM7-0Bap	2026-08-06 10:38:51.844
cmshdq1ze0045ob9nmtmtu6wk	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR3188	Booking TRF-QR3188 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-cf5f1817@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b9cc8cf526b5656d186781210	2026-08-06 10:34:51.881	id=<4cd44e8f-fa93-68d0-aa7b-dea8cb8a7f21@landedalbania.com> · smtp=250 OK id=1wrvR7-00000006s3z-0kvE	2026-08-06 10:34:51.145
cmshdq3et004aob9noekdbama	\N	\N	email	cancellation	failed	qa-race-be72f16d@example.com	Booking cancelled — TRF-QRFFAC	Hi QA Race,\n\nYour booking TRF-QRFFAC has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-be72f16d@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:52.998
cmshdq4p4004job9nkhv7ng6y	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRA089	Booking TRF-QRA089 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-7df41c5c@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=b3c7ed092bfe236dcc7c66032	2026-08-06 10:34:55.412	id=<fbf4219a-fcfb-b78d-4cb6-a40ee3b63d5c@landedalbania.com> · smtp=250 OK id=1wrvRA-00000006s6k-3Na5	2026-08-06 10:34:54.665
cmshdq5yc004qob9n6f6hjt54	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRC04B	Booking TRF-QRC04B was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-cc9d4803@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd0a75ba5eab94f5b7eaa3840	2026-08-06 10:34:57.157	id=<ea45fcfc-876f-ea9e-1bbe-b14787000159@landedalbania.com> · smtp=250 OK id=1wrvRC-00000006s7c-2e2x	2026-08-06 10:34:56.293
cmshdq79n004vob9n6jpi6vpm	\N	\N	email	cancellation	failed	qa-race-ba186ada@example.com	Booking cancelled — TRF-QRA5AE	Hi QA Race,\n\nYour booking TRF-QRA5AE has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:34\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-ba186ada@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:34:57.996
cmshdq8hg0054ob9nkf4xpzc1	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRAC84	Booking TRF-QRAC84 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-fa70fbee@example.com\nWhen: Mon 10 Aug, 12:34\nOpen: https://landedalbania.com/admin/bookings?bookingId=bb19c06770e486d81648b179d	2026-08-06 10:35:00.292	id=<86ba5db8-e789-4d79-918a-bbcfba5d8edd@landedalbania.com> · smtp=250 OK id=1wrvRF-00000006s98-3epO	2026-08-06 10:34:59.572
cmshdq9pk005bob9nfwtq2f1b	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRD825	Booking TRF-QRD825 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-b4c9a932@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b3305f8291fd024b32826f2a1	2026-08-06 10:35:01.416	id=<8c18a3f5-81fb-0804-1250-c5a1b6912af5@landedalbania.com> · smtp=250 OK id=1wrvRH-00000006s98-07dZ	2026-08-06 10:35:01.161
cmshdqant005iob9npdkgtipt	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRA248	Booking TRF-QRA248 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-7db6de9f@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b60251d73c4529d99af20f329	2026-08-06 10:35:04.444	id=<21bb5501-1799-69c3-4c6c-1bd4e641f12f@landedalbania.com> · smtp=250 OK id=1wrvRJ-00000006sTZ-0R55	2026-08-06 10:35:02.393
cmshdqd2p005nob9nutscijmb	\N	\N	email	cancellation	failed	qa-race-c0009b6b@example.com	Booking cancelled — TRF-QR5757	Hi QA Race,\n\nYour booking TRF-QR5757 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-c0009b6b@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:05.521
cmshdqeg0005wob9nnun8773o	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRCE28	Booking TRF-QRCE28 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-304b6084@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b24deb34c0642dcfa6ecb8937	2026-08-06 10:35:08.055	id=<bec3b12f-bcc7-da7b-31bf-ee0d30d8dde4@landedalbania.com> · smtp=250 OK id=1wrvRM-00000006sZ6-3Vp1	2026-08-06 10:35:07.296
cmshdqh0l0068ob9nxwrp6vdj	\N	\N	email	cancellation	failed	qa-race-66baae2d@example.com	Booking cancelled — TRF-QR7FE9	Hi QA Race,\n\nYour booking TRF-QR7FE9 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-66baae2d@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:10.63
cmshdqhzh006fob9n2cb1hnbb	\N	\N	email	cancellation	failed	qa-race-0715663c@example.com	Booking cancelled — TRF-QR3A10	Hi QA Race,\n\nYour booking TRF-QR3A10 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-0715663c@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:11.885
cmshdqhzh006hob9nihid3wfo	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR3A10	Booking TRF-QR3A10 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-0715663c@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bcfb7d0775c925ddf43d42a8f	2026-08-06 10:35:12.903	id=<36895c89-f0f3-63d9-0d9c-6bdd0a950340@landedalbania.com> · smtp=250 OK id=1wrvRR-00000006sfK-3ZtL	2026-08-06 10:35:11.886
cmshdqjgf006mob9ns2d0rk89	\N	\N	email	cancellation	failed	qa-race-3ee844e0@example.com	Booking cancelled — TRF-QR2C61	Hi QA Race,\n\nYour booking TRF-QR2C61 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-3ee844e0@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:13.791
cmshdqkey006tob9npfmchl29	\N	\N	email	cancellation	failed	qa-race-0533efff@example.com	Booking cancelled — TRF-QRBED8	Hi QA Race,\n\nYour booking TRF-QRBED8 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-0533efff@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:15.035
cmshdqkez006vob9nr9oa93gx	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRBED8	Booking TRF-QRBED8 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-0533efff@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b27ca516635742ba69f40bdca	2026-08-06 10:35:16.015	id=<f38fe991-306a-896c-3767-635c8c56d509@landedalbania.com> · smtp=250 OK id=1wrvRV-00000006sgw-0G4d	2026-08-06 10:35:15.035
cmshdqluu0070ob9nciu2wet6	\N	\N	email	cancellation	failed	qa-race-3c165f62@example.com	Booking cancelled — TRF-QR54A4	Hi QA Race,\n\nYour booking TRF-QR54A4 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-3c165f62@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:16.903
cmshdqmtr0077ob9ni86y7rq1	\N	\N	email	cancellation	failed	qa-race-62d30f88@example.com	Booking cancelled — TRF-QRDF47	Hi QA Race,\n\nYour booking TRF-QRDF47 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-62d30f88@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:18.159
cmshdqo9h007gob9npzikpfrn	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR34F3	Booking TRF-QR34F3 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-e54665dd@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd2c96ff813a8dc69b6a5e88c	2026-08-06 10:35:20.285	id=<58c14d5b-442b-efaf-f88f-533a7ee2d5af@landedalbania.com> · smtp=250 OK id=1wrvRZ-00000006skI-1zH9	2026-08-06 10:35:20.021
cmshdqp85007lob9nloaco8pd	\N	\N	email	cancellation	failed	qa-race-295a0a0b@example.com	Booking cancelled — TRF-QR1E58	Hi QA Race,\n\nYour booking TRF-QR1E58 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-295a0a0b@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:21.269
cmshdv7pf00adob9nyc8xiuz7	\N	\N	email	cancellation	failed	qa-fix-r0-91fdbf@example.com	Booking cancelled — TRF-FX6092	Hi QA Fix r0,\n\nYour booking TRF-FX6092 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:38\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r0-91fdbf@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:38:51.844
cmshdqluu0072ob9nrl3ckwmf	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR54A4	Booking TRF-QR54A4 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-3c165f62@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b08cac17ce2fedf2d95bb23ac	2026-08-06 10:35:17.162	id=<202f537e-7874-3bf0-cd65-baf02c719921@landedalbania.com> · smtp=250 OK id=1wrvRW-00000006sgw-11q1	2026-08-06 10:35:16.903
cmshdqmtr0079ob9n5iyh9nh8	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRDF47	Booking TRF-QRDF47 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-62d30f88@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b518b585cd6eb693610858b57	2026-08-06 10:35:19.126	id=<ffd7176b-732c-27fd-d1f6-819e9ab0d60b@landedalbania.com> · smtp=250 OK id=1wrvRY-00000006skI-19dQ	2026-08-06 10:35:18.16
cmshdqo9g007eob9nv3hzt1dp	\N	\N	email	cancellation	failed	qa-race-e54665dd@example.com	Booking cancelled — TRF-QR34F3	Hi QA Race,\n\nYour booking TRF-QR34F3 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-e54665dd@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:20.021
cmshdqp85007nob9np10ik62z	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR1E58	Booking TRF-QR1E58 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-295a0a0b@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=baa9b5485d7a2564866a8552b	2026-08-06 10:35:22.278	id=<45e6a3bc-e22f-e6a8-06aa-1a7eafbb7d43@landedalbania.com> · smtp=250 OK id=1wrvRb-00000006smH-2AU6	2026-08-06 10:35:21.269
cmshdqqsp007sob9nx3eygavf	\N	\N	email	cancellation	failed	qa-race-8cef945d@example.com	Booking cancelled — TRF-QR2C3E	Hi QA Race,\n\nYour booking TRF-QR2C3E has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-8cef945d@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:23.306
cmshdqqsq007uob9n4q9dcq1e	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR2C3E	Booking TRF-QR2C3E was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-8cef945d@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b4c45f9ef18de0ee2c0d70583	2026-08-06 10:35:24.024	id=<391bb1a0-2a13-b885-cb2f-90e8e5b976f2@landedalbania.com> · smtp=250 OK id=1wrvRd-00000006sna-1QRl	2026-08-06 10:35:23.306
cmshdqs2b0081ob9ndudw6grs	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR5CB9	Booking TRF-QR5CB9 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-ed60d78e@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bc2d4690a582ced2861c30539	2026-08-06 10:35:25.705	id=<077a6881-5ac9-9780-98ff-72f49e63dc01@landedalbania.com> · smtp=250 OK id=1wrvRf-00000006srt-0GPN	2026-08-06 10:35:24.948
cmshdqtid0088ob9ntr43hsfx	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRAEE0	Booking TRF-QRAEE0 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-5572502a@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd8f4e7d1b931e356ca3b6d94	2026-08-06 10:35:27.556	id=<f2ca3d4e-f201-7360-3506-9e568800fb10@landedalbania.com> · smtp=250 OK id=1wrvRg-00000006svx-46uU	2026-08-06 10:35:26.821
cmshdqv5w008dob9npweabeqk	\N	\N	email	cancellation	failed	qa-race-7950cfc0@example.com	Booking cancelled — TRF-QR8A4F	Hi QA Race,\n\nYour booking TRF-QR8A4F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-7950cfc0@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:28.964
cmshdqwvd008kob9n9bo77n2f	\N	\N	email	cancellation	failed	qa-race-e0525605@example.com	Booking cancelled — TRF-QRD05F	Hi QA Race,\n\nYour booking TRF-QRD05F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-e0525605@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:31.177
cmshdqy9g008rob9na2nttvgn	\N	\N	email	cancellation	failed	qa-race-cc7a4a0d@example.com	Booking cancelled — TRF-QR8852	Hi QA Race,\n\nYour booking TRF-QR8852 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-cc7a4a0d@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:32.98
cmshdqz860090ob9nypnz2esd	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR23FD	Booking TRF-QR23FD was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-db3eb175@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b824fa089f50f96b76b0cccc0	2026-08-06 10:35:35.201	id=<aae670cb-b296-efc8-ed52-41121efff864@landedalbania.com> · smtp=250 OK id=1wrvRo-00000006t6Z-3hp2	2026-08-06 10:35:34.23
cmshdqs2b007zob9n844v2yrx	\N	\N	email	cancellation	failed	qa-race-ed60d78e@example.com	Booking cancelled — TRF-QR5CB9	Hi QA Race,\n\nYour booking TRF-QR5CB9 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-ed60d78e@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:24.947
cmshdv9f600aiob9nfhhaiy74	\N	\N	email	cancellation	failed	qa-fix-r1-f2a54c@example.com	Booking cancelled — TRF-FX392D	Hi QA Fix r1,\n\nYour booking TRF-FX392D has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:38\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r1-f2a54c@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:38:54.066
cmshdqtid0086ob9nvhr2vhfc	\N	\N	email	cancellation	failed	qa-race-5572502a@example.com	Booking cancelled — TRF-QRAEE0	Hi QA Race,\n\nYour booking TRF-QRAEE0 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-5572502a@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:26.821
cmshdvbu000apob9nfmkwzbsu	\N	\N	email	cancellation	failed	qa-fix-r2-188d19@example.com	Booking cancelled — TRF-FXA5E6	Hi QA Fix r2,\n\nYour booking TRF-FXA5E6 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:38\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r2-188d19@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:38:57.193
cmshdqv5w008fob9njblbfaz2	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR8A4F	Booking TRF-QR8A4F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-7950cfc0@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b54832ce955df2b5851877902	2026-08-06 10:35:29.697	id=<dd7f70e6-2a75-cdda-8ef9-d75dd87f0ae7@landedalbania.com> · smtp=250 OK id=1wrvRj-00000006t0N-0ogX	2026-08-06 10:35:28.964
cmshdqwvd008mob9noi4rnudj	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRD05F	Booking TRF-QRD05F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-e0525605@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b14cc43b57e89c28db87cface	2026-08-06 10:35:32.016	id=<7f4b6fc3-bf73-774c-0ded-841c7e8e4027@landedalbania.com> · smtp=250 OK id=1wrvRl-00000006t2w-2Tgd	2026-08-06 10:35:31.178
cmshdvd4k00ayob9nxn7owef1	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX8472	Booking TRF-FX8472 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r3 · qa-fix-r3-2228ef@example.com\nWhen: Mon 10 Aug, 12:38\nOpen: https://landedalbania.com/admin/bookings?bookingId=bbbee8cacf05f71f822a97551	2026-08-06 10:38:59.611	id=<827462ae-463a-ab08-3d17-77909d7d2699@landedalbania.com> · smtp=250 OK id=1wrvV6-00000006wQW-1SvG	2026-08-06 10:38:58.869
cmshdqy9g008tob9neb4ihmju	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR8852	Booking TRF-QR8852 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-cc7a4a0d@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b40b224637d345052d5c1150d	2026-08-06 10:35:33.236	id=<d2d0ebd6-d445-3024-e1a8-9d6f034f4e91@landedalbania.com> · smtp=250 OK id=1wrvRm-00000006t2w-3a6j	2026-08-06 10:35:32.98
cmshdvefu00b5ob9njfouv1vy	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXA909	Booking TRF-FXA909 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r4 · qa-fix-r4-029ca4@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b60cd3ee24dc5069b5ff9e01b	2026-08-06 10:39:00.838	id=<5fd52267-dc32-41aa-ca9b-5b14d14c3295@landedalbania.com> · smtp=250 OK id=1wrvV7-00000006wQW-2aeb	2026-08-06 10:39:00.57
cmshdqz86008yob9n3txyor9o	\N	\N	email	cancellation	failed	qa-race-db3eb175@example.com	Booking cancelled — TRF-QR23FD	Hi QA Race,\n\nYour booking TRF-QR23FD has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-db3eb175@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:34.23
cmshdvfuk00baob9ngtb0g5as	\N	\N	email	cancellation	failed	qa-fix-r5-0e3701@example.com	Booking cancelled — TRF-FXDD29	Hi QA Fix r5,\n\nYour booking TRF-FXDD29 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r5-0e3701@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:02.396
cmshdr0ob0095ob9nu1sre9n5	\N	\N	email	cancellation	failed	qa-race-e3c49070@example.com	Booking cancelled — TRF-QRA46C	Hi QA Race,\n\nYour booking TRF-QRA46C has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-e3c49070@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:36.108
cmshdv9f600akob9nhlyw0k3p	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX392D	Booking TRF-FX392D was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r1 · qa-fix-r1-f2a54c@example.com\nWhen: Mon 10 Aug, 12:38\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd8cb0590c9f91039dc6e80e2	2026-08-06 10:38:55.102	id=<f34b64c3-a909-8170-1b23-001b966ceabb@landedalbania.com> · smtp=250 OK id=1wrvV2-00000006wOk-3BZW	2026-08-06 10:38:54.067
cmshdr2v1009cob9nruojg2ph	\N	\N	email	cancellation	failed	qa-race-c83803f3@example.com	Booking cancelled — TRF-QRB6F4	Hi QA Race,\n\nYour booking TRF-QRB6F4 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-c83803f3@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:38.941
cmshdvbu200arob9n08btllez	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXA5E6	Booking TRF-FXA5E6 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r2 · qa-fix-r2-188d19@example.com\nWhen: Mon 10 Aug, 12:38\nOpen: https://landedalbania.com/admin/bookings?bookingId=b6701f18bf5a7f57e892ce9d4	2026-08-06 10:38:57.95	id=<04f0d41d-5124-f5a7-b2bb-bbec756272ac@landedalbania.com> · smtp=250 OK id=1wrvV4-00000006wPL-2fkp	2026-08-06 10:38:57.194
cmshdr45b009lob9nc4oo0gzm	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QR3CEE	Booking TRF-QR3CEE was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-a94390c0@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b58b5dc90cde19f28d2c48bab	2026-08-06 10:35:40.886	id=<fb30532b-41c1-0f61-8658-fb2c919adfb0@landedalbania.com> · smtp=250 OK id=1wrvRt-00000006tBO-2s2H	2026-08-06 10:35:40.607
cmshdvd4k00awob9n1ynnmr6t	\N	\N	email	cancellation	failed	qa-fix-r3-2228ef@example.com	Booking cancelled — TRF-FX8472	Hi QA Fix r3,\n\nYour booking TRF-FX8472 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:38\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r3-2228ef@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:38:58.868
cmshdr5d2009sob9nrfpi1k10	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRE69F	Booking TRF-QRE69F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-57bf88d3@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=be52eb2af05a2a475235fb644	2026-08-06 10:35:42.808	id=<2b93d180-6076-937e-a319-ed028056fe2e@landedalbania.com> · smtp=250 OK id=1wrvRv-00000006tHd-2tfK	2026-08-06 10:35:42.182
cmshdr6t9009xob9ndlaosyt1	\N	\N	email	cancellation	failed	qa-race-65d5c2ba@example.com	Booking cancelled — TRF-QRE5DB	Hi QA Race,\n\nYour booking TRF-QRE5DB has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-65d5c2ba@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:44.061
cmshdveft00b3ob9n4cc0c0ao	\N	\N	email	cancellation	failed	qa-fix-r4-029ca4@example.com	Booking cancelled — TRF-FXA909	Hi QA Fix r4,\n\nYour booking TRF-FXA909 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r4-029ca4@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:00.57
cmshdvful00bcob9n15itwiha	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXDD29	Booking TRF-FXDD29 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r5 · qa-fix-r5-0e3701@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bae9748a82cd7c6f7f896130e	2026-08-06 10:39:03.449	id=<bafd8348-2876-1936-53b4-e56c8296bec2@landedalbania.com> · smtp=250 OK id=1wrvVA-00000006wVF-1Igd	2026-08-06 10:39:02.397
cmshdvhu400bhob9n543g9rbj	\N	\N	email	cancellation	failed	qa-fix-r6-166406@example.com	Booking cancelled — TRF-FXD28F	Hi QA Fix r6,\n\nYour booking TRF-FXD28F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r6-166406@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:04.972
cmshdr0oc0097ob9nbne0ewof	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRA46C	Booking TRF-QRA46C was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-e3c49070@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bb14e9bc7914690e7f8b30b68	2026-08-06 10:35:38.065	id=<5de475ab-6f72-6bb5-0208-81e1705d7652@landedalbania.com> · smtp=250 OK id=1wrvRq-00000006t8G-3Ifa	2026-08-06 10:35:36.108
cmshdvhu500bjob9n68m9ojwa	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXD28F	Booking TRF-FXD28F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r6 · qa-fix-r6-166406@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bc41eb745a1b0e1a1321009f2	2026-08-06 10:39:05.726	id=<2d3f5a53-9309-2f74-d174-2f913737670a@landedalbania.com> · smtp=250 OK id=1wrvVC-00000006wWs-2siN	2026-08-06 10:39:04.973
cmshdr2v1009eob9nodmbbjb9	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRB6F4	Booking TRF-QRB6F4 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-c83803f3@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=b8c12ccdd0c7999af42302bfc	2026-08-06 10:35:39.68	id=<aadf36ba-6c4f-8381-c2dd-fe6154d9e1c9@landedalbania.com> · smtp=250 OK id=1wrvRs-00000006tBO-1wMr	2026-08-06 10:35:38.941
cmshdvj4s00bqob9nyw4jno5x	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX7C7B	Booking TRF-FX7C7B was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r7 · qa-fix-r7-22c5d0@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bc5ab2dd6b65fe01f07160929	2026-08-06 10:39:07.385	id=<99c6c87c-51d5-e08b-43ae-f434592ddab5@landedalbania.com> · smtp=250 OK id=1wrvVE-00000006wYH-1hlM	2026-08-06 10:39:06.652
cmshdr45b009job9nqcfmnntk	\N	\N	email	cancellation	failed	qa-race-a94390c0@example.com	Booking cancelled — TRF-QR3CEE	Hi QA Race,\n\nYour booking TRF-QR3CEE has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-a94390c0@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:40.607
cmshdr5d1009qob9novnp07sb	\N	\N	email	cancellation	failed	qa-race-57bf88d3@example.com	Booking cancelled — TRF-QRE69F	Hi QA Race,\n\nYour booking TRF-QRE69F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:35\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-race-57bf88d3@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:35:42.181
cmshdvkej00bvob9nc8hzw8gr	\N	\N	email	cancellation	failed	qa-fix-r8-05bb6b@example.com	Booking cancelled — TRF-FX2554	Hi QA Fix r8,\n\nYour booking TRF-FX2554 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r8-05bb6b@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:08.299
cmshdr6t9009zob9nbefj816o	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-QRE5DB	Booking TRF-QRE5DB was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Race · qa-race-65d5c2ba@example.com\nWhen: Mon 10 Aug, 12:35\nOpen: https://landedalbania.com/admin/bookings?bookingId=bebfbb27aaed27c034a5381c8	2026-08-06 10:35:44.631	id=<e2f742f5-9b0f-dcda-5209-6f7aeae00cac@landedalbania.com> · smtp=250 OK id=1wrvRx-00000006tKr-2Osb	2026-08-06 10:35:44.062
cmshdvj4s00boob9n9hjhu3vv	\N	\N	email	cancellation	failed	qa-fix-r7-22c5d0@example.com	Booking cancelled — TRF-FX7C7B	Hi QA Fix r7,\n\nYour booking TRF-FX7C7B has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r7-22c5d0@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:06.652
cmshdvkej00bxob9nmh7fvrwh	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX2554	Booking TRF-FX2554 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r8 · qa-fix-r8-05bb6b@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b3e6d1fb993ce01abe37b2780	2026-08-06 10:39:09.03	id=<9cec0823-d8a9-db09-8ce0-df5e09967fa3@landedalbania.com> · smtp=250 OK id=1wrvVG-00000006waW-0Vn1	2026-08-06 10:39:08.3
cmshdvma000c4ob9n3fl92e68	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX1E2A	Booking TRF-FX1E2A was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r9 · qa-fix-r9-81c05a@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b43efca6b5ee15373b2fd63e1	2026-08-06 10:39:11.022	id=<ea11b938-2fb8-411b-8305-5ece0802ec39@landedalbania.com> · smtp=250 OK id=1wrvVI-00000006waW-0qU1	2026-08-06 10:39:10.728
cmshdvm9z00c2ob9nexmia2h2	\N	\N	email	cancellation	failed	qa-fix-r9-81c05a@example.com	Booking cancelled — TRF-FX1E2A	Hi QA Fix r9,\n\nYour booking TRF-FX1E2A has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r9-81c05a@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:10.727
cmshdvnfb00c9ob9nlvls8tyf	\N	\N	email	cancellation	failed	qa-fix-r10-1aa42a@example.com	Booking cancelled — TRF-FXF6AC	Hi QA Fix r10,\n\nYour booking TRF-FXF6AC has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r10-1aa42a@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:12.215
cmshdvnfb00cbob9na3t9acow	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXF6AC	Booking TRF-FXF6AC was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r10 · qa-fix-r10-1aa42a@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b86405875bc0a7a2c83fce45f	2026-08-06 10:39:13.175	id=<75402265-cd0e-5e13-23c9-541f3a762b34@landedalbania.com> · smtp=250 OK id=1wrvVK-00000006wdt-1x40	2026-08-06 10:39:12.216
cmshdvous00cgob9nzma1xh2m	\N	\N	email	cancellation	failed	qa-fix-r11-cf2c0f@example.com	Booking cancelled — TRF-FXFF6F	Hi QA Fix r11,\n\nYour booking TRF-FXFF6F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r11-cf2c0f@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:14.068
cmshdvous00ciob9nxt457bbn	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXFF6F	Booking TRF-FXFF6F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r11 · qa-fix-r11-cf2c0f@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bde558074d2bf0ca19653fb0c	2026-08-06 10:39:14.768	id=<427d633d-1c0c-f021-1932-ded6da6dc58e@landedalbania.com> · smtp=250 OK id=1wrvVM-00000006web-0Vmp	2026-08-06 10:39:14.068
cmshdvq4m00cnob9nsyvoqj5a	\N	\N	email	cancellation	failed	qa-fix-r12-592b15@example.com	Booking cancelled — TRF-FX86D9	Hi QA Fix r12,\n\nYour booking TRF-FX86D9 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r12-592b15@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:15.719
cmshdvq4n00cpob9nmf54lx0n	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX86D9	Booking TRF-FX86D9 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r12 · qa-fix-r12-592b15@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bb8e0c4710cd334339f110e92	2026-08-06 10:39:16.419	id=<bee563da-6152-fe98-1d7b-f49e37df26c9@landedalbania.com> · smtp=250 OK id=1wrvVN-00000006wfL-3SBb	2026-08-06 10:39:15.719
cmshdvrv400cuob9ndvp2m2ys	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXF2BF	Booking TRF-FXF2BF was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r13 · qa-fix-r13-8a6052@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bbe24b2d8d3f022702308acbb	2026-08-06 10:39:18.707	id=<a6e9d541-bb07-dea8-8028-d5bc7bfd57ba@landedalbania.com> · smtp=250 OK id=1wrvVQ-00000006wgk-0jZ2	2026-08-06 10:39:17.968
cmshdvtjo00d1ob9ndheymfkj	\N	\N	email	cancellation	failed	qa-fix-r14-d71cae@example.com	Booking cancelled — TRF-FX6DEF	Hi QA Fix r14,\n\nYour booking TRF-FX6DEF has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r14-d71cae@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:20.148
cmshdvv9v00daob9nipkt5npt	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXDA6F	Booking TRF-FXDA6F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r15 · qa-fix-r15-210489@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bedbc3ae9054c0d2ff5c890ff	2026-08-06 10:39:23.379	id=<d4f0bf07-be10-63a8-8f69-60b0494429fe@landedalbania.com> · smtp=250 OK id=1wrvVU-00000006wj7-4A6m	2026-08-06 10:39:22.388
cmshdvwyu00dhob9nbzfd0sfs	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX945C	Booking TRF-FX945C was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r16 · qa-fix-r16-be242c@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bef2359225d560d7bc1443912	2026-08-06 10:39:25.332	id=<04ad62dc-c16a-d4db-eb10-a3a9d730114a@landedalbania.com> · smtp=250 OK id=1wrvVW-00000006wls-45oP	2026-08-06 10:39:24.582
cmshdvyhv00doob9nzszidevy	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXB920	Booking TRF-FXB920 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r17 · qa-fix-r17-03f87f@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=ba07bee894d416ae8f79d07c2	2026-08-06 10:39:27.342	id=<8c67d92a-f175-15ff-2ca9-67193d337cec@landedalbania.com> · smtp=250 OK id=1wrvVY-00000006wnu-47Rk	2026-08-06 10:39:26.564
cmshdvzwb00dvob9n4t9noaqe	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX5A48	Booking TRF-FX5A48 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r18 · qa-fix-r18-8d3441@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=baf6b2ee3bfa343eaf7874c30	2026-08-06 10:39:29.165	id=<e41cbb73-e9dd-5f05-7dc6-84571c13ac77@landedalbania.com> · smtp=250 OK id=1wrvVa-00000006wpF-3Txh	2026-08-06 10:39:28.379
cmshdw1zr00e0ob9n5chs4l1t	\N	\N	email	cancellation	failed	qa-fix-r19-2169fd@example.com	Booking cancelled — TRF-FX09E9	Hi QA Fix r19,\n\nYour booking TRF-FX09E9 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r19-2169fd@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:31.095
cmshdw3ej00e8ob9n0p6d2l8p	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXB6FD	Booking TRF-FXB6FD was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r20 · qa-fix-r20-57e248@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bcdd849a67a5da5f80f9141f3	2026-08-06 10:39:33.666	id=<1775c4ad-aee1-acba-9f27-657178f00578@landedalbania.com> · smtp=250 OK id=1wrvVe-00000006wua-1nZw	2026-08-06 10:39:32.923
cmshdw4qt00eeob9noq7n3vxt	\N	\N	email	cancellation	failed	qa-fix-r21-03322b@example.com	Booking cancelled — TRF-FX5411	Hi QA Fix r21,\n\nYour booking TRF-FX5411 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r21-03322b@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:34.661
cmshdw64v00elob9n7dbcqn8d	\N	\N	email	cancellation	failed	qa-fix-r22-5b30c0@example.com	Booking cancelled — TRF-FXA06F	Hi QA Fix r22,\n\nYour booking TRF-FXA06F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r22-5b30c0@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:36.463
cmshdw7aq00esob9nqx7lqg6m	\N	\N	email	cancellation	failed	qa-fix-r23-8c2265@example.com	Booking cancelled — TRF-FX029F	Hi QA Fix r23,\n\nYour booking TRF-FX029F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r23-8c2265@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:37.97
cmshdw90400f1ob9nu4l1b4cf	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX709F	Booking TRF-FX709F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r24 · qa-fix-r24-aa404f@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=bd1b2d9b198a59ed50ecb8cce	2026-08-06 10:39:40.954	id=<6cac0759-6c88-fb4e-80e1-177fe8501854@landedalbania.com> · smtp=250 OK id=1wrvVl-00000006wzi-3u14	2026-08-06 10:39:40.181
cmshdvrv500cwob9ndzkit37g	\N	\N	email	cancellation	failed	qa-fix-r13-8a6052@example.com	Booking cancelled — TRF-FXF2BF	Hi QA Fix r13,\n\nYour booking TRF-FXF2BF has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r13-8a6052@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:17.968
cmshdvtjo00d3ob9n8ye2ezmj	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX6DEF	Booking TRF-FX6DEF was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r14 · qa-fix-r14-d71cae@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b7bcb0af35e9c4b884739a5cd	2026-08-06 10:39:20.442	id=<e1d9fa4e-2b1e-0980-06dd-ccdb8607c132@landedalbania.com> · smtp=250 OK id=1wrvVR-00000006wgk-41B0	2026-08-06 10:39:20.149
cmshdvv9v00d8ob9nml7fqrye	\N	\N	email	cancellation	failed	qa-fix-r15-210489@example.com	Booking cancelled — TRF-FXDA6F	Hi QA Fix r15,\n\nYour booking TRF-FXDA6F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r15-210489@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:22.387
cmshdvwyt00dfob9n55pb1qay	\N	\N	email	cancellation	failed	qa-fix-r16-be242c@example.com	Booking cancelled — TRF-FX945C	Hi QA Fix r16,\n\nYour booking TRF-FX945C has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r16-be242c@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:24.581
cmshdvyhv00dmob9nkfu2z0i9	\N	\N	email	cancellation	failed	qa-fix-r17-03f87f@example.com	Booking cancelled — TRF-FXB920	Hi QA Fix r17,\n\nYour booking TRF-FXB920 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r17-03f87f@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:26.563
cmshdvzwa00dtob9nej6wh28q	\N	\N	email	cancellation	failed	qa-fix-r18-8d3441@example.com	Booking cancelled — TRF-FX5A48	Hi QA Fix r18,\n\nYour booking TRF-FX5A48 has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r18-8d3441@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:28.379
cmshdw1zr00e2ob9ne0j22rgb	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX09E9	Booking TRF-FX09E9 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r19 · qa-fix-r19-2169fd@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=be600f4b3cd61d803f27847c2	2026-08-06 10:39:31.841	id=<f50c48b2-1477-fe18-8580-2ba71265125c@landedalbania.com> · smtp=250 OK id=1wrvVc-00000006wtC-2BgV	2026-08-06 10:39:31.095
cmshdw3ej00e9ob9nurh2lssw	\N	\N	email	cancellation	failed	qa-fix-r20-57e248@example.com	Booking cancelled — TRF-FXB6FD	Hi QA Fix r20,\n\nYour booking TRF-FXB6FD has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r20-57e248@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:32.923
cmshdw4qt00egob9n8kgbz27a	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX5411	Booking TRF-FX5411 was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r21 · qa-fix-r21-03322b@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b46e2e185cd084118b6c775e9	2026-08-06 10:39:35.416	id=<3adc0e80-42e0-41fc-0611-0348d036adcc@landedalbania.com> · smtp=250 OK id=1wrvVg-00000006wvz-0vXJ	2026-08-06 10:39:34.661
cmshdw64v00enob9n1k7utdcf	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FXA06F	Booking TRF-FXA06F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r22 · qa-fix-r22-5b30c0@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=b9cc12a1367105ee507e0860e	2026-08-06 10:39:36.736	id=<eee412e8-a430-8ebb-387c-1fe3ef6206a7@landedalbania.com> · smtp=250 OK id=1wrvVh-00000006wvz-2TSM	2026-08-06 10:39:36.464
cmshdw7ar00euob9n01ns741t	\N	\N	email	cancellation	sent	support@landedalbania.com	Booking cancelled — TRF-FX029F	Booking TRF-FX029F was cancelled (Deposit forfeited (no refund)).\nCustomer: QA Fix r23 · qa-fix-r23-8c2265@example.com\nWhen: Mon 10 Aug, 12:39\nOpen: https://landedalbania.com/admin/bookings?bookingId=beca83acd016d5f5151a7570e	2026-08-06 10:39:38.982	id=<a04493d3-cb8a-497c-2fea-d0ab37247c7f@landedalbania.com> · smtp=250 OK id=1wrvVj-00000006wyO-3oVp	2026-08-06 10:39:37.971
cmshdw90400ezob9nuparwxqq	\N	\N	email	cancellation	failed	qa-fix-r24-aa404f@example.com	Booking cancelled — TRF-FX709F	Hi QA Fix r24,\n\nYour booking TRF-FX709F has been cancelled.\nThe deposit paid has been forfeited and will not be refunded. Any unpaid balance will not be charged.\n\nPickup was: TIA → Durres\nWhen: Mon 10 Aug, 12:39\n\n+355 68 325 6010 · support@landedalbania.com	\N	Can't send mail - all recipients were rejected: 550-The mail server could not deliver mail to qa-fix-r24-aa404f@example.com. \n550-The account or domain may not exist, they may be blacklisted, or missing\n550 the proper dns entries.	2026-08-06 10:39:40.181
\.


--
-- Data for Name: PageContent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PageContent" (id, slug, label, title, description, "ogImage", sections, "createdAt", "updatedAt", locale) FROM stdin;
cms8xtc3a0003lkbczuu1fy93	home	Homepage	Albania Transfers · Trasferimenti aeroportuali	Prenota trasferimenti aeroportuali affidabili in tutta l'Albania. Prezzi fissi, autisti verificati e condizioni di cancellazione chiare.		[{"id": "b787485e-04a0-44f8-aa85-0d091b4b6476", "key": "hero.heading", "type": "heading", "level": 1, "heading": "Albania Transfers.\\nTrasferimenti aeroportuali"}, {"id": "c1e92b36-d37a-4dbc-909e-75df6f6d6689", "key": "hero.text", "body": "", "type": "text"}, {"id": "1173bc19-40e3-4f8e-914c-f50d160f4f35", "key": "hero.image", "src": "https://www.welcomepickups.com/wp-content/themes/welcomepickups_new/images/conversion-v2/hero_photo_desktop_2.jpg", "type": "image"}, {"id": "6ce7e5ed-55c5-4bf3-9d03-34b822861348", "key": "whyBook.heading", "type": "heading", "level": 2, "heading": ""}, {"id": "de08e0ea-75da-45f2-a9d6-837e5c0e6cd3", "key": "whyBook.item1.heading", "icon": "headset", "type": "heading", "level": 3, "heading": ""}, {"id": "fd7d0188-b690-4dc2-b46f-049fbec94ef6", "key": "whyBook.item1.text", "body": "", "type": "text"}, {"id": "3da7cde7-ba1e-4f92-a79f-38e7d7d3022a", "key": "whyBook.item2.heading", "icon": "wallet", "type": "heading", "level": 3, "heading": ""}, {"id": "2f01c1ef-e92f-4456-8fc5-24fd4faedd8c", "key": "whyBook.item2.text", "body": "", "type": "text"}, {"id": "ad84f4ba-c2a7-4372-a19a-0565d1bcf722", "key": "whyBook.item3.heading", "icon": "shield", "type": "heading", "level": 3, "heading": ""}, {"id": "8c54094d-3685-4720-b7b4-0d8d1dc76bda", "key": "whyBook.item3.text", "body": "", "type": "text"}, {"id": "5055f347-f26c-4a2d-b61d-da96ff1f0692", "key": "destinations.heading", "type": "heading", "level": 2, "heading": ""}, {"id": "685f058c-6626-4dc8-b653-0eb2ba7a2345", "key": "destinations.text", "body": "", "type": "text"}, {"id": "8f701554-73dd-4504-8dac-8f507cf40510", "key": "testimonials.heading", "type": "heading", "level": 2, "heading": ""}, {"id": "fbe9782b-758d-4298-9d33-b5ce7cd4c06b", "key": "testimonials.eyebrow", "body": "", "type": "text"}, {"id": "8afa4dd1-27d8-422a-846a-13c24a79bd4f", "key": "peace.eyebrow", "body": "", "type": "text"}, {"id": "a73fa0a2-aa8d-4738-a875-784808060d08", "key": "peace.heading", "type": "heading", "level": 2, "heading": ""}, {"id": "937b841f-d708-4159-9fa7-304e095578d3", "key": "peace.item1", "type": "heading", "level": 3, "heading": ""}, {"id": "c01301b7-d9a5-4433-ba93-02ac5b84ce1b", "key": "peace.item2", "type": "heading", "level": 3, "heading": ""}, {"id": "2bba1880-0120-4de4-9c17-a2a82f506eb6", "key": "peace.item3", "type": "heading", "level": 3, "heading": ""}, {"id": "4caf6011-2a6d-45c6-a78e-7b7f1a59e37e", "key": "peace.item4", "type": "heading", "level": 3, "heading": ""}, {"id": "65db3c18-de50-4be9-b517-5812069ca2cb", "key": "peace.item5", "type": "heading", "level": 3, "heading": ""}, {"id": "341a832e-8363-492b-acaf-e89e15dd50dd", "key": "peace.item6", "type": "heading", "level": 3, "heading": ""}, {"id": "afd9bfc3-578d-4756-a318-842f153cb898", "key": "safety.heading", "type": "heading", "level": 2, "heading": ""}, {"id": "4a1f1ce3-b644-43b3-a2da-dc3d057a6c73", "key": "safety.item1.heading", "type": "heading", "level": 3, "heading": ""}, {"id": "37048c5d-fe3d-49b3-aa36-e6fa72b33336", "key": "safety.item1.text", "body": "", "type": "text"}, {"id": "44efebd3-38b2-4e45-a068-d0c89cadbad3", "alt": "Using the booking app to find nearby drivers", "key": "safety.item1.image", "src": "/marketing/safety-drivers.png", "type": "image"}, {"id": "01a67ebc-f14a-49f8-9cef-fe91d8ed3993", "key": "safety.item2.heading", "type": "heading", "level": 3, "heading": ""}, {"id": "d9883c79-4fb8-4997-aff0-7f0eb0eee6e6", "key": "safety.item2.text", "body": "", "type": "text"}, {"id": "f884b7e8-eb0e-44e5-bfe5-e3e6a9834603", "alt": "Friendly professional driver ready for pickup", "key": "safety.item2.image", "src": "/marketing/safety-know-driver.png", "type": "image"}, {"id": "0ae75489-191c-4465-88b1-f1f6130b968f", "key": "faq.1", "type": "faq_item", "answer": "", "question": ""}, {"id": "a95f600e-c737-4abe-8618-c92972d1e5f4", "key": "faq.2", "type": "faq_item", "answer": "", "question": ""}]	2026-07-31 12:47:20.95	2026-07-31 13:21:30.095	it
cms8xp1xy0000lkbct4ruekcg	home	Homepage	Albania Transfers · Airport transfers	Book reliable airport transfers across Albania. Fixed prices, vetted drivers, clear cancellation terms.		[{"id": "b787485e-04a0-44f8-aa85-0d091b4b6476", "key": "hero.heading", "type": "heading", "level": 1, "heading": "Arrive. Discover.\\nExperience."}, {"id": "c1e92b36-d37a-4dbc-909e-75df6f6d6689", "key": "hero.text", "body": "Personalised airport transfers designed for travel across Albania.", "type": "text"}, {"id": "1173bc19-40e3-4f8e-914c-f50d160f4f35", "key": "hero.image", "src": "https://www.welcomepickups.com/wp-content/themes/welcomepickups_new/images/conversion-v2/hero_photo_desktop_2.jpg", "type": "image"}, {"id": "6ce7e5ed-55c5-4bf3-9d03-34b822861348", "key": "whyBook.heading", "type": "heading", "level": 2, "heading": "Why book with us?"}, {"id": "de08e0ea-75da-45f2-a9d6-837e5c0e6cd3", "key": "whyBook.item1.heading", "icon": "headset", "type": "heading", "level": 3, "heading": "24/7 Help Center"}, {"id": "fd7d0188-b690-4dc2-b46f-049fbec94ef6", "key": "whyBook.item1.text", "body": "No matter the time zone, we're always here to assist you and answer your questions.", "type": "text"}, {"id": "3da7cde7-ba1e-4f92-a79f-38e7d7d3022a", "key": "whyBook.item2.heading", "icon": "wallet", "type": "heading", "level": 3, "heading": "Best Price Guarantee"}, {"id": "2f01c1ef-e92f-4456-8fc5-24fd4faedd8c", "key": "whyBook.item2.text", "body": "Find a lower price? We'll match it or refund the difference, hassle-free.", "type": "text"}, {"id": "ad84f4ba-c2a7-4372-a19a-0565d1bcf722", "key": "whyBook.item3.heading", "icon": "shield", "type": "heading", "level": 3, "heading": "Quality & Reliability"}, {"id": "8c54094d-3685-4720-b7b4-0d8d1dc76bda", "key": "whyBook.item3.text", "body": "Book with confidence knowing our services meet the highest standards of safety and trust.", "type": "text"}, {"id": "5055f347-f26c-4a2d-b61d-da96ff1f0692", "key": "destinations.heading", "type": "heading", "level": 2, "heading": "Featured Destinations"}, {"id": "685f058c-6626-4dc8-b653-0eb2ba7a2345", "key": "destinations.text", "body": "Discover our most popular hand-picked locations for your next unforgettable journey.", "type": "text"}, {"id": "8f701554-73dd-4504-8dac-8f507cf40510", "key": "testimonials.heading", "type": "heading", "level": 2, "heading": "Trusted by travellers across Albania"}, {"id": "fbe9782b-758d-4298-9d33-b5ce7cd4c06b", "key": "testimonials.eyebrow", "body": "Traveller stories", "type": "text"}, {"id": "8afa4dd1-27d8-422a-846a-13c24a79bd4f", "key": "peace.eyebrow", "body": "Absolute Peace of Mind", "type": "text"}, {"id": "a73fa0a2-aa8d-4738-a875-784808060d08", "key": "peace.heading", "type": "heading", "level": 2, "heading": "Why Book with Albania Transfers"}, {"id": "937b841f-d708-4159-9fa7-304e095578d3", "key": "peace.item1", "type": "heading", "level": 3, "heading": "Meet-and-Greet"}, {"id": "c01301b7-d9a5-4433-ba93-02ac5b84ce1b", "key": "peace.item2", "type": "heading", "level": 3, "heading": "Flight Tracking"}, {"id": "2bba1880-0120-4de4-9c17-a2a82f506eb6", "key": "peace.item3", "type": "heading", "level": 3, "heading": "Easy Booking"}, {"id": "4caf6011-2a6d-45c6-a78e-7b7f1a59e37e", "key": "peace.item4", "type": "heading", "level": 3, "heading": "Reliable Chauffeurs"}, {"id": "65db3c18-de50-4be9-b517-5812069ca2cb", "key": "peace.item5", "type": "heading", "level": 3, "heading": "Fixed Prices"}, {"id": "341a832e-8363-492b-acaf-e89e15dd50dd", "key": "peace.item6", "type": "heading", "level": 3, "heading": "Clear Cancellation Terms"}, {"id": "afd9bfc3-578d-4756-a318-842f153cb898", "key": "safety.heading", "type": "heading", "level": 2, "heading": "Safety is our #1 priority"}, {"id": "4a1f1ce3-b644-43b3-a2da-dc3d057a6c73", "key": "safety.item1.heading", "type": "heading", "level": 3, "heading": "1000s of experienced drivers"}, {"id": "37048c5d-fe3d-49b3-aa36-e6fa72b33336", "key": "safety.item1.text", "body": "With thousands of drivers in one app, you can book a transfer wherever you are, even in times of high demand.", "type": "text"}, {"id": "44efebd3-38b2-4e45-a068-d0c89cadbad3", "alt": "Using the booking app to find nearby drivers", "key": "safety.item1.image", "src": "/uploads/pages/drivers-avaible.jpg", "type": "image"}, {"id": "01a67ebc-f14a-49f8-9cef-fe91d8ed3993", "key": "safety.item2.heading", "type": "heading", "level": 3, "heading": "Know your driver"}, {"id": "d9883c79-4fb8-4997-aff0-7f0eb0eee6e6", "key": "safety.item2.text", "body": "When you hop on an Albania Transfers ride, you'll know your driver's details, rating, and driving experience to make sure you're in safe hands.", "type": "text"}, {"id": "f884b7e8-eb0e-44e5-bfe5-e3e6a9834603", "alt": "Friendly professional driver ready for pickup", "key": "safety.item2.image", "src": "/marketing/safety-know-driver.png", "type": "image"}, {"id": "0ae75489-191c-4465-88b1-f1f6130b968f", "key": "faq.1", "type": "faq_item", "answer": "We recommend booking as soon as your flight is confirmed. Same-day transfers are often available subject to driver capacity.", "question": "How far in advance should I book?"}, {"id": "a95f600e-c737-4abe-8618-c92972d1e5f4", "key": "faq.2", "type": "faq_item", "answer": "Your fare is fixed and includes meet-and-greet, flight tracking, and door-to-door transfer. Tolls and child seats may be added where selected.", "question": "What is included in the price?"}]	2026-07-31 12:44:01.174	2026-08-04 15:21:19.965	en
cms8qbv6v0001lk9k2q966ecw	destinations/tirana	Destination · Tirana City Escape	Tirana City Escape airport transfer	Vibrant capital streets, cafés, and quick airport links for city stays.	https://images.unsplash.com/photo-1600093463592-8e77ffe2476e?auto=format&fit=crop&q=80&w=800	[{"id": "9355b8b4-9ef6-49ff-991a-b8c009e4735a", "key": "title", "type": "heading", "level": 1, "heading": "Tirana City Escape"}, {"id": "7da1bfac-95a5-4305-aaf0-a7ae3ba01ea8", "key": "region", "body": "Central Albania", "type": "text"}, {"id": "b1ee11e0-911d-44f2-a60b-bb535a1bd716", "key": "description", "body": "Vibrant capital streets, cafés, and quick airport links for city stays.", "type": "text"}, {"id": "ce6f2535-402d-407c-915e-02f8011ed926", "alt": "Tirana City Escape", "key": "hero", "src": "https://images.unsplash.com/photo-1600093463592-8e77ffe2476e?auto=format&fit=crop&q=80&w=800", "type": "image"}, {"id": "8553f0d4-f766-4865-969f-1f1e494cb481", "key": "badge", "body": "Popular", "type": "text"}, {"id": "4a47db24-358d-4aa3-ae42-f77562ae3c52", "key": "priceFrom", "body": "€25", "type": "text"}, {"id": "8685e0ad-e1ac-4a2c-95f6-95870caeb9be", "key": "attractions.heading", "type": "heading", "level": 2, "heading": "Top attractions"}, {"id": "5b041798-a6d1-4a40-934d-cef2a08cb02c", "key": "more.heading", "type": "heading", "level": 2, "heading": "More destinations"}, {"id": "77ba32aa-c21d-4e56-a93c-40739119ce5d", "alt": "", "key": "attraction.1", "src": "/uploads/pages/r-5.webp", "body": "Test", "type": "attraction", "heading": "Theth Waterfall"}, {"id": "3d6d4ab7-3c8f-4dac-89dd-ddda469c30f9", "key": "_featured", "body": "featured", "type": "text"}]	2026-07-31 09:17:48.583	2026-08-05 20:54:34.014	en
cmsgkfiaa002bob9ntfilcwc6	destinations/durres	Destination · Durrës Coast	Durrës Coast airport transfer	Historic port city with sandy beaches and Roman ruins minutes from the shore.	https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=800	[{"id": "edbfff30-89f2-46a9-9685-dca41d82d4ef", "key": "title", "type": "heading", "level": 1, "heading": "Durrës Coast"}, {"id": "7b174e5b-2aad-4ac3-8c73-0bc927760653", "key": "region", "body": "Adriatic Coast", "type": "text"}, {"id": "3aaf11fe-675d-4568-ac56-63acb4aaac5c", "key": "description", "body": "Historic port city with sandy beaches and Roman ruins minutes from the shore.", "type": "text"}, {"id": "5e1ac365-8d23-4c29-bab7-31821d25c1f4", "alt": "Durrës Coast", "key": "hero", "src": "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=800", "type": "image"}, {"id": "6c64a608-c354-4e6c-ac4f-5202216b1c5c", "key": "badge", "body": "Trending", "type": "text"}, {"id": "c2e7ddd4-c352-43a0-9c6d-ec782683af10", "key": "priceFrom", "body": "€30", "type": "text"}, {"id": "94d29554-b53b-43a1-a365-932e2f6fe11c", "key": "attractions.heading", "type": "heading", "level": 2, "heading": "Top attractions"}, {"id": "6dc07ce2-f110-4254-abf6-ee872248213a", "key": "more.heading", "type": "heading", "level": 2, "heading": "More destinations"}, {"id": "d36a98e4-486e-4446-a918-bd79e2f6f777", "key": "_featured", "body": "featured", "type": "text"}]	2026-08-05 20:54:50.195	2026-08-05 20:54:50.195	en
cmsgkfj2b002cob9nzbgreq5n	destinations/vlore	Destination · Vlorë Riviera	Vlorë Riviera airport transfer	Gateway to the south — turquoise bays, promenades, and sunset views.	https://images.unsplash.com/photo-1519046909924-d93b0f86d5b3?auto=format&fit=crop&q=80&w=800	[{"id": "2b9406be-7a6f-42f7-aad2-e037aca399cc", "key": "title", "type": "heading", "level": 1, "heading": "Vlorë Riviera"}, {"id": "7d7e0bed-5336-47ef-80c0-a68bc612f18e", "key": "region", "body": "Albanian Riviera", "type": "text"}, {"id": "446decab-c54e-41bb-a5f7-7888a5b4dbad", "key": "description", "body": "Gateway to the south — turquoise bays, promenades, and sunset views.", "type": "text"}, {"id": "ab08e90d-9e4e-47ce-a1dd-964d4ec37fec", "alt": "Vlorë Riviera", "key": "hero", "src": "https://images.unsplash.com/photo-1519046909924-d93b0f86d5b3?auto=format&fit=crop&q=80&w=800", "type": "image"}, {"id": "3ace23b6-9f70-42d1-bf80-42c9660c28a9", "key": "badge", "body": "Coastal", "type": "text"}, {"id": "a6b87373-ec71-4960-8fd7-1cc5dd03e734", "key": "priceFrom", "body": "€45", "type": "text"}, {"id": "0179426f-1a7a-41ce-999c-b605354b146a", "key": "attractions.heading", "type": "heading", "level": 2, "heading": "Top attractions"}, {"id": "6e24fd76-352c-4c8b-b7c4-3d58f2536a31", "key": "more.heading", "type": "heading", "level": 2, "heading": "More destinations"}, {"id": "d6effdaa-22a9-4924-8e25-0caa09f1e17a", "key": "_featured", "body": "featured", "type": "text"}]	2026-08-05 20:54:51.203	2026-08-05 20:54:51.203	en
cmsgkfkid002dob9nosvmr6b7	destinations/sarande	Destination · Sarandë Seaside	Sarandë Seaside airport transfer	Lively seaside town facing Corfu, with crystal waters and nightlife.	https://images.unsplash.com/photo-1506953823976-52e1fdc0149a?auto=format&fit=crop&q=80&w=800	[{"id": "6477dbbd-2930-4a3d-aac2-5e83e422f351", "key": "title", "type": "heading", "level": 1, "heading": "Sarandë Seaside"}, {"id": "ea4c7833-9ddf-4958-bc0d-d9bd56ed3aaa", "key": "region", "body": "Southern Coast", "type": "text"}, {"id": "6dc72add-0970-48fd-8b9f-0b686236b15a", "key": "description", "body": "Lively seaside town facing Corfu, with crystal waters and nightlife.", "type": "text"}, {"id": "6c88ad05-6421-46fb-bd87-c76b845acee3", "alt": "Sarandë Seaside", "key": "hero", "src": "https://images.unsplash.com/photo-1506953823976-52e1fdc0149a?auto=format&fit=crop&q=80&w=800", "type": "image"}, {"id": "e8b80841-65e6-4848-9e3a-48010862fb6d", "key": "badge", "body": "Best Value", "type": "text"}, {"id": "5f877022-8d30-49b6-8bb0-aba930a9cab2", "key": "priceFrom", "body": "€55", "type": "text"}, {"id": "d8efd37e-84fc-4e8a-969c-5fd31ae66af1", "key": "attractions.heading", "type": "heading", "level": 2, "heading": "Top attractions"}, {"id": "f6f8ee54-c07b-4ec4-acb1-a875b870b6c9", "key": "more.heading", "type": "heading", "level": 2, "heading": "More destinations"}, {"id": "7498e11d-f209-4acf-b82a-976556aba3e6", "key": "_featured", "body": "featured", "type": "text"}]	2026-08-05 20:54:53.077	2026-08-05 20:54:53.077	en
cmsgkfl6x002eob9nfxikazjz	destinations/ksamil	Destination · Ksamil Islands	Ksamil Islands airport transfer	Iconic turquoise islands and white-sand coves on the Ionian Sea.	https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&q=80&w=800	[{"id": "5da7e86e-de58-41c1-be5a-c0a49e71c16a", "key": "title", "type": "heading", "level": 1, "heading": "Ksamil Islands"}, {"id": "e0047cd5-bda4-4217-93af-e46901ea838a", "key": "region", "body": "Butrint National Park", "type": "text"}, {"id": "62dd02e0-5b2f-464d-83e9-647af5108c90", "key": "description", "body": "Iconic turquoise islands and white-sand coves on the Ionian Sea.", "type": "text"}, {"id": "ced7331a-e06a-49fa-af32-814862149dca", "alt": "Ksamil Islands", "key": "hero", "src": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&q=80&w=800", "type": "image"}, {"id": "d3997972-aa2f-4f87-9dc2-b4e9997246a2", "key": "badge", "body": "Must See", "type": "text"}, {"id": "0e1d9d22-d98f-4e80-a3f7-4cd7954963cb", "key": "priceFrom", "body": "€60", "type": "text"}, {"id": "b7690ead-6e89-482c-ba22-984590a35a3a", "key": "attractions.heading", "type": "heading", "level": 2, "heading": "Top attractions"}, {"id": "07b78075-f7de-41fb-ace5-381301e09e16", "key": "more.heading", "type": "heading", "level": 2, "heading": "More destinations"}, {"id": "de522756-574b-4aca-9aae-0e7dbde4b97b", "key": "_featured", "body": "featured", "type": "text"}]	2026-08-05 20:54:53.961	2026-08-05 20:54:53.961	en
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "bookingId", amount, currency, status, provider, "externalId", "paidAt", "createdAt", "updatedAt", type) FROM stdin;
cmry2z9f0003hlkbn0odw8tam	cmry2z9ev003clkbnqx8ps17f	23.40	EUR	deposit_paid	stripe	pi_trf-5kd0ze	2026-07-22 12:00:00	2026-07-23 22:26:27.565	2026-07-23 22:26:27.565	deposit
cmry2z9fe003xlkbnlwtounym	cmry2z9f8003mlkbn40w729kf	43.50	EUR	deposit_paid	stripe	pi_trf-9wp3lq	2026-07-22 12:00:00	2026-07-23 22:26:27.578	2026-07-23 22:26:27.578	deposit
cmry2z9fh003zlkbno5pmwbok	cmry2z9f8003mlkbn40w729kf	101.50	EUR	paid	stripe	pi_trf-9wp3lq_bal	2026-07-22 18:00:00	2026-07-23 22:26:27.581	2026-07-23 22:26:27.581	balance
cmry2z9g1004clkbnum7wi40d	cmry2z9fv0048lkbn7uoyzc0r	35.40	EUR	deposit_paid	stripe	pi_trf-1ab6yt	2026-07-22 12:00:00	2026-07-23 22:26:27.601	2026-07-23 22:26:27.601	deposit
cmryq62k30005lk9kcudlsa3a	cmryq5lhv0002lk9ks26z915e	19.50	EUR	deposit_paid	stripe	pi_3TwfCMD0vXCx8t6H0fdXScJe	2026-07-24 09:15:36.411	2026-07-24 09:15:36.435	2026-07-24 09:15:36.435	deposit
cmryq98u8000plk9keduubr7o	cmryq5lhv0002lk9ks26z915e	45.50	EUR	fully_paid	manual	cash:cmryq5lhv0002lk9ks26z915e:1784884684533	2026-07-24 09:18:04.533	2026-07-24 09:18:04.544	2026-07-24 09:18:04.544	balance
cmsbxb1r90005lk9m7qp5pcqk	cmsbxadu80002lk9mimqt3zhu	48.00	EUR	fully_paid	stripe	pi_3U00o3D0vXCx8t6H1WQQveW7	2026-08-02 14:56:26.212	2026-08-02 14:56:26.277	2026-08-02 14:56:26.277	balance
cmseg1wdi0005lk9y4piyxp9o	cmseg1f6o0002lk9ycdorsq5t	55.00	EUR	fully_paid	stripe	pi_3U0eSZD0vXCx8t6H031J79pQ	2026-08-04 09:16:44.415	2026-08-04 09:16:44.454	2026-08-04 09:16:44.454	balance
cmsegbfrm000ilk9y6zc21reu	cmsegazvq000flk9y9izogwfm	65.00	EUR	fully_paid	stripe	pi_3U0eZhD0vXCx8t6H0UDWHbmF	2026-08-04 09:24:09.468	2026-08-04 09:24:09.491	2026-08-04 09:24:09.491	balance
cmsghkqht0006ob9nvhmnzhfd	cmsghk9jx0002ob9nnqy7ctx2	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 19:34:55.264	2026-08-05 19:34:55.264	deposit
cmsghv80c000oob9n0b7dmw1l	cmsghk9jx0002ob9nnqy7ctx2	55.00	EUR	fully_paid	manual	cash:cmsghk9jx0002ob9nnqy7ctx2:1785958984516	2026-08-05 19:43:04.516	2026-08-05 19:43:04.525	2026-08-05 19:43:04.525	balance
cmsgi0noy0014ob9nzbg64lub	cmsghzq5d0010ob9n1qn6qmls	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 19:47:18.129	2026-08-05 19:47:18.129	deposit
cmsgi64o7001gob9n2w5aan4u	cmsgi62jh001cob9n63fk9rwv	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 19:51:33.415	2026-08-05 19:51:33.415	deposit
cmsgi8t17001sob9n4x9p753l	cmsgi8q20001oob9ndikhokb0	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 19:53:38.299	2026-08-05 19:53:38.299	deposit
cmsgia6y20024ob9nlb6oypac	cmsgia4y60020ob9n7ue5ub66	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 19:54:42.985	2026-08-05 19:54:42.985	deposit
cmsglx9pn002lob9n6uu7f6ls	cmsglwoak002hob9napjtx8b9	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 21:36:38.507	2026-08-05 21:36:38.507	deposit
cmsgmc3fn0006ob9smgpdek3u	cmsgma8770002ob9spaefubp8	0.00	EUR	unpaid	manual	\N	\N	2026-08-05 21:48:10.21	2026-08-05 21:48:10.21	deposit
cmsh9y3870006ob9nk0xj8ci1	cmsh9xxzp0002ob9nrmdfq0sx	0.00	EUR	unpaid	manual	\N	\N	2026-08-06 08:49:07.542	2026-08-06 08:49:07.542	deposit
cmsha1b8f000tob9n4jn792t9	cmsh9xxzp0002ob9nrmdfq0sx	65.00	EUR	fully_paid	manual	cash:cmsh9xxzp0002ob9nrmdfq0sx:1786006297880	2026-08-06 08:51:37.88	2026-08-06 08:51:37.887	2026-08-06 08:51:37.887	balance
\.


--
-- Data for Name: PaypalOrderIntent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PaypalOrderIntent" (id, "orderId", "bookingId", "paymentOption", "expectedAmount", currency, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PricingRule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PricingRule" (id, "zoneId", "vehicleType", "baseFare", "perKmRate", "minFare", currency, active, "createdAt", "updatedAt") FROM stdin;
cmry2z9a1000alkbnjadazwcg	cmry2z9920001lkbnp5z0niw5	sedan	18.00	0.85	28.00	EUR	t	2026-07-23 22:26:27.385	2026-07-23 22:26:27.385
cmry2z9ab000elkbnete6kyxx	cmry2z9920001lkbnp5z0niw5	minivan	28.00	1.32	43.00	EUR	t	2026-07-23 22:26:27.396	2026-07-23 22:26:27.396
cmry2z9ah000ilkbnepvjdtlt	cmry2z99k0003lkbnxehr7hvb	sedan	28.00	1.10	38.00	EUR	t	2026-07-23 22:26:27.402	2026-07-23 22:26:27.402
cmry2z9an000mlkbnzrfufjus	cmry2z99k0003lkbnxehr7hvb	minivan	43.00	1.71	59.00	EUR	t	2026-07-23 22:26:27.407	2026-07-23 22:26:27.407
cmry2z9as000qlkbnq3r8jgn7	cmry2z99p0004lkbnfdf0qbpy	sedan	42.00	1.35	55.00	EUR	t	2026-07-23 22:26:27.413	2026-07-23 22:26:27.413
cmry2z9ay000ulkbnjlhkrq1c	cmry2z99p0004lkbnfdf0qbpy	minivan	65.00	2.09	85.00	EUR	t	2026-07-23 22:26:27.418	2026-07-23 22:26:27.418
cmry2z9b3000ylkbnpfnp4m4o	cmry2z99u0007lkbn2bv1pcr0	sedan	42.00	1.35	55.00	EUR	t	2026-07-23 22:26:27.424	2026-07-23 22:26:27.424
cmry2z9b90012lkbnyc8pkdmg	cmry2z99u0007lkbn2bv1pcr0	minivan	65.00	2.09	85.00	EUR	t	2026-07-23 22:26:27.429	2026-07-23 22:26:27.429
cmry2z9bf0016lkbn14qdwwo7	cmry2z99q0006lkbnnhs8cany	sedan	52.00	1.55	68.00	EUR	t	2026-07-23 22:26:27.436	2026-07-23 22:26:27.436
cmry2z9bl001alkbnxa17uwfd	cmry2z99q0006lkbnnhs8cany	minivan	81.00	2.40	105.00	EUR	t	2026-07-23 22:26:27.441	2026-07-23 22:26:27.441
cmry2z9br001elkbnjen627nz	cmry2z99p0005lkbnv0tuzomm	sedan	58.00	1.70	78.00	EUR	t	2026-07-23 22:26:27.447	2026-07-23 22:26:27.447
cmry2z9bw001ilkbnj87qjw9b	cmry2z99p0005lkbnv0tuzomm	minivan	90.00	2.63	121.00	EUR	t	2026-07-23 22:26:27.452	2026-07-23 22:26:27.452
cmry2z9c2001mlkbnslji3t1n	cmry2z99i0002lkbnwyhnms54	sedan	58.00	1.70	78.00	EUR	t	2026-07-23 22:26:27.458	2026-07-23 22:26:27.458
cmry2z9c7001qlkbnbmldjax0	cmry2z99i0002lkbnwyhnms54	minivan	90.00	2.63	121.00	EUR	t	2026-07-23 22:26:27.464	2026-07-23 22:26:27.464
cmry2z9cd001ulkbni9zc795e	cmry2z99u0008lkbn2ubhjp13	sedan	72.00	2.05	95.00	EUR	t	2026-07-23 22:26:27.469	2026-07-23 22:26:27.469
cmry2z9ci001ylkbn4cdyhi60	cmry2z99u0008lkbn2ubhjp13	minivan	112.00	3.18	147.00	EUR	t	2026-07-23 22:26:27.474	2026-07-23 22:26:27.474
\.


--
-- Data for Name: PushSubscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PushSubscription" (id, endpoint, p256dh, auth, audience, "ownerId", "userAgent", "createdAt", "updatedAt") FROM stdin;
cmsgmr032000nob9s3yadxsnq	https://fcm.googleapis.com/fcm/send/eiTMk6u0AcM:APA91bEYBNgQFgZQCC3phl_v137dNLVQbyPkWGCdWdJj44vVNqWttnLzIo59KCb2C2f3_E55qwxytdfyVMdxQfYivKcvM2qEeKG1oC1pjgYNQCG6zGBLH0WkrwBWoBLnwJ1_3ySvKaNB	BOXwTLDcdXGr3gAxO5i-xqBcG-z77TZNtG8TPGm7kgq4Q7yGT73uNQ0-ORpIitIiy-4CobLOglalOO-_kBHxy1U	fiYXRO3q6Xf0kM8HF0qEtw	admin	cmry2z98u0000lkbn86mkqlac	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-05 21:59:45.71	2026-08-05 21:59:45.71
\.


--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Review" (id, "bookingId", "driverId", "createdAt", "driverRating", "driverComment", "platformRating", "platformComment", status, "moderatedAt") FROM stdin;
cmry2z9fk0041lkbnqwbmkl46	cmry2z9f8003mlkbn40w729kf	cmry2z9co0025lkbn0ry329so	2026-07-23 22:26:27.585	5	Excellent long-distance transfer.	5	\N	approved	2026-07-24 08:31:00.481
\.


--
-- Data for Name: Settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Settings" (id, "companyName", "supportPhone", "supportEmail", "supportWhatsApp", "displayCurrencies", "freeCancellationHours", "depositPercentage", airports, "notificationChannelsEnabled", "flightDelayThresholdMinutes", "whatsappConnectionStatus", "stripeMode", "paypalMode", "createdAt", "updatedAt", "roundTripDiscountPercent", "stripeEnabled", "paypalEnabled", "cashOnArrivalEnabled", "infantCarrierPrice", "childSeatPrice", "boosterSeatPrice", "paypalSandboxClientId", "paypalSandboxSecret", "paypalLiveClientId", "paypalLiveSecret", "depositPaymentEnabled", "fullPaymentEnabled", "stripeTestPublishableKey", "stripeTestSecretKey", "stripeTestWebhookSecret", "stripeLivePublishableKey", "stripeLiveSecretKey", "stripeLiveWebhookSecret", "adminNotificationEmail", "faviconUrl", "searchIndexingEnabled", "smtpHost", "smtpPort", "smtpSecure", "smtpUser", "smtpPass", "smtpFrom", "smtpTlsRejectUnauthorized", "sedanSeats", "sedanLuggage", "minivanSeats", "minivanLuggage") FROM stdin;
default	Landed in Albania	+355 68 325 6010	support@landedalbania.com	+355 68 325 6010	{EUR}	24	30	[{"name": "Tirana International", "iataCode": "TIA"}]	{"reminder": true, "dateChange": true, "flightDelay": true, "cancellation": true, "confirmation": true, "reviewRequest": true, "driverAssigned": true, "completedReceipt": true}	45	disconnected	test	test	2026-07-23 22:26:27.486	2026-08-06 08:53:34.103	0	t	f	t	10.00	12.00	8.00					t	t	pk_test_51Tu83cD0vXCx8t6HdYUOber63Q7Ro5ey1qV3sfvlNVrfZidpwsW0Jaan5oNVJoD7blQ7wypeWSkVSBYGNkJruTfk00ZjtlZB4H	sk_test_51Tu83cD0vXCx8t6HXw2V6FA4cOpQRTtzkXEeBRJJvtmfrlxaldOCk5Yhzr7ul6LPGjzRIb2zQ8CsqYO1qm8dw1Rg00nbP5C9AL					support@landedalbania.com		f	premium257.web-hosting.com	465	t	no-reply@landedalbania.com	enc:v1:qZ7dy9qCz2b5aTJf.LNW1_NzjknQ1_4UtaJ659w.ik_xY39NAhhPsijz-S2UiQ	Landed in Albania <no-reply@landedalbania.com>	t	4	3	6	6
\.


--
-- Data for Name: StaffNotification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StaffNotification" (id, audience, "ownerId", type, title, body, url, "bookingId", "readAt", "createdAt") FROM stdin;
cmsh7nhjv001wob9s2lngb8x6	driver	cmry2z9co0023lkbnuo6p7xma	driver_assigned	New trip — accept or reject	TRF-337692\nTirana International (TIA) → Durrës\nThu 06 Aug, 14:44	/driver?bookingId=cmsh7n8wc001nob9s4bi0oyce	cmsh7n8wc001nob9s4bi0oyce	\N	2026-08-06 07:44:53.659
cmryq7wro000flk9kpmk6grv1	driver	cmry2z9co0023lkbnuo6p7xma	driver_assigned	New trip — accept or reject	TRF-8F4E7E\nTirana International (TIA) → Berat\nFri 24 Jul, 11:10	/driver?bookingId=cmryq5lhv0002lk9ks26z915e	cmryq5lhv0002lk9ks26z915e	\N	2026-07-24 09:17:02.245
cmsh7n920001pob9s8xx5jwag	admin	\N	new_booking	New booking	TRF-337692 · Alket\nTirana International (TIA) → Durrës	/admin/bookings?bookingId=cmsh7n8wc001nob9s4bi0oyce	cmsh7n8wc001nob9s4bi0oyce	2026-08-06 07:45:41.631	2026-08-06 07:44:42.649
cmsh9zgnm000eob9nqwyd84zh	driver	cmry2z9co0023lkbnuo6p7xma	driver_assigned	New trip — accept or reject	TRF-DF371C\nTirana International (TIA) → Berat\nThu 13 Aug, 11:45	/driver?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	cmsh9xxzp0002ob9nrmdfq0sx	\N	2026-08-06 08:50:11.602
cmsh9zy04000hob9n16yeo51v	admin	\N	driver_accepted	Driver accepted trip	TRF-337692 · Ana Krasniqi\nTirana International (TIA) → Durrës	/admin/bookings?bookingId=cmsh7n8wc001nob9s4bi0oyce	cmsh7n8wc001nob9s4bi0oyce	2026-08-06 08:50:42.341	2026-08-06 08:50:34.085
cmsh9y3ap0007ob9nfrvng2yo	admin	\N	new_booking	New booking	TRF-DF371C · Alket Shyti\nTirana International (TIA) → Berat	/admin/bookings?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	cmsh9xxzp0002ob9nrmdfq0sx	2026-08-06 08:51:01.761	2026-08-06 08:49:07.634
cmsha0y6u000mob9nhxmlvaaz	admin	\N	driver_accepted	Driver accepted trip	TRF-DF371C · Ana Krasniqi\nTirana International (TIA) → Berat	/admin/bookings?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	cmsh9xxzp0002ob9nrmdfq0sx	2026-08-06 08:51:27.116	2026-08-06 08:51:20.982
cmsha19o9000rob9ntugutfgf	admin	\N	driver_arrived	Driver marked arrived	TRF-DF371C · Ana Krasniqi\nTirana International (TIA) → Berat	/admin/bookings?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	cmsh9xxzp0002ob9nrmdfq0sx	2026-08-06 08:53:42.767	2026-08-06 08:51:35.866
cmsha1b8s000uob9nedkxer0d	admin	\N	cash_paid	Cash paid confirmed	TRF-DF371C · Ana Krasniqi collected 65.00 EUR	/admin/bookings?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	cmsh9xxzp0002ob9nrmdfq0sx	2026-08-06 08:53:42.767	2026-08-06 08:51:37.9
cmsha1c8k000xob9nuwz5nlld	admin	\N	trip_completed	Trip completed	TRF-DF371C · Ana Krasniqi\nTirana International (TIA) → Berat	/admin/bookings?bookingId=cmsh9xxzp0002ob9nrmdfq0sx	cmsh9xxzp0002ob9nrmdfq0sx	2026-08-06 08:53:42.767	2026-08-06 08:51:39.188
cmshcon2u001kob9nupm26clt	driver	cmry2z9co0023lkbnuo6p7xma	driver_assigned	New trip — accept or reject	TRF-3B6A17\nTirana International (TIA) → Berat\nThu 06 Aug, 22:45	/driver?bookingId=cmsghzq5d0010ob9n1qn6qmls	cmsghzq5d0010ob9n1qn6qmls	\N	2026-08-06 10:05:45.558
cmsghmmlk000eob9n9ndwhbbm	driver	cmry2z9co0023lkbnuo6p7xma	driver_assigned	New trip — accept or reject	TRF-2A1926\nTirana International (TIA) → Berat\nThu 06 Aug, 22:30	/driver?bookingId=cmsghk9jx0002ob9nnqy7ctx2	cmsghk9jx0002ob9nnqy7ctx2	\N	2026-08-05 19:36:23.528
cmshcpl5s001nob9ni7239jd1	admin	\N	driver_accepted	Driver accepted trip	TRF-3B6A17 · Ana Krasniqi\nTirana International (TIA) → Berat	/admin/bookings?bookingId=cmsghzq5d0010ob9n1qn6qmls	cmsghzq5d0010ob9n1qn6qmls	2026-08-06 12:29:28.13	2026-08-06 10:06:29.728
cmshdoi9r001wob9nj7y7nmnn	admin	\N	booking_cancelled	Booking cancelled	TRF-QA5649 · QA SelfService opencancel\nTIA Airport → Durrës Center	/admin/bookings?bookingId=bd4d73b7180594cf59e6a55a5	bd4d73b7180594cf59e6a55a5	2026-08-06 12:29:28.13	2026-08-06 10:33:38.943
cmshdojgj0027ob9nb8snxwvn	admin	\N	date_change	Pickup time changed	TRF-QA2A66 · QA SelfService openedit\nSun 09 Aug, 12:33 → Tue 11 Aug, 12:33	/admin/bookings?bookingId=bd00ad857df472fd8e22fc06f	bd00ad857df472fd8e22fc06f	2026-08-06 12:29:28.13	2026-08-06 10:33:40.483
cmshdojzm0028ob9ndfg1zae3	admin	\N	booking_cancelled	Booking cancelled	TRF-QAD85B · QA SelfService race\nTIA Airport → Durrës Center	/admin/bookings?bookingId=bed52d567ba9210edf14d911d	bed52d567ba9210edf14d911d	2026-08-06 12:29:28.13	2026-08-06 10:33:41.17
cmshdpqkh002fob9nooq4u5xs	admin	\N	booking_cancelled	Booking cancelled	TRF-QRA0FA · QA Race\nTIA → Durres	/admin/bookings?bookingId=b081578db9dcb503a49211d72	b081578db9dcb503a49211d72	2026-08-06 12:29:28.13	2026-08-06 10:34:36.354
cmshdps4n002mob9n5h8nq7v0	admin	\N	booking_cancelled	Booking cancelled	TRF-QRDB4F · QA Race\nTIA → Durres	/admin/bookings?bookingId=bf674ea471dbfc08d03c58c8c	bf674ea471dbfc08d03c58c8c	2026-08-06 12:29:28.13	2026-08-06 10:34:38.375
cmshdq2k30046ob9ncvu5z5n8	admin	\N	booking_cancelled	Booking cancelled	TRF-QR3188 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b9cc8cf526b5656d186781210	b9cc8cf526b5656d186781210	2026-08-06 12:29:28.13	2026-08-06 10:34:51.891
cmshdq6mq004rob9n6531fczp	admin	\N	booking_cancelled	Booking cancelled	TRF-QRC04B · QA Race\nTIA → Durres	/admin/bookings?bookingId=bd0a75ba5eab94f5b7eaa3840	bd0a75ba5eab94f5b7eaa3840	2026-08-06 12:29:28.13	2026-08-06 10:34:57.17
cmshdqc95005job9nbo08a2k5	admin	\N	booking_cancelled	Booking cancelled	TRF-QRA248 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b60251d73c4529d99af20f329	b60251d73c4529d99af20f329	2026-08-06 12:29:28.13	2026-08-06 10:35:04.457
cmshdqdqz005qob9nh83a0ji7	admin	\N	booking_cancelled	Booking cancelled	TRF-QR5757 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bff616afad03ede0f01678bd4	bff616afad03ede0f01678bd4	2026-08-06 12:29:28.13	2026-08-06 10:35:06.395
cmshdqf1d005xob9nlydfu3lg	admin	\N	booking_cancelled	Booking cancelled	TRF-QRCE28 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b24deb34c0642dcfa6ecb8937	b24deb34c0642dcfa6ecb8937	2026-08-06 12:29:28.13	2026-08-06 10:35:08.066
cmshdvkz800byob9n4bg4stqg	admin	\N	booking_cancelled	Booking cancelled	TRF-FX2554 · QA Fix r8\nTIA → Durres	/admin/bookings?bookingId=b3e6d1fb993ce01abe37b2780	b3e6d1fb993ce01abe37b2780	2026-08-06 12:29:28.13	2026-08-06 10:39:09.045
cmshdvo6700ccob9ngqqwbobm	admin	\N	booking_cancelled	Booking cancelled	TRF-FXF6AC · QA Fix r10\nTIA → Durres	/admin/bookings?bookingId=b86405875bc0a7a2c83fce45f	b86405875bc0a7a2c83fce45f	2026-08-06 12:29:28.13	2026-08-06 10:39:13.183
cmshdvqod00cqob9nzyrig6l7	admin	\N	booking_cancelled	Booking cancelled	TRF-FX86D9 · QA Fix r12\nTIA → Durres	/admin/bookings?bookingId=bb8e0c4710cd334339f110e92	bb8e0c4710cd334339f110e92	2026-08-06 12:29:28.13	2026-08-06 10:39:16.429
cmshdvtw200d4ob9nhqw8zgnp	admin	\N	booking_cancelled	Booking cancelled	TRF-FX6DEF · QA Fix r14\nTIA → Durres	/admin/bookings?bookingId=b7bcb0af35e9c4b884739a5cd	b7bcb0af35e9c4b884739a5cd	2026-08-06 12:29:28.13	2026-08-06 10:39:20.595
cmshdvw1w00dbob9n9ia2yhkc	admin	\N	booking_cancelled	Booking cancelled	TRF-FXDA6F · QA Fix r15\nTIA → Durres	/admin/bookings?bookingId=bedbc3ae9054c0d2ff5c890ff	bedbc3ae9054c0d2ff5c890ff	2026-08-06 12:29:28.13	2026-08-06 10:39:23.396
cmshdvxk400diob9n28b7i1ql	admin	\N	booking_cancelled	Booking cancelled	TRF-FX945C · QA Fix r16\nTIA → Durres	/admin/bookings?bookingId=bef2359225d560d7bc1443912	bef2359225d560d7bc1443912	2026-08-06 12:29:28.13	2026-08-06 10:39:25.348
cmshdvz3q00dpob9n71rhz3a1	admin	\N	booking_cancelled	Booking cancelled	TRF-FXB920 · QA Fix r17\nTIA → Durres	/admin/bookings?bookingId=ba07bee894d416ae8f79d07c2	ba07bee894d416ae8f79d07c2	2026-08-06 12:29:28.13	2026-08-06 10:39:27.35
cmshdw83300evob9nivf7uufh	admin	\N	booking_cancelled	Booking cancelled	TRF-FX029F · QA Fix r23\nTIA → Durres	/admin/bookings?bookingId=beca83acd016d5f5151a7570e	beca83acd016d5f5151a7570e	2026-08-06 12:29:28.13	2026-08-06 10:39:38.991
cmshdw9m200f2ob9n6bsjkho8	admin	\N	booking_cancelled	Booking cancelled	TRF-FX709F · QA Fix r24\nTIA → Durres	/admin/bookings?bookingId=bd1b2d9b198a59ed50ecb8cce	bd1b2d9b198a59ed50ecb8cce	2026-08-06 12:29:28.13	2026-08-06 10:39:40.97
cmshdpt7h002tob9nji1qeuts	admin	\N	booking_cancelled	Booking cancelled	TRF-QR7E00 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bdb23c1f28687d41a3b746d1c	bdb23c1f28687d41a3b746d1c	2026-08-06 12:29:28.13	2026-08-06 10:34:39.773
cmshdpurb0030ob9nmfodywla	admin	\N	booking_cancelled	Booking cancelled	TRF-QR891F · QA Race\nTIA → Durres	/admin/bookings?bookingId=b373cf8b240ff01bb8faff4af	b373cf8b240ff01bb8faff4af	2026-08-06 12:29:28.13	2026-08-06 10:34:41.783
cmshdpw250037ob9nqai18fpv	admin	\N	booking_cancelled	Booking cancelled	TRF-QR04A2 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b75fc11e4fa415b398705e12f	b75fc11e4fa415b398705e12f	2026-08-06 12:29:28.13	2026-08-06 10:34:43.47
cmshdpxc7003eob9nc69lzwlz	admin	\N	booking_cancelled	Booking cancelled	TRF-QR3AD7 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b4668166c58af7b5bdf3feea2	b4668166c58af7b5bdf3feea2	2026-08-06 12:29:28.13	2026-08-06 10:34:45.127
cmshdpygz003lob9nc1sx88sz	admin	\N	booking_cancelled	Booking cancelled	TRF-QR213D · QA Race\nTIA → Durres	/admin/bookings?bookingId=bb7db77e5131852cb6af44ee4	bb7db77e5131852cb6af44ee4	2026-08-06 12:29:28.13	2026-08-06 10:34:46.596
cmshdpzpy003sob9nfpqcvd24	admin	\N	booking_cancelled	Booking cancelled	TRF-QR4104 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b9d4e07e8325745386fe0a8f7	b9d4e07e8325745386fe0a8f7	2026-08-06 12:29:28.13	2026-08-06 10:34:48.215
cmshdq15l003zob9nhxsxf2lo	admin	\N	booking_cancelled	Booking cancelled	TRF-QR96E8 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b00aa0f0c336401d37b2222ad	b00aa0f0c336401d37b2222ad	2026-08-06 12:29:28.13	2026-08-06 10:34:50.074
cmshdq3zw004dob9nb2rrpsup	admin	\N	booking_cancelled	Booking cancelled	TRF-QRFFAC · QA Race\nTIA → Durres	/admin/bookings?bookingId=b37f0cda463bfb7c72c57ed5b	b37f0cda463bfb7c72c57ed5b	2026-08-06 12:29:28.13	2026-08-06 10:34:53.756
cmshdq5a7004kob9nvmcttvp0	admin	\N	booking_cancelled	Booking cancelled	TRF-QRA089 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b3c7ed092bfe236dcc7c66032	b3c7ed092bfe236dcc7c66032	2026-08-06 12:29:28.13	2026-08-06 10:34:55.423
cmshdq7ue004yob9n17j9mji4	admin	\N	booking_cancelled	Booking cancelled	TRF-QRA5AE · QA Race\nTIA → Durres	/admin/bookings?bookingId=b13111911dd1adba625f88820	b13111911dd1adba625f88820	2026-08-06 12:29:28.13	2026-08-06 10:34:58.742
cmshdq91r0055ob9ni3skqqrm	admin	\N	booking_cancelled	Booking cancelled	TRF-QRAC84 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bb19c06770e486d81648b179d	bb19c06770e486d81648b179d	2026-08-06 12:29:28.13	2026-08-06 10:35:00.303
cmshdqa08005cob9n7g99c4nz	admin	\N	booking_cancelled	Booking cancelled	TRF-QRD825 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b3305f8291fd024b32826f2a1	b3305f8291fd024b32826f2a1	2026-08-06 12:29:28.13	2026-08-06 10:35:01.544
cmshdqgcn0064ob9nihc81w8l	admin	\N	booking_cancelled	Booking cancelled	TRF-QR7897 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b0edb477009662d31aacdd384	b0edb477009662d31aacdd384	2026-08-06 12:29:28.13	2026-08-06 10:35:09.768
cmshdqhbo006bob9nqpy0vnaf	admin	\N	booking_cancelled	Booking cancelled	TRF-QR7FE9 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b26534eda53a6175590d8acbc	b26534eda53a6175590d8acbc	2026-08-06 12:29:28.13	2026-08-06 10:35:11.028
cmshdqis1006iob9nlvva95vx	admin	\N	booking_cancelled	Booking cancelled	TRF-QR3A10 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bcfb7d0775c925ddf43d42a8f	bcfb7d0775c925ddf43d42a8f	2026-08-06 12:29:28.13	2026-08-06 10:35:12.913
cmshdqjrd006pob9njf6v6wz7	admin	\N	booking_cancelled	Booking cancelled	TRF-QR2C61 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b1cd4e4de6cc981a6c3839c6a	b1cd4e4de6cc981a6c3839c6a	2026-08-06 12:29:28.13	2026-08-06 10:35:14.185
cmshdql6l006wob9nefrhk799	admin	\N	booking_cancelled	Booking cancelled	TRF-QRBED8 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b27ca516635742ba69f40bdca	b27ca516635742ba69f40bdca	2026-08-06 12:29:28.13	2026-08-06 10:35:16.03
cmshdqm5r0073ob9nyiuyw8bw	admin	\N	booking_cancelled	Booking cancelled	TRF-QR54A4 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b08cac17ce2fedf2d95bb23ac	b08cac17ce2fedf2d95bb23ac	2026-08-06 12:29:28.13	2026-08-06 10:35:17.295
cmshdqnl0007aob9noqmxpicb	admin	\N	booking_cancelled	Booking cancelled	TRF-QRDF47 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b518b585cd6eb693610858b57	b518b585cd6eb693610858b57	2026-08-06 12:29:28.13	2026-08-06 10:35:19.141
cmshdqok9007hob9n90cbqnyr	admin	\N	booking_cancelled	Booking cancelled	TRF-QR34F3 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bd2c96ff813a8dc69b6a5e88c	bd2c96ff813a8dc69b6a5e88c	2026-08-06 12:29:28.13	2026-08-06 10:35:20.41
cmshdqq26007oob9nk85colu0	admin	\N	booking_cancelled	Booking cancelled	TRF-QR1E58 · QA Race\nTIA → Durres	/admin/bookings?bookingId=baa9b5485d7a2564866a8552b	baa9b5485d7a2564866a8552b	2026-08-06 12:29:28.13	2026-08-06 10:35:22.351
cmshdqrcz007vob9n0zwtiks0	admin	\N	booking_cancelled	Booking cancelled	TRF-QR2C3E · QA Race\nTIA → Durres	/admin/bookings?bookingId=b4c45f9ef18de0ee2c0d70583	b4c45f9ef18de0ee2c0d70583	2026-08-06 12:29:28.13	2026-08-06 10:35:24.036
cmshdqsnn0082ob9n07nzge9p	admin	\N	booking_cancelled	Booking cancelled	TRF-QR5CB9 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bc2d4690a582ced2861c30539	bc2d4690a582ced2861c30539	2026-08-06 12:29:28.13	2026-08-06 10:35:25.716
cmshdqu3s0089ob9nsbtw63zy	admin	\N	booking_cancelled	Booking cancelled	TRF-QRAEE0 · QA Race\nTIA → Durres	/admin/bookings?bookingId=bd8f4e7d1b931e356ca3b6d94	bd8f4e7d1b931e356ca3b6d94	2026-08-06 12:29:28.13	2026-08-06 10:35:27.592
cmshdqvqn008gob9n1hjymk39	admin	\N	booking_cancelled	Booking cancelled	TRF-QR8A4F · QA Race\nTIA → Durres	/admin/bookings?bookingId=b54832ce955df2b5851877902	b54832ce955df2b5851877902	2026-08-06 12:29:28.13	2026-08-06 10:35:29.711
cmshdqxiy008nob9ns0g1ufk9	admin	\N	booking_cancelled	Booking cancelled	TRF-QRD05F · QA Race\nTIA → Durres	/admin/bookings?bookingId=b14cc43b57e89c28db87cface	b14cc43b57e89c28db87cface	2026-08-06 12:29:28.13	2026-08-06 10:35:32.026
cmshdqykc008uob9nw63dj1l1	admin	\N	booking_cancelled	Booking cancelled	TRF-QR8852 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b40b224637d345052d5c1150d	b40b224637d345052d5c1150d	2026-08-06 12:29:28.13	2026-08-06 10:35:33.372
cmshdqzzk0091ob9ni1dclldy	admin	\N	booking_cancelled	Booking cancelled	TRF-QR23FD · QA Race\nTIA → Durres	/admin/bookings?bookingId=b824fa089f50f96b76b0cccc0	b824fa089f50f96b76b0cccc0	2026-08-06 12:29:28.13	2026-08-06 10:35:35.217
cmshdr26y0098ob9nx3xw90mj	admin	\N	booking_cancelled	Booking cancelled	TRF-QRA46C · QA Race\nTIA → Durres	/admin/bookings?bookingId=bb14e9bc7914690e7f8b30b68	bb14e9bc7914690e7f8b30b68	2026-08-06 12:29:28.13	2026-08-06 10:35:38.075
cmshdr3fv009fob9nj3ajn57i	admin	\N	booking_cancelled	Booking cancelled	TRF-QRB6F4 · QA Race\nTIA → Durres	/admin/bookings?bookingId=b8c12ccdd0c7999af42302bfc	b8c12ccdd0c7999af42302bfc	2026-08-06 12:29:28.13	2026-08-06 10:35:39.691
cmshdr4j0009mob9nsr4y32or	admin	\N	booking_cancelled	Booking cancelled	TRF-QR3CEE · QA Race\nTIA → Durres	/admin/bookings?bookingId=b58b5dc90cde19f28d2c48bab	b58b5dc90cde19f28d2c48bab	2026-08-06 12:29:28.13	2026-08-06 10:35:41.101
cmshdr5yi009tob9n1ktopr8w	admin	\N	booking_cancelled	Booking cancelled	TRF-QRE69F · QA Race\nTIA → Durres	/admin/bookings?bookingId=be52eb2af05a2a475235fb644	be52eb2af05a2a475235fb644	2026-08-06 12:29:28.13	2026-08-06 10:35:42.955
cmshdr7de00a0ob9nqvdilkix	admin	\N	booking_cancelled	Booking cancelled	TRF-QRE5DB · QA Race\nTIA → Durres	/admin/bookings?bookingId=bebfbb27aaed27c034a5381c8	bebfbb27aaed27c034a5381c8	2026-08-06 12:29:28.13	2026-08-06 10:35:44.787
cmshdv46400a7ob9n4hhnac06	admin	\N	booking_cancelled	Booking cancelled	TRF-FXB00C · QA Fix open\nTIA → Durres	/admin/bookings?bookingId=b7c9e9074f1e85e39342d5968	b7c9e9074f1e85e39342d5968	2026-08-06 12:29:28.13	2026-08-06 10:38:47.26
cmshdv89u00aeob9nd3ivzwyj	admin	\N	booking_cancelled	Booking cancelled	TRF-FX6092 · QA Fix r0\nTIA → Durres	/admin/bookings?bookingId=b936fa93028af7ee58bfa421b	b936fa93028af7ee58bfa421b	2026-08-06 12:29:28.13	2026-08-06 10:38:52.578
cmshdva8c00alob9nnnfa4tpy	admin	\N	booking_cancelled	Booking cancelled	TRF-FX392D · QA Fix r1\nTIA → Durres	/admin/bookings?bookingId=bd8cb0590c9f91039dc6e80e2	bd8cb0590c9f91039dc6e80e2	2026-08-06 12:29:28.13	2026-08-06 10:38:55.116
cmshdvcff00asob9nhwd1o7zm	admin	\N	booking_cancelled	Booking cancelled	TRF-FXA5E6 · QA Fix r2\nTIA → Durres	/admin/bookings?bookingId=b6701f18bf5a7f57e892ce9d4	b6701f18bf5a7f57e892ce9d4	2026-08-06 12:29:28.13	2026-08-06 10:38:57.963
cmshdvdpj00azob9netdipi4f	admin	\N	booking_cancelled	Booking cancelled	TRF-FX8472 · QA Fix r3\nTIA → Durres	/admin/bookings?bookingId=bbbee8cacf05f71f822a97551	bbbee8cacf05f71f822a97551	2026-08-06 12:29:28.13	2026-08-06 10:38:59.624
cmshdverf00b6ob9n8f8pp4qs	admin	\N	booking_cancelled	Booking cancelled	TRF-FXA909 · QA Fix r4\nTIA → Durres	/admin/bookings?bookingId=b60cd3ee24dc5069b5ff9e01b	b60cd3ee24dc5069b5ff9e01b	2026-08-06 12:29:28.13	2026-08-06 10:39:00.987
cmshdvgol00bdob9nn49qwgk6	admin	\N	booking_cancelled	Booking cancelled	TRF-FXDD29 · QA Fix r5\nTIA → Durres	/admin/bookings?bookingId=bae9748a82cd7c6f7f896130e	bae9748a82cd7c6f7f896130e	2026-08-06 12:29:28.13	2026-08-06 10:39:03.477
cmshdvif900bkob9ng1uvkggc	admin	\N	booking_cancelled	Booking cancelled	TRF-FXD28F · QA Fix r6\nTIA → Durres	/admin/bookings?bookingId=bc41eb745a1b0e1a1321009f2	bc41eb745a1b0e1a1321009f2	2026-08-06 12:29:28.13	2026-08-06 10:39:05.733
cmshdvjpj00brob9ny7wy3ezh	admin	\N	booking_cancelled	Booking cancelled	TRF-FX7C7B · QA Fix r7\nTIA → Durres	/admin/bookings?bookingId=bc5ab2dd6b65fe01f07160929	bc5ab2dd6b65fe01f07160929	2026-08-06 12:29:28.13	2026-08-06 10:39:07.4
cmshdvmmu00c5ob9nk8qx7h29	admin	\N	booking_cancelled	Booking cancelled	TRF-FX1E2A · QA Fix r9\nTIA → Durres	/admin/bookings?bookingId=b43efca6b5ee15373b2fd63e1	b43efca6b5ee15373b2fd63e1	2026-08-06 12:29:28.13	2026-08-06 10:39:11.19
cmshdvpek00cjob9n8i0lis8j	admin	\N	booking_cancelled	Booking cancelled	TRF-FXFF6F · QA Fix r11\nTIA → Durres	/admin/bookings?bookingId=bde558074d2bf0ca19653fb0c	bde558074d2bf0ca19653fb0c	2026-08-06 12:29:28.13	2026-08-06 10:39:14.78
cmshdvsg200cxob9n2p52ael5	admin	\N	booking_cancelled	Booking cancelled	TRF-FXF2BF · QA Fix r13\nTIA → Durres	/admin/bookings?bookingId=bbe24b2d8d3f022702308acbb	bbe24b2d8d3f022702308acbb	2026-08-06 12:29:28.13	2026-08-06 10:39:18.722
cmshdw0ih00dwob9ns5g1lhba	admin	\N	booking_cancelled	Booking cancelled	TRF-FX5A48 · QA Fix r18\nTIA → Durres	/admin/bookings?bookingId=baf6b2ee3bfa343eaf7874c30	baf6b2ee3bfa343eaf7874c30	2026-08-06 12:29:28.13	2026-08-06 10:39:29.178
cmshdw2kr00e3ob9n0gtde0kr	admin	\N	booking_cancelled	Booking cancelled	TRF-FX09E9 · QA Fix r19\nTIA → Durres	/admin/bookings?bookingId=be600f4b3cd61d803f27847c2	be600f4b3cd61d803f27847c2	2026-08-06 12:29:28.13	2026-08-06 10:39:31.852
cmshdw3zf00eaob9nou7zu9wh	admin	\N	booking_cancelled	Booking cancelled	TRF-FXB6FD · QA Fix r20\nTIA → Durres	/admin/bookings?bookingId=bcdd849a67a5da5f80f9141f3	bcdd849a67a5da5f80f9141f3	2026-08-06 12:29:28.13	2026-08-06 10:39:33.675
cmshdw5c000ehob9ndkb6y0r7	admin	\N	booking_cancelled	Booking cancelled	TRF-FX5411 · QA Fix r21\nTIA → Durres	/admin/bookings?bookingId=b46e2e185cd084118b6c775e9	b46e2e185cd084118b6c775e9	2026-08-06 12:29:28.13	2026-08-06 10:39:35.425
cmshdw6gf00eoob9nh4na6e3j	admin	\N	booking_cancelled	Booking cancelled	TRF-FXA06F · QA Fix r22\nTIA → Durres	/admin/bookings?bookingId=b9cc12a1367105ee507e0860e	b9cc12a1367105ee507e0860e	2026-08-06 12:29:28.13	2026-08-06 10:39:36.88
\.


--
-- Data for Name: Zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Zone" (id, name, active, "createdAt", "updatedAt") FROM stdin;
cmry2z9920001lkbnp5z0niw5	Tirana City	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99i0002lkbnwyhnms54	Ksamil	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99k0003lkbnxehr7hvb	Durrës	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99p0004lkbnfdf0qbpy	Vlorë	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99p0005lkbnv0tuzomm	Sarandë	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99q0006lkbnnhs8cany	Shkodër	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99u0007lkbn2bv1pcr0	Berat	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
cmry2z99u0008lkbn2ubhjp13	Theth / Albanian Alps	t	2026-07-23 22:26:27.351	2026-07-23 22:26:27.351
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
af7b8ff5-8a0c-4dd1-be18-60ec45c5f396	832ab3b8dee0b02ae82ef58c7a2476c47a78f718b8a50ce9945848b98f704111	2026-08-04 07:24:41.094159+00	20260804010000_settings_favicon	\N	\N	2026-08-04 07:24:40.908882+00	1
a8329229-2354-4217-af40-2efc77b87a8e	0029fd6faaf45e0706c5c2a41104e3cb3b1cfd30dd3e6445de253d1f4cf79211	2026-07-23 21:33:38.204709+00	20260716082630_init_admin_user	\N	\N	2026-07-23 21:33:38.141639+00	1
20319914-dd85-4746-b41d-9938b0949702	7144fa24c930d51e7768f78f0fa77502524c424054f7d3a050bf6880615f9143	2026-07-23 21:33:39.207034+00	20260718150000_customer_email_unique	\N	\N	2026-07-23 21:33:39.175477+00	1
f2cfdaa2-9940-4b83-a975-9699787e72c1	473a1d5ccd4d87c6cdb31d2c37eb88c368f93462888d3169aa6ebde943b3d105	2026-07-23 21:33:38.759423+00	20260716083310_full_schema	\N	\N	2026-07-23 21:33:38.209492+00	1
3a318080-bb2f-4e29-a239-86e84e3176e6	0744c2dd4953f3f9ef36be51c71ce3222d704b7337a69bf3cc65af3b824ef696	2026-07-23 21:33:38.780227+00	20260716121500_settings_payment_methods	\N	\N	2026-07-23 21:33:38.763373+00	1
704498c2-5359-42c4-adec-4c774397f436	ad43fa84144d41777325b172c889737a880431df0c28be05c5bf04c4e07604a8	2026-07-27 13:00:38.648417+00	20260725180000_page_content	\N	\N	2026-07-27 13:00:38.425658+00	1
090a78f0-773e-4891-b7aa-56db646cf11f	360faa547cb0fa12c86c9640237e4b3288e610a3bc3c98e426ee0b31dba0989c	2026-07-23 21:33:38.821399+00	20260716143000_booking_pickup_pin	\N	\N	2026-07-23 21:33:38.787289+00	1
75a8789e-b406-4579-97e7-a5d428573537	64590c9def0ff26775f5528e2007e405a46b61701e8236d73b458b08b0eeefe8	2026-07-23 21:33:39.243214+00	20260718210000_sync_booking_payment_schema	\N	\N	2026-07-23 21:33:39.213722+00	1
879fa534-2b1e-4eca-ab01-252335f982f4	88a7cde3b0ecd5771328e4bfb4f10b417762d4cdfd5402d0fae2f8ec10fb1d56	2026-07-23 21:33:38.847067+00	20260716152000_child_seat_prices	\N	\N	2026-07-23 21:33:38.825387+00	1
dd5dc6a4-ffb1-4936-9b79-147a1cf72a7d	ce6db38d6c874c7acfc4d4b8de05ceac8ea531835f52d2d0d36440e83447a3fb	2026-07-23 21:33:38.874342+00	20260717100000_admin_role	\N	\N	2026-07-23 21:33:38.853347+00	1
04fdc9bf-99a7-481e-bb6b-674483ddde2c	00f9a973a2d8c36be2142bb65beb8d9b74d2002c8d2c50ede35ccfc45544de23	2026-07-23 21:33:38.895692+00	20260717110000_admin_suspended	\N	\N	2026-07-23 21:33:38.880895+00	1
8662580c-0699-4e0d-89cc-2207f1e341ce	59aece13b953e4fc644ea5fa60a46c8b9936889fb3c60953ee5f7615da3b201f	2026-07-23 21:33:39.277829+00	20260719120000_remove_zone_centroids	\N	\N	2026-07-23 21:33:39.247847+00	1
0f463bbc-2616-486b-b22c-0c8cbc014498	cc80b413de418737f4ac50abd7c600fd3ed62ad5a0b58e3ac0f9ac18209203a9	2026-07-23 21:33:38.981128+00	20260717120000_paypal_config	\N	\N	2026-07-23 21:33:38.899609+00	1
e1d8c41d-50a1-48ce-9606-d4a3fae8f859	8d33eec85eb52d2fec133c5ce350775b019457a61aae144d49c15e236e07ffd2	2026-07-23 21:33:39.004118+00	20260717130000_payment_options	\N	\N	2026-07-23 21:33:38.985142+00	1
7e9bcad6-c27e-4bbe-aca1-b492c1d04252	f8097e02836bf70a85bda8dae4c7b9bede63511d0500c1a77b33c8a10e094e3c	2026-07-23 21:33:39.035829+00	20260717140000_stripe_config	\N	\N	2026-07-23 21:33:39.010971+00	1
db92daaf-4e6b-4e13-9735-1aef6b99ac38	619cc8580a4ee5dd37f94267c0a58462dbeca6848893443b2234a2d09dd6c49d	2026-07-23 21:33:39.302709+00	20260720120000_admin_requires_password_reset	\N	\N	2026-07-23 21:33:39.284245+00	1
99e5abf2-4dfd-4932-8d89-3810b9918526	de4d0698022dd445e2be28339a7e17710af17c011cf4f3ab04debbbd3cfcc494	2026-07-23 21:33:39.066174+00	20260717150000_driver_pin_status_flow	\N	\N	2026-07-23 21:33:39.039724+00	1
b1b2ca7b-9fd1-4b96-b6e5-7073773dc300	1b537c5714178680acb7a8a2956b4f84051f9fc47b524198531ba88adb29ea37	2026-07-23 21:33:39.142518+00	20260718100000_push_and_driver_accepted	\N	\N	2026-07-23 21:33:39.073003+00	1
b21d34cf-a4b1-4ee4-ab0c-ede20b70dfc4	2999ed1a18b87c2a97071d3e009c68e2fce8e0637bbc870d333511ea84c43fbe	2026-07-27 13:00:38.686259+00	20260726160000_media_asset	\N	\N	2026-07-27 13:00:38.651822+00	1
3ace08d7-24bb-42eb-997b-37c282b576c9	80d78f9033678116b352b9937905e182ece5084d85a52a5900fbf39d84b23b45	2026-07-23 21:33:39.171501+00	20260718140000_customer_stripe_id	\N	\N	2026-07-23 21:33:39.149232+00	1
0506031f-ba74-464b-ad04-fe8c19d37408	c94c99e65bb147c666d09c4169219b11d00c9b02b7445c422545c6d482d11487	2026-07-23 21:33:39.383512+00	20260720220000_staff_notifications	\N	\N	2026-07-23 21:33:39.3069+00	1
ff1a2cc3-384c-46f4-9162-7356f9c2d30a	33bd60ce0b31b2511ee11111a44142f6ffe151e62cce1262e9e04a2b5e89ab55	2026-07-23 21:33:39.408562+00	20260723160000_email_notification_settings	\N	\N	2026-07-23 21:33:39.387388+00	1
5edb07bd-907b-4e3c-a6f7-11f32a1aae6d	b8c788dba42e592d579db1b6b7db643e9b55bc891b041f215eb740fb5787e050	2026-07-24 07:58:50.839159+00	20260724100000_post_trip_reviews	\N	\N	2026-07-24 07:58:48.670402+00	1
b670fb65-eca8-410a-ba0e-6fd49f531357	cf238394f9b6ec5d2cf03a06373e1a39145de9e0a5b05ea2b1dbd1274ad7caea	2026-07-31 12:29:35.37029+00	20260731140000_page_content_locale	\N	\N	2026-07-31 12:29:35.219386+00	1
a696764f-b4f0-4917-a886-f972231d9097	50cdf304b2921d21f43434655a587b6035502c82e1c9b4e9b882b1971da6d9cb	2026-07-24 09:39:58.882259+00	20260724110000_review_submitted_notification	\N	\N	2026-07-24 09:39:58.838691+00	1
22d10c5a-2f9d-43e5-acb0-5c2013ce7b7c	13e8a5dd9773d8d8085c8bbc6828859ee79446b9eb5b12c1c11dd136c5cb72c3	2026-08-04 07:24:41.123817+00	20260804020000_settings_search_indexing	\N	\N	2026-08-04 07:24:41.102022+00	1
771aede8-4be9-49c3-b435-a71884144251	6041711e4f7fcac84f716d3aa312a08cd37feb0a45b17048f61f636fddfbed49	2026-07-31 12:46:51.746253+00	20260731150000_drop_page_content_slug_unique	\N	\N	2026-07-31 12:46:51.720148+00	1
05fc1035-2c6a-4e85-ba80-35c2dcafc0c2	a8b6a5e42d2ea0e7f064a18b9314c8406c4547c1de6250b0be9c21c572f171b0	2026-08-02 14:25:24.713827+00	20260731180000_paypal_order_intent	\N	\N	2026-08-02 14:25:24.483131+00	1
7e09fef0-87b9-426d-b056-3a719ac05804	9067de54893aa13b691ea61ed4a2ef632d239610e2e31f6daacf16f792fd7ee8	2026-08-05 21:22:24.935799+00	20260805233000_settings_vehicle_capacity_rules	\N	\N	2026-08-05 21:22:24.909129+00	1
00bcdf7e-c451-452e-bd8a-31e5049cc14e	36b12b2305dec53fa32f2ad21eb6400f072ab64d90fe19835b8752b87645943f	2026-08-04 08:38:01.212357+00	20260804120000_settings_smtp	\N	\N	2026-08-04 08:38:01.094955+00	1
5673e169-67e5-4634-8ee5-a0bf93b63d12	7834c41e22dca0524f557bba0fe0b81c9642475505c88ead33c0836db22061f0	2026-08-05 21:15:05.299606+00	20260805230000_vehicle_types_sedan_minivan_only	\N	\N	2026-08-05 21:15:05.139397+00	1
d7eccc4f-ed45-4174-bd91-a5a28fb568a1	398f2e7fca6edbbc1a8f9a10b74e2915bfc56abea1e83d0fdb7629588b32c520	2026-08-06 08:37:05.607244+00	20260806100000_booking_passenger_booker	\N	\N	2026-08-06 08:37:05.512114+00	1
\.


--
-- Name: AdminUser AdminUser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdminUser"
    ADD CONSTRAINT "AdminUser_pkey" PRIMARY KEY (id);


--
-- Name: BookingStatusEvent BookingStatusEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BookingStatusEvent"
    ADD CONSTRAINT "BookingStatusEvent_pkey" PRIMARY KEY (id);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: Driver Driver_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Driver"
    ADD CONSTRAINT "Driver_pkey" PRIMARY KEY (id);


--
-- Name: FlightStatusEvent FlightStatusEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FlightStatusEvent"
    ADD CONSTRAINT "FlightStatusEvent_pkey" PRIMARY KEY (id);


--
-- Name: MediaAsset MediaAsset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MediaAsset"
    ADD CONSTRAINT "MediaAsset_pkey" PRIMARY KEY (id);


--
-- Name: NotificationLog NotificationLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_pkey" PRIMARY KEY (id);


--
-- Name: PageContent PageContent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PageContent"
    ADD CONSTRAINT "PageContent_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: PaypalOrderIntent PaypalOrderIntent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PaypalOrderIntent"
    ADD CONSTRAINT "PaypalOrderIntent_pkey" PRIMARY KEY (id);


--
-- Name: PricingRule PricingRule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PricingRule"
    ADD CONSTRAINT "PricingRule_pkey" PRIMARY KEY (id);


--
-- Name: PushSubscription PushSubscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PushSubscription"
    ADD CONSTRAINT "PushSubscription_pkey" PRIMARY KEY (id);


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY (id);


--
-- Name: Settings Settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Settings"
    ADD CONSTRAINT "Settings_pkey" PRIMARY KEY (id);


--
-- Name: StaffNotification StaffNotification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StaffNotification"
    ADD CONSTRAINT "StaffNotification_pkey" PRIMARY KEY (id);


--
-- Name: Zone Zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Zone"
    ADD CONSTRAINT "Zone_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AdminUser_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AdminUser_email_key" ON public."AdminUser" USING btree (email);


--
-- Name: BookingStatusEvent_bookingId_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BookingStatusEvent_bookingId_timestamp_idx" ON public."BookingStatusEvent" USING btree ("bookingId", "timestamp");


--
-- Name: Booking_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_customerId_idx" ON public."Booking" USING btree ("customerId");


--
-- Name: Booking_driverId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_driverId_idx" ON public."Booking" USING btree ("driverId");


--
-- Name: Booking_paymentStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_paymentStatus_idx" ON public."Booking" USING btree ("paymentStatus");


--
-- Name: Booking_pickupDateTime_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_pickupDateTime_idx" ON public."Booking" USING btree ("pickupDateTime");


--
-- Name: Booking_pickupPin_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Booking_pickupPin_key" ON public."Booking" USING btree ("pickupPin");


--
-- Name: Booking_referenceCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Booking_referenceCode_key" ON public."Booking" USING btree ("referenceCode");


--
-- Name: Booking_roundTripId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_roundTripId_idx" ON public."Booking" USING btree ("roundTripId");


--
-- Name: Booking_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_status_idx" ON public."Booking" USING btree (status);


--
-- Name: Booking_zoneId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Booking_zoneId_idx" ON public."Booking" USING btree ("zoneId");


--
-- Name: Customer_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_email_key" ON public."Customer" USING btree (email);


--
-- Name: Customer_stripeCustomerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_stripeCustomerId_key" ON public."Customer" USING btree ("stripeCustomerId");


--
-- Name: Driver_active_vetted_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Driver_active_vetted_idx" ON public."Driver" USING btree (active, vetted);


--
-- Name: Driver_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Driver_phone_idx" ON public."Driver" USING btree (phone);


--
-- Name: Driver_plateNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Driver_plateNumber_key" ON public."Driver" USING btree ("plateNumber");


--
-- Name: FlightStatusEvent_bookingId_observedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FlightStatusEvent_bookingId_observedAt_idx" ON public."FlightStatusEvent" USING btree ("bookingId", "observedAt");


--
-- Name: FlightStatusEvent_flightNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FlightStatusEvent_flightNumber_idx" ON public."FlightStatusEvent" USING btree ("flightNumber");


--
-- Name: MediaAsset_url_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "MediaAsset_url_key" ON public."MediaAsset" USING btree (url);


--
-- Name: NotificationLog_bookingId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "NotificationLog_bookingId_idx" ON public."NotificationLog" USING btree ("bookingId");


--
-- Name: NotificationLog_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "NotificationLog_customerId_idx" ON public."NotificationLog" USING btree ("customerId");


--
-- Name: NotificationLog_status_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "NotificationLog_status_type_idx" ON public."NotificationLog" USING btree (status, type);


--
-- Name: PageContent_locale_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PageContent_locale_idx" ON public."PageContent" USING btree (locale);


--
-- Name: PageContent_slug_locale_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PageContent_slug_locale_key" ON public."PageContent" USING btree (slug, locale);


--
-- Name: Payment_bookingId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_bookingId_idx" ON public."Payment" USING btree ("bookingId");


--
-- Name: Payment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_status_idx" ON public."Payment" USING btree (status);


--
-- Name: PaypalOrderIntent_bookingId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PaypalOrderIntent_bookingId_idx" ON public."PaypalOrderIntent" USING btree ("bookingId");


--
-- Name: PaypalOrderIntent_orderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PaypalOrderIntent_orderId_key" ON public."PaypalOrderIntent" USING btree ("orderId");


--
-- Name: PaypalOrderIntent_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PaypalOrderIntent_status_idx" ON public."PaypalOrderIntent" USING btree (status);


--
-- Name: PricingRule_zoneId_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PricingRule_zoneId_active_idx" ON public."PricingRule" USING btree ("zoneId", active);


--
-- Name: PricingRule_zoneId_vehicleType_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PricingRule_zoneId_vehicleType_key" ON public."PricingRule" USING btree ("zoneId", "vehicleType");


--
-- Name: PushSubscription_audience_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PushSubscription_audience_idx" ON public."PushSubscription" USING btree (audience);


--
-- Name: PushSubscription_endpoint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PushSubscription_endpoint_key" ON public."PushSubscription" USING btree (endpoint);


--
-- Name: PushSubscription_ownerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PushSubscription_ownerId_idx" ON public."PushSubscription" USING btree ("ownerId");


--
-- Name: Review_bookingId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Review_bookingId_key" ON public."Review" USING btree ("bookingId");


--
-- Name: Review_driverId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Review_driverId_idx" ON public."Review" USING btree ("driverId");


--
-- Name: Review_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Review_status_idx" ON public."Review" USING btree (status);


--
-- Name: StaffNotification_audience_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StaffNotification_audience_createdAt_idx" ON public."StaffNotification" USING btree (audience, "createdAt");


--
-- Name: StaffNotification_audience_readAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StaffNotification_audience_readAt_idx" ON public."StaffNotification" USING btree (audience, "readAt");


--
-- Name: StaffNotification_bookingId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StaffNotification_bookingId_idx" ON public."StaffNotification" USING btree ("bookingId");


--
-- Name: StaffNotification_ownerId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StaffNotification_ownerId_createdAt_idx" ON public."StaffNotification" USING btree ("ownerId", "createdAt");


--
-- Name: Zone_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Zone_active_idx" ON public."Zone" USING btree (active);


--
-- Name: Zone_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Zone_name_key" ON public."Zone" USING btree (name);


--
-- Name: BookingStatusEvent BookingStatusEvent_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BookingStatusEvent"
    ADD CONSTRAINT "BookingStatusEvent_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Booking Booking_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Booking Booking_zoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_zoneId_fkey" FOREIGN KEY ("zoneId") REFERENCES public."Zone"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FlightStatusEvent FlightStatusEvent_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FlightStatusEvent"
    ADD CONSTRAINT "FlightStatusEvent_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationLog NotificationLog_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NotificationLog NotificationLog_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaypalOrderIntent PaypalOrderIntent_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PaypalOrderIntent"
    ADD CONSTRAINT "PaypalOrderIntent_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PricingRule PricingRule_zoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PricingRule"
    ADD CONSTRAINT "PricingRule_zoneId_fkey" FOREIGN KEY ("zoneId") REFERENCES public."Zone"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Zl3DyT0hNttUWbNQOMwi1IHOsaCXWHVPamZfcuMPrTofsya9j5ZtkMNdYs3bHhh

